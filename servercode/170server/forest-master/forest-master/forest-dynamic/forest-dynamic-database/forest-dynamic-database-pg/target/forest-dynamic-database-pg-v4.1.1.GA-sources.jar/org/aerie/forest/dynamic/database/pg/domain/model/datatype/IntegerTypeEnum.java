/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import org.aerie.forest.core.brick.domain.value.EnumValueObject;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.universal.ParamCheckException;

import lombok.Getter;

/**
 * @description 整数类型分类
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/14 16:05
 * @version v2.2.1.RC
 */
public enum IntegerTypeEnum implements EnumValueObject<IntegerTypeEnum, Integer> {

    /**
     * @description 小
     */
    SMALL(16, Short.MIN_VALUE, Short.MAX_VALUE),

    /**
     * @description 默认
     */
    DEFAULT(32, Integer.MIN_VALUE, Integer.MAX_VALUE),

    /**
     * @description 大
     */
    BIG(64, Long.MIN_VALUE, Long.MAX_VALUE);

    /**
     * @description 字段长度
     */
    private final Integer fieldSize;

    /**
     * @description 最小值
     */
    @Getter
    private final long minValue;

    /**
     * @description 最大值
     */
    @Getter
    private final long maxValue;

    /**
     * @description Constructor
     * @param fieldSize 字段长度
     * @param minValue 最小值
     * @param maxValue 最大值
     *
     * @author zhangqi
     * @date 2023/1/8 15:38
     * @initVersion v2.2.1.RC
     */
    IntegerTypeEnum(int fieldSize, long minValue, long maxValue) {
        this.fieldSize = fieldSize;
        this.minValue = minValue;
        this.maxValue = maxValue;
    }

    @Override
    public Integer getValue() {
        return fieldSize;
    }

    /**
     * @description 判断是否在范围内
     *
     * @author zhangqi
     * @date 2023/1/8 15:40
     * @initVersion v2.2.1.RC
     */
    public void withinLimits(Long min, Long max) throws ParamCheckException {
        if (min == null && max == null) {
            return;
        }
        if (min != null && max != null && min > max) {
            throw new ParamCheckException(ExceptionMsg
                .builder("The minimum value cannot be greater than the maximum value,min:{}, max:{}", min, max)
                .build());
        }
        if (min != null && (min < this.minValue || min > this.maxValue)) {
            throw new ParamCheckException(ExceptionMsg
                .builder("The minimum is out of range, min:{},range:{} - {}", min, minValue, maxValue).build());
        }
        if (max != null && (max < this.minValue || max > this.maxValue)) {
            throw new ParamCheckException(ExceptionMsg
                .builder("The minimum is out of range, min:{},range:{} - {}", min, minValue, maxValue).build());
        }
    }

    /**
     * @description 根据字段长度获取整数枚举
     * @param fieldSize 字段长度
     * @return 整数枚举
     *
     * @author zhangqi
     * @date 2023/1/8 16:02
     * @initVersion v2.2.1.RC
     */
    public static IntegerTypeEnum getIntTypeBySize(int fieldSize) {
        for (IntegerTypeEnum value : IntegerTypeEnum.values()) {
            if (fieldSize == value.fieldSize) {
                return value;
            }
        }
        return null;
    }
}
