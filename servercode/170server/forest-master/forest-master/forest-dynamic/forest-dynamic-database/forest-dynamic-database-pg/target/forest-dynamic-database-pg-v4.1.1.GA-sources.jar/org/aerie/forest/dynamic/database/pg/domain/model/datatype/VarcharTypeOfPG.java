/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.db.DBFieldException;

/**
 * @description varchar
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/14 16:38
 * @version v2.2.1.RC
 */
public class VarcharTypeOfPG extends AbstractStringTypeOfPG<VarcharTypeOfPG> {

    @Serial
    private static final long serialVersionUID = -1757171663048292831L;

    /**
     * @description 字符长度
     */
    private final int length;

    /**
     * @description 字段类型名称
     */
    private static final String DATA_TYPE_NAME = "varchar";

    /**
     * @description 关键字
     */
    private final String KEYWORD = "VARCHAR";

    /**
     * @description Constructor
     * @param length 字符长度
     *
     * @author zhangqi
     * @date 2022/11/14 16:40
     * @initVersion v2.2.1.RC
     */
    public VarcharTypeOfPG(int length) {
        this.length = length;
    }

    @Override
    public VarcharTypeOfPG verify() throws DBFieldException {
        if (length < 1) {
            throw new DBFieldException(ExceptionMsg.builder("The varchar length cannot be less than one").build());
        }
        return this;
    }

    @Override
    public String getKeyword() {
        return KEYWORD + (length >= 32767 ? "" : "(" + length + ")");
    }

    @Override
    public String getDataTypeName() {
        return DATA_TYPE_NAME;
    }

    @Override
    protected String assembleSqlPiece() {
        return new StringBuilder(KEYWORD).append(FRONT_SMALL_BRACKET).append(length).append(BACK_SMALL_BRACKET)
            .toString();
    }
}
