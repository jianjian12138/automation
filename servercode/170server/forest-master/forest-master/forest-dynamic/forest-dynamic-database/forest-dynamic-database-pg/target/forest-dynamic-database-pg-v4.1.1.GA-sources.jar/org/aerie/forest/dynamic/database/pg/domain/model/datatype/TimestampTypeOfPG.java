/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.core.brick.exception.db.DBFieldException;
import org.aerie.forest.dynamic.database.model.domain.module.AbstractPgsqlModule;
import org.aerie.forest.dynamic.database.model.domain.module.datatype.AbstractTimeTypeOfDB;

/**
 * @description pgsql时间戳类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/14 16:57
 * @version v2.2.1.RC
 */
public class TimestampTypeOfPG extends AbstractTimeTypeOfDB<AbstractPgsqlModule, TimestampTypeOfPG> {

    @Serial
    private static final long serialVersionUID = -8972640230823063267L;

    /**
     * @description 是否带时区标识
     */
    private final boolean timeZoneTag;

    /**
     * @description 字段类型名称
     */
    private static final String DATA_TYPE_NAME = "timestamp";

    /**
     * @description 关键字
     */
    private static final String KEYWORD = "TIMESTAMP";

    /**
     * @description 字段类型名称, 带时区
     */
    private static final String DATA_TYPE_NAME_TZ = "timestamptz";

    /**
     * @description 关键字, 带时区
     */
    private static final String KEYWORD_TZ = "TIMESTAMPTZ";

    /**
     * @description Constructor
     * @param timeZoneTag 是否带时区标识
     *
     * @author zhangqi
     * @date 2022/11/14 16:54
     * @initVersion v2.2.1.RC
     */
    public TimestampTypeOfPG(boolean timeZoneTag) {
        this.timeZoneTag = timeZoneTag;
    }

    @Override
    public TimestampTypeOfPG verify() throws DBFieldException {
        return this;
    }

    @Override
    public String getKeyword() {
        return timeZoneTag ? KEYWORD_TZ : KEYWORD;
    }

    @Override
    public String getDataTypeName() {
        return timeZoneTag ? DATA_TYPE_NAME_TZ : DATA_TYPE_NAME;
    }

    @Override
    protected String assembleSqlPiece() {
        return this.getKeyword();
    }
}
