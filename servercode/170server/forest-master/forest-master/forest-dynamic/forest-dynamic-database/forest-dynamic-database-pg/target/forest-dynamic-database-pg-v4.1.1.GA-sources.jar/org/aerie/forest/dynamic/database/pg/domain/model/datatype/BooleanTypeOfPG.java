/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.dynamic.database.model.domain.module.AbstractPgsqlModule;
import org.aerie.forest.dynamic.database.model.domain.module.datatype.AbstractBooleanTypeOfDB;

/**
 * @description pgsql的整布尔型
 *
 * @author zhangqi
 * @organization aeire
 * @date 2022/11/2 17:46
 * @version v2.2.1.RC
 */
public class BooleanTypeOfPG extends AbstractBooleanTypeOfDB<AbstractPgsqlModule, BooleanTypeOfPG> {

    @Serial
    private static final long serialVersionUID = -7277159295396211000L;

    /**
     * @description 字段类型名称
     */
    private static final String DATA_TYPE_NAME = "boolean";

    /**
     * @description 关键字
     */
    private final String KEYWORD = "BOOL";

    @Override
    public String getKeyword() {
        return KEYWORD;
    }

    @Override
    public BooleanTypeOfPG verify() {
        return this;
    }

    @Override
    public String getDataTypeName() {
        return DATA_TYPE_NAME;
    }

    @Override
    protected String assembleSqlPiece() {
        return KEYWORD;
    }
}
