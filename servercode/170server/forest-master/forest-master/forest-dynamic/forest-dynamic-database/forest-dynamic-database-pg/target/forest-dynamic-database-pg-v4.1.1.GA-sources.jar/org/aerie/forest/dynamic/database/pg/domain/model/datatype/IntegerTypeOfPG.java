/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.core.brick.exception.db.DBFieldException;
import org.aerie.forest.dynamic.database.model.domain.module.AbstractPgsqlModule;
import org.aerie.forest.dynamic.database.model.domain.module.datatype.AbstractIntegerTypeOfDB;

/**
 * @description pgsql的整数类型
 *
 * @author zhangqi
 * @organization aeire
 * @date 2022/11/2 17:46
 * @version v2.2.1.RC
 */
public class IntegerTypeOfPG extends AbstractIntegerTypeOfDB<AbstractPgsqlModule, IntegerTypeOfPG> {

    @Serial
    private static final long serialVersionUID = 7100480141381280084L;

    /**
     * @description 整数类型
     */
    private final IntegerTypeEnum integerTypeEnum;

    /**
     * @description 字段类型名称 小, smallint (int2)[-32768 to +32767]
     */
    private static final String DATA_TYPE_NAME_SMALL = "smallint";

    /**
     * @description 关键字 小
     */
    private static final String KEYWORD_SMALL = "SMALLINT";

    /**
     * @description 字段类型名称 默认, (int4)[-2147483648 to +2147483647]
     */
    private static final String DATA_TYPE_NAME_DEFAULT = "integer";

    /**
     * @description 关键字 默认
     */
    private static final String KEYWORD_DEFAULT = "INTEGER";

    /**
     * @description 字段类型名称 大, (int8)[-9223372036854775808 to +9223372036854775807]
     */
    private static final String DATA_TYPE_NAME_BIG = "bigint";

    /**
     * @description 关键字 大
     */
    private static final String KEYWORD_BIG = "BIGINT";

    /**
     * @description Constructor
     * @param integerTypeEnum 整数类型
     *
     * @author zhangqi
     * @date 2022/11/14 16:13
     * @initVersion v2.2.1.RC
     */
    public IntegerTypeOfPG(IntegerTypeEnum integerTypeEnum) {
        this.integerTypeEnum = integerTypeEnum;
    }

    @Override
    public IntegerTypeOfPG verify() throws DBFieldException {
        return this;
    }

    @Override
    public String getKeyword() {
        switch (this.integerTypeEnum) {
            case SMALL -> {
                return KEYWORD_SMALL;
            }
            case DEFAULT -> {
                return KEYWORD_DEFAULT;
            }
            case BIG -> {
                return KEYWORD_BIG;
            }
        }
        return KEYWORD_DEFAULT;
    }

    @Override
    public String getDataTypeName() {
        switch (this.integerTypeEnum) {
            case SMALL -> {
                return DATA_TYPE_NAME_SMALL;
            }
            case DEFAULT -> {
                return DATA_TYPE_NAME_DEFAULT;
            }
            case BIG -> {
                return DATA_TYPE_NAME_BIG;
            }
        }
        return DATA_TYPE_NAME_DEFAULT;
    }

    @Override
    protected String assembleSqlPiece() {
        return this.getKeyword();
    }

}
