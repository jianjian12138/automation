/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.dynamic.database.model.domain.module.AbstractPgsqlModule;
import org.aerie.forest.dynamic.database.model.domain.module.datatype.AbstractTimeTypeOfDB;

/**
 * @description pgsql的日时间类型
 *
 * @author zhangqi
 * @organization aeire
 * @date 2022/11/2 17:46
 * @version v2.2.1.RC
 */
public abstract class AbstractTimeTypeOfPG<T extends AbstractTimeTypeOfPG<T>>
    extends AbstractTimeTypeOfDB<AbstractPgsqlModule, T> {

    @Serial
    private static final long serialVersionUID = 2939559189801268576L;
}
