/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.dynamic.database.model.domain.module.AbstractPgsqlModule;
import org.aerie.forest.dynamic.database.model.domain.module.datatype.AbstractSerialTypeOfDB;

/**
 * @description pgsql的整数类型
 *
 * @author zhangqi
 * @organization aeire
 * @date 2022/11/2 17:46
 * @version v2.2.1.RC
 */
public class SerialTypeOfPG extends AbstractSerialTypeOfDB<AbstractPgsqlModule, SerialTypeOfPG> {

    @Serial
    private static final long serialVersionUID = -2760993560257863851L;

    /**
     * @description 整数类型
     */
    private final IntegerTypeEnum integerTypeEnum;

    /**
     * @description 字段类型名称 小, smallserial (serial2)[ 1 to 32767]
     */
    private static final String DATA_TYPE_NAME_SMALL = "smallserial";

    /**
     * @description 关键字 小
     */
    private static final String KEYWORD_SMALL = "SMALLSERIAL";

    /**
     * @description 字段类型名称 默认, serial (serial4)[1 to 2147483647]
     */
    private static final String DATA_TYPE_NAME_DEFAULT = "serial";

    /**
     * @description 关键字 默认
     */
    private static final String KEYWORD_DEFAULT = "SERIAL";

    /**
     * @description 字段类型名称 大, bigserial (serial8)[1 to 9223372036854775807]
     */
    private static final String DATA_TYPE_NAME_BIG = "bigserial";

    /**
     * @description 关键字 大
     */
    private static final String KEYWORD_BIG = "BIGSERIAL";

    /**
     * @description Constructor
     * @param integerTypeEnum 序号类型
     *
     * @author zhangqi
     * @date 2022/11/14 16:13
     * @initVersion v2.2.1.RC
     */
    public SerialTypeOfPG(IntegerTypeEnum integerTypeEnum) {
        this.integerTypeEnum = integerTypeEnum;
    }

    @Override
    public SerialTypeOfPG verify() {
        return this;
    }

    @Override
    public String getKeyword() {
        switch (integerTypeEnum) {
            case SMALL -> {
                return KEYWORD_SMALL;
            }
            case DEFAULT -> {
                return KEYWORD_DEFAULT;
            }
            case BIG -> {
                return KEYWORD_BIG;
            }
        }
        return KEYWORD_DEFAULT;
    }

    @Override
    public String getDataTypeName() {
        switch (integerTypeEnum) {
            case SMALL -> {
                return DATA_TYPE_NAME_SMALL;
            }
            case DEFAULT -> {
                return DATA_TYPE_NAME_DEFAULT;
            }
            case BIG -> {
                return DATA_TYPE_NAME_BIG;
            }
        }
        return DATA_TYPE_NAME_DEFAULT;
    }

    @Override
    protected String assembleSqlPiece() {
        return this.getKeyword();
    }

}
