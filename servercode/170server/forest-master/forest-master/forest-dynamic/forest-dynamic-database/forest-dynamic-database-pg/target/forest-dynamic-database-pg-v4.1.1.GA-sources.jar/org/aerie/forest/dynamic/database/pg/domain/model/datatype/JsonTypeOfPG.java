/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

/**
 * @description json
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/14 15:34
 * @version v2.2.1.RC
 */
public class JsonTypeOfPG extends AbstractJsonTypeOfPG<JsonTypeOfPG> {

    @Serial
    private static final long serialVersionUID = 5159177364735174011L;

    /**
     * @description 字段类型名称
     */
    private static final String DATA_TYPE_NAME = "json";

    /**
     * @description 关键字
     */
    private final String KEYWORD = "JSON";

    @Override
    public String getKeyword() {
        return KEYWORD;
    }

    @Override
    public String getDataTypeName() {
        return DATA_TYPE_NAME;
    }

    @Override
    protected String assembleSqlPiece() {
        return KEYWORD;
    }

    @Override
    public JsonTypeOfPG verify() {
        return this;
    }
}
