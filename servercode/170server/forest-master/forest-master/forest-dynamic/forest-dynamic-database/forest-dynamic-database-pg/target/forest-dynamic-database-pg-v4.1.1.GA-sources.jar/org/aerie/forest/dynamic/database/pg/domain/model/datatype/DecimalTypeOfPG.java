/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

/**
 * @description Decimal
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/14 15:34
 * @version v2.2.1.RC
 */
public class DecimalTypeOfPG extends AbstractFixedPointTypeOfPG<DecimalTypeOfPG> {

    @Serial
    private static final long serialVersionUID = -7204412763471540908L;

    /**
     * @description 字段类型名称
     */
    private static final String DATA_TYPE_NAME = "decimal";

    /**
     * @description 关键字
     */
    private final String KEYWORD = "DECIMAL";

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2022/11/14 16:07
     * @initVersion v2.2.1.RC
     */
    public DecimalTypeOfPG() {}

    /**
     * @description Constructor
     * @param precision 精度
     *
     * @author zhangqi
     * @date 2022/11/14 16:07
     * @initVersion v2.2.1.RC
     */
    public DecimalTypeOfPG(Integer precision) {
        super(precision, null);
    }

    /**
     * @description Constructor
     * @param precision 精度
     * @param scale 有效数
     *
     * @author zhangqi
     * @date 2022/11/14 16:08
     * @initVersion v2.2.1.RC
     */
    public DecimalTypeOfPG(Integer precision, Integer scale) {
        super(precision, scale);
    }

    @Override
    public String getKeyword() {
        return KEYWORD;
    }

    @Override
    public String getDataTypeName() {
        return DATA_TYPE_NAME;
    }

    @Override
    protected String assembleSqlPiece() {
        return assembleFixedPoint(KEYWORD);
    }

}
