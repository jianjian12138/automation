/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.core.brick.exception.db.DBFieldException;

/**
 * @description text
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/14 16:38
 * @version v2.2.1.RC
 */
public class TextTypeOfPG extends AbstractStringTypeOfPG<TextTypeOfPG> {

    @Serial
    private static final long serialVersionUID = -3711206403601410588L;

    /**
     * @description 字段类型名称
     */
    private static final String DATA_TYPE_NAME = "text";

    /**
     * @description 关键字
     */
    private final String KEYWORD = "TEXT";

    @Override
    public TextTypeOfPG verify() throws DBFieldException {
        return this;
    }

    @Override
    public String getKeyword() {
        return KEYWORD;
    }

    @Override
    public String getDataTypeName() {
        return DATA_TYPE_NAME;
    }

    @Override
    protected String assembleSqlPiece() {
        return KEYWORD;
    }
}
