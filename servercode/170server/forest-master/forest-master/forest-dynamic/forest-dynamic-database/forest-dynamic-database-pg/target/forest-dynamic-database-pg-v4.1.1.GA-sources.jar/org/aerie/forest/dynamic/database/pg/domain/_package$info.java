/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

/**
 * @description 领域
 *
 * @author zhangqi
 * @organization aerie
 * @date 2022/11/02 16:52
 * @version v2.2.1.RC
 */
package org.aerie.forest.dynamic.database.pg.domain;