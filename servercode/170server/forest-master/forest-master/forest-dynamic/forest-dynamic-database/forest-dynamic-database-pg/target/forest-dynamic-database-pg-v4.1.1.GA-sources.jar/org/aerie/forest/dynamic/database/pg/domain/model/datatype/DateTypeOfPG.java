/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.core.brick.exception.db.DBFieldException;

/**
 * @description pgsql日期类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/14 17:03
 * @version v2.2.1.RC
 */
public class DateTypeOfPG extends AbstractTimeTypeOfPG<DateTypeOfPG> {

    @Serial
    private static final long serialVersionUID = -5317067596887511262L;

    /**
     * @description 字段类型名称
     */
    private static final String DATA_TYPE_NAME = "date";

    /**
     * @description 关键字
     */
    private final String KEYWORD = "DATE";

    @Override
    public DateTypeOfPG verify() throws DBFieldException {
        return this;
    }

    @Override
    public String getKeyword() {
        return KEYWORD;
    }

    @Override
    public String getDataTypeName() {
        return DATA_TYPE_NAME;
    }

    @Override
    protected String assembleSqlPiece() {
        return KEYWORD;
    }
}
