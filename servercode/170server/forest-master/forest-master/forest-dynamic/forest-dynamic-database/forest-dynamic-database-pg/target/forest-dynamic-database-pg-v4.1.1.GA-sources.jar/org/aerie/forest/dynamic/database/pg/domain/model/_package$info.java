/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

/**
 * @description 模型
 *
 * @author zhangqi
 * @organization aerie
 * @date 2022/11/02 14:58
 * @version v2.2.1.RC
 */
package org.aerie.forest.dynamic.database.pg.domain.model;