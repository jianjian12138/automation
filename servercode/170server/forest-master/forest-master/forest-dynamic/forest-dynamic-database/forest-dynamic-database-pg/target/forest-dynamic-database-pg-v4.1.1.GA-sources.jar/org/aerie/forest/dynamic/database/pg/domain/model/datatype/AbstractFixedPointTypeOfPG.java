/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.db.DBFieldException;
import org.aerie.forest.dynamic.database.model.domain.module.AbstractPgsqlModule;
import org.aerie.forest.dynamic.database.model.domain.module.datatype.AbstractBooleanTypeOfDB;
import org.aerie.forest.dynamic.database.model.domain.module.datatype.AbstractDataTypeOfDB;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @description pgsql的定点数类型
 *
 * @author zhangqi
 * @organization aeire
 * @date 2022/11/2 17:46
 * @version v2.2.1.RC
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractFixedPointTypeOfPG<T extends AbstractFixedPointTypeOfPG<T>>
    extends AbstractBooleanTypeOfDB<AbstractPgsqlModule, T> {

    @Serial
    private static final long serialVersionUID = 6900675248922509295L;

    /**
     * @description 精准度(定点数的整数部分和小数部分总长度)
     */
    protected Integer precision;

    /**
     * @description 有效位数
     */
    protected Integer scale;

    @Override
    @SuppressWarnings("unchecked")
    public T verify() throws DBFieldException {
        if (scale != null && (precision == null || precision.compareTo(scale) < 0)) {
            throw new DBFieldException(ExceptionMsg
                .builder(
                    "If the scale exists, the precision must exist and the precision must be greater than the scale")
                .build());
        }
        if (precision != null && precision.compareTo(0) <= 0) {
            throw new DBFieldException(ExceptionMsg.builder("The precision must be greater than zero").build());
        }
        if (scale != null && scale.compareTo(0) < 0) {
            throw new DBFieldException(ExceptionMsg.builder("The scale cannot be less than zero").build());
        }
        return (T)this;
    }

    /**
     * @description 组装定点数的sql片
     * @param keyWord 关键字
     * @return 定点数的sql片
     *
     * @author zhangqi
     * @date 2022/11/14 18:02
     * @initVersion v2.2.1.RC
     */
    protected String assembleFixedPoint(String keyWord) {
        if (getScale() != null) {
            return new StringBuilder(keyWord).append(AbstractDataTypeOfDB.FRONT_SMALL_BRACKET).append(getPrecision()).append(AbstractDataTypeOfDB.COMMA)
                .append(getScale()).append(AbstractDataTypeOfDB.BACK_SMALL_BRACKET).toString();
        }
        if (getPrecision() != null) {
            return new StringBuilder(keyWord).append(AbstractDataTypeOfDB.FRONT_SMALL_BRACKET).append(getPrecision())
                .append(AbstractDataTypeOfDB.BACK_SMALL_BRACKET).toString();
        }
        return keyWord;
    }

}
