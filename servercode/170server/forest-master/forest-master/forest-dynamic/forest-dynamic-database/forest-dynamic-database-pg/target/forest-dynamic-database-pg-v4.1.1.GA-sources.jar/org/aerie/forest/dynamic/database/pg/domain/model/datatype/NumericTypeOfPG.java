/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

/**
 * @description Numeric
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/14 15:34
 * @version v2.2.1.RC
 */
public class NumericTypeOfPG extends AbstractFixedPointTypeOfPG<NumericTypeOfPG> {

    @Serial
    private static final long serialVersionUID = -3395508380426104524L;

    /**
     * @description 字段类型名称
     */
    private static final String DATA_TYPE_NAME = "numeric";

    /**
     * @description 关键字
     */
    private final String KEYWORD = "NUMERIC";

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2022/11/14 16:08
     * @initVersion v2.2.1.RC
     */
    public NumericTypeOfPG() {}

    /**
     * @description Constructor
     * @param precision 精度
     *
     * @author zhangqi
     * @date 2022/11/14 16:09
     * @initVersion v2.2.1.RC
     */
    public NumericTypeOfPG(Integer precision) {
        super(precision, null);
    }

    /**
     * @description Constructor
     * @param precision 精度
     * @param scale 有效数
     *
     * @author zhangqi
     * @date 2022/11/14 16:09
     * @initVersion v2.2.1.RC
     */
    public NumericTypeOfPG(Integer precision, Integer scale) {
        super(precision, scale);
    }

    @Override
    public String getKeyword() {
        if (precision != null && scale == null) {
            return KEYWORD + "(" + precision + ")";
        } else if (precision != null) {
            return KEYWORD + "(" + precision + ", " + scale + ")";
        }
        throw new RuntimeException("precision can not be null");
    }

    @Override
    public String getDataTypeName() {
        return DATA_TYPE_NAME;
    }

    @Override
    protected String assembleSqlPiece() {
        return assembleFixedPoint(KEYWORD);
    }
}
