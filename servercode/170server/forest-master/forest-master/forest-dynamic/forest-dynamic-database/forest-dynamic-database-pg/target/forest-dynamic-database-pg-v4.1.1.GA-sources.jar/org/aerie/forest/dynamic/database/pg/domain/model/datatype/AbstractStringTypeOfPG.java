/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.database.pg.domain.model.datatype;

import java.io.Serial;

import org.aerie.forest.dynamic.database.model.domain.module.AbstractPgsqlModule;
import org.aerie.forest.dynamic.database.model.domain.module.datatype.AbstractStringTypeOfDB;

/**
 * @description pgsql的字符串类型
 *
 * @author zhangqi
 * @organization aeire
 * @date 2022/11/2 17:46
 * @version v2.2.1.RC
 */
public abstract class AbstractStringTypeOfPG<T extends AbstractStringTypeOfPG<T>>
    extends AbstractStringTypeOfDB<AbstractPgsqlModule, T> {

    @Serial
    private static final long serialVersionUID = -170477806903335556L;
}
