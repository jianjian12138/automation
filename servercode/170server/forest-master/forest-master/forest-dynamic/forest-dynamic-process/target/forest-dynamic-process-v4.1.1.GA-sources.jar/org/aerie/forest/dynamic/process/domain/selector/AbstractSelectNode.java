/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.selector.UnselectedException;
import org.aerie.forest.core.frame.rebar.factory.ForestFactory;
import org.aerie.forest.dynamic.process.domain._shelf.ForestDpShelf;
import org.aerie.forest.dynamic.process.domain.calculate.ContinueFieldsLump;
import org.aerie.forest.dynamic.process.domain.compare.processor.Comparator;
import org.aerie.forest.dynamic.process.domain.compare.processor.ComparisonExpression;
import org.aerie.forest.dynamic.process.domain.compare.processor.ComparisonExpressionPack;
import org.aerie.forest.dynamic.process.domain.placeholder.AbstractFieldBasePositionInfo;
import org.aerie.forest.dynamic.process.domain.placeholder.LocalFieldPlaceholder;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import cn.hutool.core.collection.CollUtil;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 选择节点
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/22 9:52
 * @version 3.0.1.300
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractSelectNode<T extends Serializable> extends ContinueFieldsLump<AbstractSelectNode<T>, ValidationParam> implements Serializable {

    @Serial
    private static final long serialVersionUID = 1531366464910037009L;

    /**
     * @description 比较器
     */
    protected static final Comparator COMPARATOR =
        ForestFactory.INSTANCE.getForestRebarFactory(ForestDpShelf.getInstance().comparator);

    /**
     * @description 比较器集合 需要单独的处理器校验
     */
    protected final List<ComparisonExpression> comparisonExpressions;

    /**
     * @description 选择节点输出结果
     */
    protected T value;

    @Override
    protected List<String> detailedAllParameterPlaceholder() {
        List<String> result = new ArrayList<>();
        if (CollUtil.isNotEmpty(comparisonExpressions)) {
            return result;
        }
        for (ComparisonExpression comparisonExpression : comparisonExpressions) {
            result.addAll(comparisonExpression.obtainAllParameterPlaceholder());
        }
        return result;
    }

    /**
     * @description Constructor
     * @param value 选择节点输出结果
     * @param comparisonExpressions 比较器集合 需要单独的处理器校验
     *
     * @author zhangqi
     * @date 2024/6/26 18:42
     * @initVersion v3.1.1.GA
     */
    @JsonCreator
    public AbstractSelectNode(@JsonProperty("value") T value,
        @JsonProperty("comparisonExpressions") List<ComparisonExpression> comparisonExpressions) {
        this.value = value;
        this.comparisonExpressions =
            CollUtil.isEmpty(comparisonExpressions) ? new ArrayList<>() : comparisonExpressions;
    }

    @Override
    protected AbstractSelectNode<T> detailedValidation(ValidationParam validationParam) throws ExceptionPack {
        try {
            if (!CollUtil.isEmpty(comparisonExpressions)) {
                for (ComparisonExpression comparisonExpression : comparisonExpressions) {
                    comparisonExpression.verify(validationParam.getOwnedEnterpriseCode());
                }
            }
            return this;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Selector node validation failed").build());
        }
    }

    @Override
    protected List<LocalFieldPlaceholder> detailedNeedProvideFields() throws ExceptionPack {
        try {
            List<LocalFieldPlaceholder> result = new ArrayList<>();
            for (ComparisonExpression comparisonExpression : comparisonExpressions) {
                List<LocalFieldPlaceholder> localFieldPlaceholders = comparisonExpression.needProvideFields();
                result.addAll(localFieldPlaceholders);
            }
            return AbstractFieldBasePositionInfo.distinctWithBaseCheckNullable(result);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The set of fields required by the select node cannot be obtained").build());
        }
    }

    @Override
    protected final List<LocalFieldPlaceholder> detailedProvidedFields() throws ExceptionPack {
        // 单独的选择节点无法提供任何字段
        return new ArrayList<>();
    }

    /**
     * @description 获得选择节点结果
     * @return 结果
     * @throws Exception 获得结果异常
     *
     * @author zhangqi
     * @date 2023/11/22 18:50
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public final T getResult(Map<String, String> placeholderValueMap) throws Exception {
        if (CollUtil.isEmpty(comparisonExpressions)) {
            return value;
        }
        for (ComparisonExpression comparisonExpression : comparisonExpressions) {
            if (Boolean.FALSE.equals(
                COMPARATOR.executeProcess(new ComparisonExpressionPack(comparisonExpression, placeholderValueMap)))) {
                throw new UnselectedException(ExceptionMsg.builder("The comparator is false").build());
            }
        }
        return value;
    }

    @JsonIgnore
    @Override
    public List<String> getAllPlaceholderValue() {
        List<String> result = new ArrayList<>();
        comparisonExpressions.forEach(p -> result.addAll(p.getAllPlaceholderValue()));
        return result;
    }

    /**
     * @description 获得节点的输出 - 使用的时候需要一次性汇总获得所有的输出, 然后查询校验[性能问题] 当然后面要采取其他的方式解决这个问题, 比如将校验内置
     * @return 节点的输出
     *
     * @author zhangqi
     * @date 2024/10/16 9:26
     * @initVersion v4.0.1.GA
     */
    @Deprecated
    public T output() {
        return value;
    }
}
