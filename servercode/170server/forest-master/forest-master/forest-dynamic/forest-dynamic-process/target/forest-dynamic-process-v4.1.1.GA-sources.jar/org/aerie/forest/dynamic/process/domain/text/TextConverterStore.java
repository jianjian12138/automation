/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.text;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.StringJudgementShelf;
import org.aerie.forest.core.brick.bannew.statical.AbstractStaticResource;
import org.aerie.forest.core.brick.exception.AbstractForestException;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.function.verify.ParameterFree;
import org.aerie.forest.core.brick.processor.MessageHideProcessor;

import cn.hutool.core.util.StrUtil;

/**
 * @description 文本转化器库
 *
 * @author quark
 * @organization futurecraftsmen
 * @date 2024/4/29 15:54
 * @version v3.1.1.GA
 */

public final class TextConverterStore extends AbstractStaticResource {

    /**
     * @description 全密文展示 - 空返回 —— , 非空返回 "******"
     */
    public static final AbstractTextConverter<ParameterFree> FULL_CIPHERTEXT = new AbstractTextConverter<>() {

        @Override
        public ParameterFree verify(ParameterFree o) {
            return null;
        }

        @Override
        protected String transformAction(String text, ParameterFree param) throws AbstractForestException {
            return MessageHideProcessor.INSTANCE.hideAction(text, -1, -1);
        }
    };

    /**
     * @description 自动部分密文
     */
    public static final AbstractTextConverter<ParameterFree> AUTOMATIC_CIPHERTEXT = new AbstractTextConverter<>() {

        @Override
        public ParameterFree verify(ParameterFree o) {
            return null;
        }

        @Override
        protected String transformAction(String text, ParameterFree param) throws AbstractForestException {
            if (StrUtil.isBlank(text)) {
                return MessageHideProcessor.NULL_VALUE_REPLACE_FLAG;
            }
            return MessageHideProcessor.INSTANCE.hideAction(text, 3, text.length() - 3);
        }
    };

    /**
     * @description 自动部分密文
     */
    public static final AbstractTextConverter<TextLocationInfo> CUSTOM_CIPHERTEXT = new AbstractTextConverter<>() {

        @Override
        public TextLocationInfo verify(TextLocationInfo o) throws AbstractForestException {
            return AssertInjecter.inject(o, "ciphertextLocation").and(ObjectJudgementShelf.NOT_NULL)
                .and(p -> p.start <= 0).and(p -> p.start < p.end)
                .judgeAndGet(ExceptionMsg.builder("Custom ciphertext parameters are illegal, param: {}", o).build());
        }

        @Override
        protected String transformAction(String text, TextLocationInfo param) throws AbstractForestException {
            return MessageHideProcessor.INSTANCE.hideAction(text, param.start, param.end());
        }
    };

    /**
     * @description 字符串截取
     */
    public static final AbstractTextConverter<TextLocationInfo> STRING_TRUNCATION = new AbstractTextConverter<>() {

        @Override
        public TextLocationInfo verify(TextLocationInfo o) throws AbstractForestException {
            return AssertInjecter.inject(o, "ciphertextLocation").and(ObjectJudgementShelf.NOT_NULL)
                .and(p -> p.start <= 0).and(p -> p.start < p.end)
                .judgeAndGet(ExceptionMsg.builder("Custom ciphertext parameters are illegal, param: {}", o).build());
        }

        @Override
        protected String transformAction(String text, TextLocationInfo param) throws AbstractForestException {
            try {
                return AssertInjecter.inject(text, "text").and(StringJudgementShelf.NOT_BLANK)
                    .judgeAndGet(ExceptionMsg.builder("text cannot be blank").build())
                    .substring(param.start, param.end);
            } catch (Exception e) {
                throw new ExceptionPack(e, ExceptionMsg.builder("Strings cannot be truncated").build());
            }
        }
    };

    /**
     * @description 密文起止位置
     * @param start 起
     * @param end 止
     *
     * @author quark
     * @organization futurecraftsmen
     * @date 2024/4/30 17:51
     * @version v3.1.1.GA
     */
    public record TextLocationInfo(int start, int end) {
    }

    /**
     * @description 字符串拼接
     */
    public static final AbstractTextConverter<String> STRING_SPLICING = new AbstractTextConverter<>() {
        @Override
        public String verify(String s) throws AbstractForestException {
            return AssertInjecter.inject(s, "s").and(StringJudgementShelf.NOT_BLANK)
                .judgeAndGet(ExceptionMsg.builder("The string to be concatenated cannot be blank").build());
        }

        @Override
        protected String transformAction(String text, String param) throws AbstractForestException {
            try {
                return AssertInjecter.inject(text, "text").and(StringJudgementShelf.NOT_BLANK)
                    .judgeAndGet(ExceptionMsg.builder("The string to be concatenated cannot be blank").build())
                    .concat(param);
            } catch (Exception e) {
                throw new ExceptionPack(e, ExceptionMsg.builder("Strings cannot be concatenated").build());
            }
        }
    };
}
