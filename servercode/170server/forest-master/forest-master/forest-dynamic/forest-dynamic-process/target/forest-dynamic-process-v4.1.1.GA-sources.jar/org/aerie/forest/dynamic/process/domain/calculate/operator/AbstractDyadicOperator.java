/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator;

import java.math.BigDecimal;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.JudgmentExecutor;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ComparableJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.calculate.OperatorNodeException;
import org.aerie.forest.dynamic.process.domain.calculate.ParamPosition;

/**
 * @description 双元运算符
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 15:03
 * @version 3.0.1.300
 */
public abstract class AbstractDyadicOperator extends AbstractOperator {

    /**
     * @description Constructor
     * @param displaySymbol 展示的符号
     *
     * @author zhangqi
     * @date 2023/4/19 17:31
     * @initVersion 3.0.1.300
     */
    protected AbstractDyadicOperator(String displaySymbol, String operatorName, int priority) {
        super(displaySymbol, operatorName, 20 + priority);
    }

    @Override
    public final BigDecimal getResult(int scale, BigDecimal... params) throws ExceptionPack {
        try {
            checkParam(params);
            AssertInjecter.inject(params.length, "params length").and(ComparableJudgementShelf.EQUAL_TO, 2)
                .judge(ExceptionMsg.builder("The number of parameters calculated is invalid, paramSize: {}",
                    JudgmentExecutor.This.INSTANCE).build());
            return calculateResult(scale, params[0], params[1]);
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The result cannot be calculated").build());
        }
    }

    /**
     * @description 计算出结果
     * @param scale 小数位数
     * @param front 前运算数
     * @param back 后运算数
     * @return 计算的结果
     *
     * @author zhangqi
     * @date 2023/4/19 16:45
     * @initVersion 3.0.1.300
     */
    protected abstract BigDecimal calculateResult(int scale, BigDecimal front, BigDecimal back) throws ExceptionPack;

    @Override
    public final ParamPosition getParamPosition() {
        // 双元运算符肯定是两侧
        return ParamPosition.FLANKS;
    }

    @Override
    public void verifyPre(Object pre) throws OperatorNodeException {
        if (pre instanceof BigDecimal) {
            // 双元运算符前面可以是数字
            return;
        }
        if (pre instanceof AbstractOperator value && value.getParamPosition().equals(ParamPosition.LEFT)) {
            // 运算符前面可以是后置单元运算符
            return;
        }
        throw new OperatorNodeException(
            ExceptionMsg.builder("The front symbol of the dyadic symbol is invalid").build());
    }

    @Override
    public void verifyNext(Object next) throws OperatorNodeException {
        if (next instanceof BigDecimal) {
            // 双元运算符后面可以是数字
            return;
        }
        if (next instanceof AbstractOperator value && value.getParamPosition().equals(ParamPosition.RIGHT)) {
            // 双元运算符后面可以是前置单元运算符
            return;
        }
        throw new OperatorNodeException(
            ExceptionMsg.builder("The back symbol of the dyadic symbol is invalid").build());
    }

}
