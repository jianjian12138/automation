/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.operator.number;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.compare.AbstractNumberSymbol;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractNumericalValue;

/**
 * @description 数值比较 等于
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 17:59
 * @version 3.0.1.300
 */
public final class NumericalUnEqual extends AbstractNumberSymbol {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 数值不等于
         */
        private static final NumericalUnEqual NUMERICAL_UN_EQUAL = new NumericalUnEqual();
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static NumericalUnEqual getInstance() {
        return INSTANCE.NUMERICAL_UN_EQUAL;
    }

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2023/5/15 17:14
     * @initVersion 3.0.1.300
     */
    private NumericalUnEqual() {
        super("!=", "不等于", false, "NUMERICAL_UN_EQUAL");
    }

    @Override
    protected boolean compare(AbstractNumericalValue<?> pre, AbstractNumericalValue<?> post) throws ExceptionPack {
        try {
            return pre.getComparableValue(false).compareTo(post.getComparableValue(false)) != 0;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to compare successfully, comparison expression: {}",
                pre.getValue() + getDisplaySymbol() + post.getValue()).build());
        }
    }

}
