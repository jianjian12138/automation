/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import java.math.BigDecimal;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.frame.rebar.factory.ForestFactory;
import org.aerie.forest.dynamic.process.domain._shelf.ForestDpShelf;
import org.aerie.forest.dynamic.process.domain.calculate.processor.AbstractOperationNode;
import org.aerie.forest.dynamic.process.domain.calculate.processor.operation.OperationProcessPack;
import org.aerie.forest.dynamic.process.domain.calculate.processor.operation.OperationProcessor;
import org.aerie.forest.dynamic.process.domain.calculate.processor.show.ShowProcessPack;
import org.aerie.forest.dynamic.process.domain.calculate.processor.show.ShowProcessor;

/**
 * @description 计算值
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 14:35
 * @version 3.0.1.300
 */
public final class CalculateValue extends AbstractNumericalValue<AbstractOperationNode<?>> {

    /**
     * @description Constructor
     * @param value 值
     *
     * @author zhangqi
     * @date 2023/5/17 14:32
     * @initVersion 3.0.1.300
     */
    public CalculateValue(AbstractOperationNode<?> value) {
        super(value);
    }

    @Override
    public BigDecimal getComparableValue(boolean canBeNull) throws ExceptionPack {

        OperationProcessor operationProcessor =
            ForestFactory.INSTANCE.getForestRebarFactory(ForestDpShelf.getInstance().operationProcessor);
        try {
            if (canBeNull && value == null) {
                return null;
            }
            AssertInjecter.inject(value, "value").and(ObjectJudgementShelf.NOT_NULL).or().and(() -> canBeNull)
                .judge(ExceptionMsg.builder("The value to be compared cannot be null").build());
            return operationProcessor.executeProcess(new OperationProcessPack(value, 16, 5));
        } catch (Exception e) {
            ShowProcessor showProcessor =
                ForestFactory.INSTANCE.getForestRebarFactory(ForestDpShelf.getInstance().showProcessor);
            throw new ExceptionPack(e, ExceptionMsg.builder("Could not calculate the value, equation: {}",
                showProcessor.executeProcess(new ShowProcessPack(value, null))).build());
        }
    }
}
