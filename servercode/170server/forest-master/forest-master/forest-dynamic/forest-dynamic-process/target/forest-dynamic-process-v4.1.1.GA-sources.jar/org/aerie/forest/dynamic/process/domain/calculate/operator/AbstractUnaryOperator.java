/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator;

import java.math.BigDecimal;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.JudgmentExecutor;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ComparableJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.calculate.OperatorNodeException;
import org.aerie.forest.dynamic.process.domain.calculate.ParamPosition;
import org.aerie.forest.dynamic.process.domain.calculate.processor.EndNode;
import org.aerie.forest.dynamic.process.domain.calculate.processor.StartNode;

/**
 * @description 单元运算符
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 15:03
 * @version 3.0.1.300
 */
public abstract class AbstractUnaryOperator extends AbstractOperator {

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     * @param operatorName 符号名称
     * @param priority 优先级
     *
     * @author zhangqi
     * @date 2023/4/20 9:24
     * @initVersion 3.0.1.300
     */
    protected AbstractUnaryOperator(String displaySymbol, String operatorName, int priority) {
        super(displaySymbol, operatorName, priority + 50);
    }

    @Override
    public final BigDecimal getResult(int scale, BigDecimal... params) throws ExceptionPack {
        try {
            checkParam(params);
            AssertInjecter.inject(params.length, "params length").and(ComparableJudgementShelf.EQUAL_TO, 1)
                .judge(ExceptionMsg.builder("The number of parameters calculated is invalid, paramSize: {}",
                    JudgmentExecutor.This.INSTANCE).build());
            return calculateResult(scale, params[0]);
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The result cannot be calculated").build());
        }
    }

    /**
     * @description 计算出结果
     * @param scale 范围
     * @param param 运算数
     * @return 计算的结果
     *
     * @author zhangqi
     * @date 2023/4/19 16:45
     * @initVersion 3.0.1.300
     */
    protected abstract BigDecimal calculateResult(int scale, BigDecimal param) throws ExceptionPack;

    @Override
    public void verifyPre(Object pre) throws OperatorNodeException {
        ParamPosition paramPosition = getParamPosition();
        if (paramPosition.equals(ParamPosition.LEFT)) {
            if (pre instanceof BigDecimal) {
                return;
            }
            if (pre instanceof AbstractOperator value && value.getParamPosition().equals(ParamPosition.LEFT)) {
                return;
            }
            throw new OperatorNodeException(ExceptionMsg
                .builder("The prefix operator is illegal, present operator: {}, pre operator: {}", this, pre).build());
        } else if (paramPosition.equals(ParamPosition.RIGHT)) {
            if (pre instanceof AbstractDyadicOperator) {
                return;
            }
            if (pre instanceof AbstractOperator value && value.getParamPosition().equals(ParamPosition.RIGHT)) {
                return;
            }
            if (pre instanceof StartNode) {
                return;
            }
            throw new OperatorNodeException(ExceptionMsg
                .builder("The prefix operator is illegal, present operator: {}, pre operator: {}", this, pre).build());
        }
        throw new OperatorNodeException(ExceptionMsg
            .builder("The front symbol of the unary symbol is invalid, paramPosition: {}", paramPosition).build());
    }

    @Override
    public void verifyNext(Object next) throws OperatorNodeException {
        ParamPosition paramPosition = getParamPosition();
        if (paramPosition.equals(ParamPosition.LEFT)) {
            if (next instanceof AbstractDyadicOperator) {
                return;
            }
            if (next instanceof AbstractOperator value && value.getParamPosition().equals(ParamPosition.LEFT)) {
                return;
            }
            if (next instanceof EndNode) {
                return;
            }
            throw new OperatorNodeException(ExceptionMsg
                .builder("The next operator is illegal, present operator: {}, next operator: {}", this, next).build());
        } else if (paramPosition.equals(ParamPosition.RIGHT)) {
            if (next instanceof BigDecimal) {
                return;
            }
            if (next instanceof AbstractOperator value && value.getParamPosition().equals(ParamPosition.RIGHT)) {
                return;
            }
            throw new OperatorNodeException(ExceptionMsg
                .builder("The next operator is illegal, present operator: {}, next operator: {}", this, next).build());
        }
        throw new OperatorNodeException(ExceptionMsg
            .builder("The back symbol of the unary symbol is invalid, paramPosition: {}", paramPosition).build());
    }
}
