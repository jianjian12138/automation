/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.genericity.ContainsGenericity;

import lombok.Getter;

/**
 * @description 可以比较的值
 * @param <T> 真实值的类型
 * @param <V> 比较的值类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 14:30
 * @version 3.0.1.300
 */
@Getter
public abstract class AbstractComparable<T, V> implements ContainsGenericity {

    /**
     * @description 实际的值
     */
    protected final T value;

    /**
     * @description Constructor
     * @param value 实际的值
     *
     * @author quark
     * @date 2024/4/11 10:06
     * @initVersion v3.1.0.GA
     */
    protected AbstractComparable(T value) {
        this.value = value;
    }

    /**
     * @description 获得到数值
     * @param canBeNull 可以为空标识
     * @return 数值
     *
     * @author zhangqi
     * @date 2023/5/15 14:19
     * @initVersion 3.0.1.300
     */
    public abstract V getComparableValue(boolean canBeNull) throws ExceptionPack;
}
