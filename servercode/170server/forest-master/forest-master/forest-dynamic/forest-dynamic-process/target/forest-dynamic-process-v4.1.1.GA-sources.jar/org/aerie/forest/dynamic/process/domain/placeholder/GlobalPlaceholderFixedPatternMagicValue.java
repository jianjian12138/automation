/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import java.util.regex.Pattern;

import org.aerie.forest.core.brick.function.PatternMagicValue;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;

import cn.hutool.core.util.StrUtil;
import lombok.Getter;

/**
 * @description 全局固定值占位符正则表达式
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/2/16 13:44
 * @version 3.0.1.300
 */
public enum GlobalPlaceholderFixedPatternMagicValue implements PatternMagicValue {

    /**
     * @description 数值固定值
     */
    FIXED_VALUE_NUMBER(
        Pattern.compile("^(N\\{(-?[1-9]\\d*|0)(\\.\\d+)?\\|[\\u4e00-\\u9fff\\u3400-\\u4dbfa-zA-Z0-9]{2,16}})$"),
        FieldLogicTypeEnum.NUMBER, 1),

    /**
     * @description 关联表固定值
     */
    FIXED_VALUE_ASSOCIATION(
        Pattern.compile("^(A\\{[1-9]\\d{17,18}\\|[\\u4e00-\\u9fff\\u3400-\\u4dbfa-zA-Z0-9]{2,16}})$"),
        FieldLogicTypeEnum.ASSOCIATION, 2),

    /**
     * @description 关联表集合固定值
     */
    FIXED_VALUE_ASSOCIATION_SET(
        Pattern.compile("^(S\\{[1-9]\\d{17,18}\\|[\\u4e00-\\u9fff\\u3400-\\u4dbfa-zA-Z0-9]{2,16}})$"),
        FieldLogicTypeEnum.ASSOCIATION_SET, 3),

    /**
     * @description 关联枚举固定值
     */
    FIXED_VALUE_ENUM(
        Pattern.compile("^(E\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}\\|[\\u4e00-\\u9fff\\u3400-\\u4dbfa-zA-Z0-9]{2,16}})$"),
        FieldLogicTypeEnum.ENUM, 4),

    /**
     * @description 关联枚举集合固定值
     */
    FIXED_VALUE_ENUM_SET(
        Pattern.compile("^(X\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}\\|[\\u4e00-\\u9fff\\u3400-\\u4dbfa-zA-Z0-9]{2,16}})$"),
        FieldLogicTypeEnum.ENUM_SET, 5),

    /**
     * @description 字符串固定值
     */
    FIXED_VALUE_VARCHAR(Pattern.compile("^(V\\{[^|]*\\|[\\u4e00-\\u9fff\\u3400-\\u4dbfa-zA-Z0-9]{2,16}})$"),
        FieldLogicTypeEnum.VARCHAR, 6),

    /**
     * @description 时间固定值
     */
    FIXED_VALUE_TIME(Pattern.compile("^(T\\{[\\d-: .]{5,23}\\|[\\u4e00-\\u9fff\\u3400-\\u4dbfa-zA-Z0-9]{2,16}})$"),
        FieldLogicTypeEnum.TIME, 7),

    /**
     * @description 布尔固定值
     */
    FIXED_VALUE_BOOLEAN(Pattern.compile("^(B\\{(false|true)\\|[\\u4e00-\\u9fff\\u3400-\\u4dbfa-zA-Z0-9]{2,16}})$"),
        FieldLogicTypeEnum.BOOLEAN, 8);

    /**
     * @description 值
     */
    private final Pattern value;

    /**
     * @description 字段逻辑类型
     */
    @Getter
    private final FieldLogicTypeEnum fieldLogicType;

    /**
     * @description
     */
    @Getter
    private final int index;

    /**
     * @description Constructor
     * @param value 值
     * @param fieldLogicType 字段逻辑类型
     * @param index 序号
     *
     * @author zhangqi
     * @date 2023/2/16 13:45
     * @initVersion 3.0.1.300
     */
    GlobalPlaceholderFixedPatternMagicValue(Pattern value, FieldLogicTypeEnum fieldLogicType, int index) {
        this.value = value;
        this.fieldLogicType = fieldLogicType;
        this.index = index;
    }

    @Override
    public Pattern getValue() {
        return this.value;
    }

    /**
     * @description 匹配占位符固定值
     * @param value 待匹配的值
     * @return 匹配到的类型
     *
     * @author zhangqi
     * @date 2023/6/12 12:37
     * @initVersion 3.0.1.300
     */
    public static GlobalPlaceholderFixedPatternMagicValue matchGlobalPlaceholderFixedPatternMagicValue(String value) {
        if (StrUtil.isBlank(value)) {
            return null;
        }
        for (GlobalPlaceholderFixedPatternMagicValue globalPlaceholderPatternMagicValue : GlobalPlaceholderFixedPatternMagicValue
            .values()) {
            if (globalPlaceholderPatternMagicValue.getValue().matcher(value).matches()) {
                return globalPlaceholderPatternMagicValue;
            }
        }
        return null;
    }

    /**
     * @description 解析出参数占位符信息
     * @param value 带解析的参数占位符
     * @return 解析出的参数占位符的信息
     *
     * @author zhangqi
     * @date 2024/8/22 16:27
     * @initVersion v4.0.1.GA
     */
    public static ParameterPlaceholderInfo resolveParameterPlaceholderInfo(String value) {
        GlobalPlaceholderFixedPatternMagicValue globalPlaceholderPatternMagicValue =
            matchGlobalPlaceholderFixedPatternMagicValue(value);
        if (globalPlaceholderPatternMagicValue == null) {
            return null;
        }
        String[] split = value.substring(2, value.length() - 1).split("\\|");
        return new ParameterPlaceholderInfo(split[1], split[0], globalPlaceholderPatternMagicValue);
    }
}
