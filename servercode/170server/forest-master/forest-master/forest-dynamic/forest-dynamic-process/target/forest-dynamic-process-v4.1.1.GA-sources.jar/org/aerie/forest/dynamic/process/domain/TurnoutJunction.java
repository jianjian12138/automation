/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain;

import java.io.Serializable;

/**
 * @description 流程岔道
 * @param turnoutJunctionType 流程岔道类型
 * @param turnoutJunctionMsg 流程岔道信息
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/11/27 22:01
 * @version 3.0.1.300
 */
public record TurnoutJunction(TurnoutJunctionTypeEnum turnoutJunctionType, String turnoutJunctionMsg) implements Serializable {

}
