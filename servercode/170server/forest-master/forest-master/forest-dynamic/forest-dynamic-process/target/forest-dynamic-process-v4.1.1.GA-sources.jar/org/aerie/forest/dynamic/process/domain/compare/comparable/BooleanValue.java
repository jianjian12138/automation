/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;

/**
 * @description 布尔值
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/16 16:17
 * @version 3.0.1.300
 */
public final class BooleanValue extends AbstractComparable<Boolean, Boolean> {

    /**
     * @description Constructor
     * @param value 值
     *
     * @author zhangqi
     * @date 2023/5/17 10:25
     * @initVersion 3.0.1.300
     */
    public BooleanValue(Boolean value) {
        super(value);
    }

    @Override
    public Boolean getComparableValue(boolean canBeNull) throws ExceptionPack {
        try {
            if (canBeNull && value == null) {
                return null;
            }
            AssertInjecter.inject(value, "value").and(ObjectJudgementShelf.NOT_NULL).or().and(() -> canBeNull)
                .judge(ExceptionMsg.builder("The value to be compared cannot be null").build());
            return value;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Cannot obtain value, value: {}", value).build());
        }
    }
}