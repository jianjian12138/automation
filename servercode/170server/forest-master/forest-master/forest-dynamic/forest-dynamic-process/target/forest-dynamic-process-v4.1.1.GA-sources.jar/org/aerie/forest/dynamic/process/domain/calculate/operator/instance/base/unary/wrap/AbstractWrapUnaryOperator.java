/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.wrap;

import org.aerie.forest.core.brick.exception.calculate.CalculateRuntimeException;
import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractUnaryOperator;
import org.aerie.forest.dynamic.process.domain.calculate.operator.WrapFunction;
import org.aerie.forest.dynamic.process.domain.calculate.ParamPosition;

/**
 * @description 单元包裹型符号
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/20 11:27
 * @version 3.0.1.300
 */
public abstract class AbstractWrapUnaryOperator extends AbstractUnaryOperator
    implements WrapFunction<AbstractWrapUnaryOperator> {

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     * @param operatorName 符号名称
     * @param priority 优先级
     *
     * @author zhangqi
     * @date 2023/4/20 11:43
     * @initVersion 3.0.1.300
     */
    protected AbstractWrapUnaryOperator(String displaySymbol, String operatorName, int priority) {
        super(displaySymbol, operatorName, 40 + priority);
        ParamPosition paramPosition = getParamPosition();
        // 包裹符号只能参数在前或者在后
        if (!paramPosition.equals(ParamPosition.LEFT) && !paramPosition.equals(ParamPosition.RIGHT)) {
            throw new CalculateRuntimeException("The parameter position of the wrap operator is invalid");
        }
    }
}