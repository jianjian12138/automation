/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector.mapvalue;

import static org.aerie.forest.dynamic.process.domain.placeholder.GlobalPlaceholderPatternMagicValue.*;

import java.util.List;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.compare.CompareException;
import org.aerie.forest.dynamic.process.domain.calculate.ContinueFieldsLump;
import org.aerie.forest.dynamic.process.domain.compare.processor.ComparisonExpression;
import org.aerie.forest.dynamic.process.domain.placeholder.*;
import org.aerie.forest.dynamic.process.domain.selector.AbstractSelectNode;
import org.aerie.forest.dynamic.process.domain.selector.ValidationParam;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 选择节点
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/22 9:52
 * @version 3.0.1.300
 */
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public final class SelectMapValueNode extends AbstractSelectNode<String> {

    /**
     * @description Constructor
     * @param value 选择节点输出结果
     * @param comparisonExpressions 比较器集合 需要单独的处理器校验
     *
     * @author zhangqi
     * @date 2024/6/26 18:42
     * @initVersion v3.1.1.GA
     */
    public SelectMapValueNode(@JsonProperty("value") String value,
        @JsonProperty("comparisonExpressions") List<ComparisonExpression> comparisonExpressions) {
        super(value, comparisonExpressions);
    }

    @Override
    protected List<String> detailedAllParameterPlaceholder() {
        List<String> result = super.detailedAllParameterPlaceholder();
        if (GlobalPlaceholderFixedPatternMagicValue.matchGlobalPlaceholderFixedPatternMagicValue(value) != null) {
            result.add(value);
        }
        return result;
    }

    @Override
    protected SelectMapValueNode detailedValidation(ValidationParam validationParam) throws ExceptionPack {
        try {
            super.detailedValidation(validationParam);
            if (GlobalPlaceholderFixedPatternMagicValue.matchGlobalPlaceholderFixedPatternMagicValue(value) != null) {
                return this;
            }
            GlobalPlaceholderPatternMagicValue globalPlaceholderPatternMagicValue =
                GlobalPlaceholderPatternMagicValue.matchGlobalPlaceholderPatternMagicValue(value);
            if (CALCULATION_PLACEHOLDER.equals(globalPlaceholderPatternMagicValue)
                || CODE_PLACEHOLDER.equals(globalPlaceholderPatternMagicValue)
                || SET_PLACEHOLDER.equals(globalPlaceholderPatternMagicValue)
                || TEXT_MANIPULATION_PLACEHOLDER.equals(globalPlaceholderPatternMagicValue)) {
                return this;
            }
            if (globalPlaceholderPatternMagicValue == null) {
                throw new CompareException(
                    ExceptionMsg.builder("The selector output does not match, value: {}", value).build());
            }
            AssertInjecter
                .inject(AbstractFieldBasePositionInfoResolver.getPlaceholderThreadLocal().get().get(value), "realValue")
                .and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndReturn(ExceptionMsg.builder(
                    "Placeholder cache no, the previous unified query field information is incomplete, value: {}",
                    value).build())
                .and(p -> !p.isNullable()).or().and(validationParam::isNullAble)
                .judge(ExceptionMsg.builder(
                    "The output of a selector for a mapping of required fields must be non-null if it is a placeholder")
                    .msgView("必填字段的映射的选择器的输出如果是占位符必须是非空").build());
            return this;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Select map value node validation failed").build());
        }
    }

    @Override
    protected List<LocalFieldPlaceholder> detailedNeedProvideFields() throws ExceptionPack {
        try {
            List<LocalFieldPlaceholder> result = super.detailedNeedProvideFields();
            result.addAll(resolveAllLocalPlaceholder(value));
            return AbstractFieldBasePositionInfo.distinctWithBaseCheckNullable(result);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The set of fields required by the select node cannot be obtained").build());
        }
    }

    @JsonIgnore
    @Override
    public List<String> getAllPlaceholderValue() {
        List<String> result = super.getAllPlaceholderValue();
        result.addAll(ContinueFieldsLump.resolveAllPlaceholderValue(value));
        return result;
    }
}
