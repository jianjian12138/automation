/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import org.aerie.forest.core.brick.pact.time.TimeFormatEnum;

import lombok.Getter;

/**
 * @description 数值
 * @param <V> 数值的实际类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 14:23
 * @version 3.0.1.300
 */
@Getter
public abstract class AbstractTimeValue<V> extends AbstractComparable<String, V> {

    /**
     * @description 时间格式
     */
    protected final TimeFormatEnum timeFormat;

    /**
     * @description Constructor
     * @param value 值
     *
     * @author zhangqi
     * @date 2023/5/17 10:25
     * @initVersion 3.0.1.300
     */
    protected AbstractTimeValue(String value, TimeFormatEnum timeFormatEnum) {
        super(value);
        this.timeFormat = timeFormatEnum;
    }

}
