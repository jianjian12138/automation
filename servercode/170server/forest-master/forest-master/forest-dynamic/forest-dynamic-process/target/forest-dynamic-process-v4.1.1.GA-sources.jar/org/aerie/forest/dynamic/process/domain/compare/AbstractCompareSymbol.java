/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare;

import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;
import org.aerie.forest.dynamic.process.domain.calculate.AbstractSymbol;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractComparable;
import org.aerie.forest.dynamic.process.domain.placeholder.PlaceholderCalibrator;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;

/**
 * @description 比较符号
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 13:59
 * @version 3.0.1.300
 */
@Getter
public abstract class AbstractCompareSymbol<T extends AbstractComparable<?, ?>> extends AbstractSymbol
    implements PlaceholderCalibrator {

    /**
     * @description 空标识
     */
    public static final String NULL_FLAG = "{NULL}";

    /**
     * @description 兼容字段类型
     */
    protected final FieldLogicTypeEnum fieldLogicTypeEnum;

    /**
     * @description 参数可空标识
     */
    protected final boolean paramNullableFlag;

    /**
     * @description 标识
     */
    protected final String flag;

    /**
     * @description Constructor
     * @param displaySymbol 显示符号
     * @param operatorName 符号名称
     * @param fieldLogicTypeEnum 兼容字段类型
     * @param paramNullableFlag 参数可空标识
     * @param flag 标识
     *
     * @author zhangqi
     * @date 2023/12/7 11:39
     * @initVersion 3.0.1.300
     */
    protected AbstractCompareSymbol(String displaySymbol, String operatorName, FieldLogicTypeEnum fieldLogicTypeEnum,
        boolean paramNullableFlag, String flag) {
        super(displaySymbol, operatorName);
        this.fieldLogicTypeEnum = fieldLogicTypeEnum;
        this.paramNullableFlag = paramNullableFlag;
        this.flag = flag;
    }

    /**
     * @description 比较
     * @param pre 前置待比较的值
     * @param post 后置待比较的值
     * @return 判断结果
     * @throws ExceptionPack 比较异常
     *
     * @author zhangqi
     * @date 2023/5/15 17:57
     * @initVersion 3.0.1.300
     */
    protected abstract boolean compare(T pre, T post) throws ExceptionPack;

    /**
     * @description 比较
     * @param pre 前置待比较的值
     * @param post 后置待比较的值
     * @return 判断结果
     * @throws ExceptionPack 比较异常
     *
     * @author zhangqi
     * @date 2023/6/26 17:22
     * @initVersion 3.0.1.300
     */
    public boolean compare(String pre, String post) throws ExceptionPack {
        return compare(generateComparable(pre), generateComparable(post));
    }

    /**
     * @description 获得可比较对象
     * @param value 可比较对象的值
     * @return 生成的可比较对象
     *
     * @author zhangqi
     * @date 2023/5/17 9:38
     * @initVersion 3.0.1.300
     */
    public abstract T generateComparable(String value) throws ExceptionPack;

    /**
     * @description 校验比较值
     * @param value 待校验的值
     * @throws ExceptionPack 校验异常
     * @return 附加属性
     *
     * @author zhangqi
     * @date 2023/5/31 14:53
     * @initVersion 3.0.1.300
     */
    public abstract String checkComparable(String value) throws ExceptionPack;

    /**
     * @description 获得判空符号
     * @return 判空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:40
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public abstract AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNullSymbol();

    /**
     * @description 获得判非空符号
     * @return 判非空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:41
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public abstract AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNotNullSymbol();

    @Override
    public String toString() {
        return "AbstractCompareSymbol{" + "fieldLogicTypeEnum=" + fieldLogicTypeEnum + '}';
    }
}
