/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector.turnoff;

import java.util.Map;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.selector.UnselectedException;
import org.aerie.forest.dynamic.process.domain.TurnoutJunction;
import org.aerie.forest.dynamic.process.domain.selector.AbstractSelector;
import org.aerie.forest.dynamic.process.domain.selector.ValidationParam;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 流程岔道
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/22 9:52
 * @version 3.0.1.300
 */
@AllArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public final class TurnoffSelector extends AbstractSelector<SelectTurnoffNode, TurnoutJunction> {

    @JsonIgnore
    @Override
    public TurnoutJunction getResult(Map<String, String> placeholderValueMap) throws ExceptionPack {
        try {
            return super.getResult(placeholderValueMap);
        } catch (UnselectedException e) {
            // 没有命中返回null
            return null;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The selector cannot get the result").build());
        }
    }

    @Override
    protected TurnoffSelector detailedValidation(ValidationParam validationParam) throws ExceptionPack {
        try {
            super.detailedValidation(validationParam);
            return this;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The Turnoff Selector is invalid").build());
        }
    }
}