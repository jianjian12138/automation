/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import java.io.Serial;
import java.io.Serializable;

import org.aerie.forest.dynamic.process.domain.placeholder.GlobalPlaceholderFixedPatternMagicValue;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @description 参数占位符信息
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/22 14:55
 * @version 3.1.1.300
 */
@Data
public final class ParameterPlaceholderInfo implements Serializable {

    @Serial
    private static final long serialVersionUID = -1038408925220357712L;

    /**
     * @description 参数占位符名称
     */
    private String name;

    /**
     * @description 占位符的值
     */
    private String placeholderValue;

    /**
     * @description 占位符的类型
     */
    private GlobalPlaceholderFixedPatternMagicValue placeholderType;

    /**
     * @description Constructor
     * @param name 参数占位符名
     * @param placeholderValue 占位符的值
     * @param placeholderType 占位符的类型
     *
     * @author zhangqi
     * @date 2024/8/22 15:05
     * @initVersion 3.1.1.300
     */
    @JsonCreator
    public ParameterPlaceholderInfo(@JsonProperty("name") String name,
        @JsonProperty("placeholderValue") String placeholderValue,
        @JsonProperty("placeholderType") GlobalPlaceholderFixedPatternMagicValue placeholderType) {
        this.name = name;
        this.placeholderValue = placeholderValue;
        this.placeholderType = placeholderType;
    }
}
