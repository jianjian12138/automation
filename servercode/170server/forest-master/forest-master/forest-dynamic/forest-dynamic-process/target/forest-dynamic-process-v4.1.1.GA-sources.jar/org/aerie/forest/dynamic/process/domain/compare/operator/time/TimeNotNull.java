/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.operator.time;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.compare.AbstractTimeSymbol;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractTimeValue;

/**
 * @description 时间比较 非空
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 17:59
 * @version 3.0.1.300
 */
public final class TimeNotNull extends AbstractTimeSymbol {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 时间非空
         */
        private static final TimeNotNull TIME_NOT_NULL = new TimeNotNull();
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static TimeNotNull getInstance() {
        return INSTANCE.TIME_NOT_NULL;
    }

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2023/5/15 17:14
     * @initVersion 3.0.1.300
     */
    private TimeNotNull() {
        super("NOT NULL", "非空", true, "TIME_NOT_NULL");
    }

    @Override
    protected boolean compare(AbstractTimeValue<?> pre, AbstractTimeValue<?> post) throws ExceptionPack {
        try {
            return pre.getComparableValue(true) != null;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to compare successfully, comparison expression: {}",
                pre.getValue() + getDisplaySymbol() + post.getValue()).build());
        }
    }

    // 序列化单例
    private Object readResolve() {
        return INSTANCE.TIME_NOT_NULL;
    }
}
