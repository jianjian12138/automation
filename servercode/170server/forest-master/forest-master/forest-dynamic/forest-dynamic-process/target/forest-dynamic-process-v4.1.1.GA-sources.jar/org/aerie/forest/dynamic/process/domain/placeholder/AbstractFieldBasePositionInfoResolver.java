/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import static org.aerie.forest.dynamic.common.domain.mv.GlobalDynamicalMagicValue.ENTERPRISE_VIRTUAL_DM_TABLE;

import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.placeholder.PlaceholderException;
import org.aerie.forest.core.genericity.ContainsGenericity;
import org.aerie.forest.dynamic.common.domain.FieldLogicInfo;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;
import org.aerie.forest.dynamic.common.domain.TableFieldModel;
import org.aerie.forest.dynamic.common.domain.function.TableFieldFunction;
import org.aerie.forest.dynamic.common.domain.function.TableFunction;
import org.aerie.forest.dynamic.common.domain.mv.GlobalDynamicalMagicValue;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import lombok.*;

/**
 * @description 字段基础定位信息解析器
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/6/14 14:21
 * @version 3.0.1.300
 */
public abstract class AbstractFieldBasePositionInfoResolver<T extends AbstractFieldBasePositionInfo>
    implements ContainsGenericity {

    /**
     * @description 字段缓存信息
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/6/15 11:24
     * @version 3.0.1.300
     */
    @NoArgsConstructor
    @Data
    @ToString
    @EqualsAndHashCode
    protected static class FieldCacheInfo {

        /**
         * @description 表编号
         */
        private long tableCode;

        /**
         * @description 字段编号
         */
        private long fieldCode;

        /**
         * @description 可空标识
         */
        private boolean nullAble;

        /**
         * @description 占位符逻辑类型
         */
        private PlaceholderLogicTypeEnum placeholderType;

        /**
         * @description 集合序号
         */
        private boolean setFlag;

        /**
         * @description Constructor
         * @param tableCode 表编号
         * @param fieldCode 字段编号
         * @param nullAble 可空标识
         * @param placeholderType 占位符逻辑类型
         *
         * @author pms
         * @date 2023/9/18 22:41
         * @initVersion 3.0.1.300
         */
        public FieldCacheInfo(long tableCode, long fieldCode, boolean nullAble,
            PlaceholderLogicTypeEnum placeholderType) {
            this.tableCode = tableCode;
            this.fieldCode = fieldCode;
            this.nullAble = nullAble;
            this.placeholderType = placeholderType;
        }

        /**
         * @description Constructor
         * @param tableCode 表编号
         * @param fieldCode 字段编号
         * @param nullAble 可空标识
         * @param placeholderType 占位符逻辑类型
         * @param setFlag 集合标识
         *
         * @author pms
         * @date 2023/9/18 22:42
         * @initVersion 3.0.1.300
         */
        public FieldCacheInfo(long tableCode, long fieldCode, boolean nullAble,
            PlaceholderLogicTypeEnum placeholderType, boolean setFlag) {
            this.tableCode = tableCode;
            this.fieldCode = fieldCode;
            this.nullAble = nullAble;
            this.placeholderType = placeholderType;
            this.setFlag = setFlag;
        }

        /**
         * @description 生成占位符的key
         * @return 占位符的key
         *
         * @author zhangqi
         * @date 2023/6/16 9:30
         * @initVersion 3.0.1.300
         */
        public final String generatePlaceholderKey() {
            return this.placeholderType.getValue() + SEPARATOR_1 + this.tableCode + SEPARATOR_1 + this.fieldCode;
        }

        /**
         * @description 获得占位符的值
         * @return 占位符的值
         *
         * @author quark
         * @date 2024/4/15 10:13
         * @initVersion v3.1.0.GA
         */
        public final String getPlaceholderValue() {
            return LocalAbstractFieldPlaceholderResolver.getInstance().generatePlaceholder(
                String.valueOf(this.tableCode), String.valueOf(this.fieldCode), this.nullAble, this.setFlag, false);
        }

        /**
         * @description 相同占位符类型的相同字段的可空标识必须一致(LOCAL_INSERT不参与校验)
         * @param fieldCacheInfoList 待校验的
         *
         * @author zhangqi
         * @date 2023/6/16 9:42
         * @initVersion 3.0.1.300
         */
        public static void checkLogic(List<FieldCacheInfo> fieldCacheInfoList) {
            if (CollUtil.isEmpty(fieldCacheInfoList)) {
                return;
            }
            Map<String, Boolean> distinctCache = new HashMap<>();
            Iterator<FieldCacheInfo> iterator = fieldCacheInfoList.iterator();
            Map<String, String> placeholderErr = PLACEHOLDER_ERR_THREAD_LOCAL.get();
            while (iterator.hasNext()) {
                FieldCacheInfo next = iterator.next();
                String key = next.generatePlaceholderKey();
                if (next.getPlaceholderType().equals(PlaceholderLogicTypeEnum.UNIQUE) && next.nullAble) {
                    placeholderErr.put(next.generatePlaceholderKey(), "数据库占位符唯一索引必须非空");
                    iterator.remove();
                    continue;
                }
                // 更新插入占位符
                Boolean nullable = distinctCache.get(key);
                if (nullable == null && !PlaceholderLogicTypeEnum.LOCAL_INSERT.equals(next.getPlaceholderType())) {
                    distinctCache.put(key, next.isNullAble());
                    continue;
                }
                if (Boolean.TRUE.equals(nullable) != next.isNullAble()
                    && !PlaceholderLogicTypeEnum.LOCAL_INSERT.equals(next.getPlaceholderType())) {
                    placeholderErr.put(next.generatePlaceholderKey(), "存在相同fieldCode, 可空标识不一致的本地占位符");
                    iterator.remove();
                }
            }
        }
    }

    /**
     * @description 占位符分解逻辑类型
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/6/15 11:39
     * @version 3.0.1.300
     */
    @Getter
    protected enum PlaceholderLogicTypeEnum {

        /**
         * @description 本地占位符
         */
        LOCAL("local"),

        /**
         * @description 本地占位符写入数据库
         */
        LOCAL_INSERT("local-insert"),

        /**
         * @description 数据库占位符
         */
        DB("db"),

        /**
         * @description 唯一索引
         */
        UNIQUE("unique");

        /**
         * @description 值
         */
        private final String value;

        /**
         * @description Constructor
         * @param value 值
         *
         * @author zhangqi
         * @date 2023/6/16 9:20
         * @initVersion 3.0.1.300
         */
        PlaceholderLogicTypeEnum(String value) {
            this.value = value;
        }

    }

    /**
     * @description true
     */
    protected static final String TURE_FLAG = "t";

    /**
     * @description false
     */
    protected static final String FALSE_FLAG = "f";

    /**
     * @description 分隔符1
     */
    protected static final String SEPARATOR_1 = "_";

    /**
     * @description 分隔符2
     */
    protected static final String SEPARATOR_2 = "-";

    /**
     * @description 分隔符
     */
    protected static final String SEPARATOR_3 = "\\^";

    /**
     * @description 企业编号
     */
    // private static final FieldLogicInfo ENTERPRISE_CODE =
    // new FieldLogicInfo(GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue(), ENTERPRISE_CODE_FLAG,
    // FieldLogicTypeEnum.ASSOCIATION,
    // String.valueOf(GlobalDynamicalMagicValue.ENTERPRISE_VIRTUAL_DM_TABLE.getValue()), false);
    //
    // /**
    // * @description 企业名称
    // */
    // private static final FieldLogicInfo ENTERPRISE_NAME =
    // new FieldLogicInfo(GlobalDynamicalMagicValue.NAME_VIRTUAL_CODE.getValue(), ENTERPRISE_NAME_FLAG,
    // FieldLogicTypeEnum.VARCHAR, null, false);

    /**
     * @description 占位符线程 local
     */
    protected static final ThreadLocal<Map<String, AbstractFieldBasePositionInfo>> PLACEHOLDER_THREAD_LOCAL =
        ThreadLocal.withInitial(HashMap::new);

    /**
     * @description 占位符错误线程 local
     */
    protected static final ThreadLocal<Map<String, String>> PLACEHOLDER_ERR_THREAD_LOCAL =
        ThreadLocal.withInitial(HashMap::new);

    /**
     * @description 流程模板/动态页/权益等模型关联的所有表和字段
     */
    protected static final ThreadLocal<CouplingTableField> COUPLING_TABLE_FIELD =
        ThreadLocal.withInitial(CouplingTableField::new);

    /**
     * @description 是否包含已停用的表或字段
     */
    protected static final ThreadLocal<Boolean> INCLUDE_DISABLED_TABLE_FIELDS =
        ThreadLocal.withInitial(() -> Boolean.FALSE);

    /**
     * @description 获取占位符线程local
     * @return 占位符线程local
     *
     * @author zhangqi
     * @date 2023/6/16 16:39
     * @initVersion 3.0.1.300
     */
    public static ThreadLocal<Map<String, AbstractFieldBasePositionInfo>> getPlaceholderThreadLocal() {
        return PLACEHOLDER_THREAD_LOCAL;
    }

    /**
     * @description 获取占位符err线程local
     * @return 占位符err线程local
     *
     * @author zhangqi
     * @date 2023/6/16 16:39
     * @initVersion 3.0.1.300
     */
    public static ThreadLocal<Map<String, String>> getPlaceholderErrThreadLocal() {
        return PLACEHOLDER_ERR_THREAD_LOCAL;
    }

    public static ThreadLocal<CouplingTableField> getCouplingTableField() {
        return COUPLING_TABLE_FIELD;
    }

    public static ThreadLocal<Boolean> includeDisabledTableFields() {
        return INCLUDE_DISABLED_TABLE_FIELDS;
    }

    /**
     * @description 清空占位符线程local
     *
     * @author zhangqi
     * @date 2023/6/16 16:43
     * @initVersion 3.0.1.300
     */
    public static void removePlaceholderThreadLocal() {
        PLACEHOLDER_THREAD_LOCAL.remove();
        PLACEHOLDER_ERR_THREAD_LOCAL.remove();
        COUPLING_TABLE_FIELD.remove();
        INCLUDE_DISABLED_TABLE_FIELDS.remove();
    }

    /**
     * @description 获得指定类型的占位符
     * @param value 待取值的占位符
     * @return 获得的占位符对象
     * @throws ExceptionPack 获得异常
     *
     * @author zhangqi
     * @date 2023/6/18 15:37
     * @initVersion 3.0.1.300
     */
    public T getFieldBasePositionInfoByType(String value) throws ExceptionPack {
        try {
            AbstractFieldBasePositionInfo fieldBasePositionInfo = AssertInjecter
                .inject(PLACEHOLDER_THREAD_LOCAL.get().get(value), "fieldBasePositionInfo")
                .and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndGet(ExceptionMsg.builder(
                    "Placeholder cache no, the previous unified query field information is incomplete, placeholder: {}",
                    value).build());
            if (getGenericityClass(AbstractFieldBasePositionInfoResolver.class).isInstance(fieldBasePositionInfo)) {
                @SuppressWarnings("unchecked")
                T t = (T)fieldBasePositionInfo;
                return t;
            }
            throw new PlaceholderException(
                ExceptionMsg.builder("Placeholder parser selection error, Placeholder actual type: {}",
                    fieldBasePositionInfo.getClass()).build());
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("A placeholder of the specified type could not be obtained").build());
        }
    }

    /**
     * @description 获得指定类型的占位符
     * @param value 待取值的占位符
     * @return 获得的占位符对象
     * @throws ExceptionPack 获得异常
     *
     * @author zhangqi
     * @date 2023/6/18 15:37
     * @initVersion 3.0.1.300
     */
    public T getFieldBasePositionInfoByTypeUncheck(String value) throws ExceptionPack {
        try {
            AbstractFieldBasePositionInfo fieldBasePositionInfo = PLACEHOLDER_THREAD_LOCAL.get().get(value);
            if (getGenericityClass(AbstractFieldBasePositionInfoResolver.class).isInstance(fieldBasePositionInfo)) {
                @SuppressWarnings("unchecked")
                T t = (T)fieldBasePositionInfo;
                return t;
            }
            throw new PlaceholderException(
                ExceptionMsg.builder("Placeholder parser selection error, Placeholder actual type: {}",
                    fieldBasePositionInfo.getClass()).build());
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("A placeholder of the specified type could not be obtained").build());
        }
    }

    /**
     * @description 获得占位符
     * @param value 占位符值
     * @return 获得的占位符
     * @throws ExceptionPack 获得异常
     *
     * @author zhangqi
     * @date 2023/6/18 16:11
     * @initVersion 3.0.1.300
     */
    public static AbstractFieldBasePositionInfo getFieldBasePositionInfo(String value) throws ExceptionPack {
        try {
            return AssertInjecter.inject(PLACEHOLDER_THREAD_LOCAL.get().get(value), "")
                .and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndGet(ExceptionMsg.builder(
                    "Placeholder cache no, the previous unified query field information is incomplete, placeholder: {}",
                    value).build());
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("A placeholder of the specified type could not be obtained").build());
        }
    }

    /**
     * @description 获得占位符正则
     * @return 占位符正则
     *
     * @author zhangqi
     * @date 2023/6/14 14:53
     * @initVersion 3.0.1.300
     */
    public abstract Pattern getPlaceholderPattern();

    /**
     * @description 匹配正则
     * @param value 待匹配的值
     * @return 匹配结果
     *
     * @author zhangqi
     * @date 2023/6/14 14:51
     * @initVersion 3.0.1.300
     */
    public boolean match(String value) {
        return getPlaceholderPattern().matcher(value).matches();
    }

    /**
     * @description 解析占位符 to FieldCacheInfo
     * @param values 待解析的值
     * @return 解析出的FieldCacheInfo
     * @exception ExceptionPack 解析异常
     *
     * @author zhangqi
     * @date 2023/6/15 15:29
     * @initVersion 3.0.1.300
     */
    protected abstract List<FieldCacheInfo> resolvePlaceholderToFieldCacheInfo(String values) throws ExceptionPack;

    /**
     * @description 批量解析占位符 to FieldCacheInfo
     * @param values 待解析的集合 [可能传入不可更改集合]
     * @return 解析出的FieldCacheInfo集合
     * @throws ExceptionPack 解析异常
     *
     * @author zhangqi
     * @date 2023/6/16 11:47
     * @initVersion 3.0.1.300
     */
    protected List<FieldCacheInfo> resolvePlaceholderToFieldCacheInfos(List<String> values) throws ExceptionPack {
        List<FieldCacheInfo> result = new ArrayList<>();
        for (String value : values) {
            result.addAll(resolvePlaceholderToFieldCacheInfo(value));
        }
        return result;
    }

    /**
     * @description 解析不定占位符
     * @param values 待解析的不定占位符集合
     * @return 解析出的占位符
     * @throws ExceptionPack 解析异常
     *
     * @author zhangqi
     * @date 2023/6/14 14:24
     * @initVersion 3.0.1.300
     */
    abstract Map<String, T> analysisFieldPlaceholders(List<String> values,
        Map<String, FieldLogicInfo> fieldLogicInfoMap) throws ExceptionPack;

    /**
     * @description 解析占位符并更新占位符线程local
     * @param values 待解析的值
     * @param ownedEnterpriseCode 使用企业编号
     * @throws ExceptionPack 解析异常
     *
     * @author zhangqi
     * @date 2023/6/16 16:47
     * @initVersion 3.0.1.300
     */
    public static void analysisFieldPlaceholdersFlushCache(TableFieldFunction tableFieldFunction,
        TableFunction tableFunction, List<String> values, Long ownedEnterpriseCode) throws ExceptionPack {
        try {
            AssertInjecter.inject(PLACEHOLDER_THREAD_LOCAL.get(), "").and(CollUtil::isEmpty)
                .judge(ExceptionMsg.builder("The placeholder cache cannot be initialized repeatedly, size: {}",
                    PLACEHOLDER_THREAD_LOCAL.get().size()).build());
            AssertInjecter.inject(PLACEHOLDER_ERR_THREAD_LOCAL.get(), "").and(CollUtil::isEmpty)
                .judge(ExceptionMsg.builder("The placeholder err cache cannot be initialized repeatedly, size: {}",
                    PLACEHOLDER_ERR_THREAD_LOCAL.get().size()).build());
            if (CollUtil.isEmpty(values)) {
                return;
            }
            Map<String, LocalFieldPlaceholder> tokenPlaceholder = TokenPlaceholder.INSTANCE.getTokenPlaceholder();
            List<String> distinctValues = values.stream().distinct().collect(Collectors.toList());
            distinctValues.removeIf(
                next -> tokenPlaceholder.values().stream().anyMatch(p -> p.generatePlaceholder().equals(next)));
            // 本地
            List<String> localPlaceholderValueListUnmodifiable = distinctValues.stream().distinct()
                .filter(p -> LocalAbstractFieldPlaceholderResolver.getInstance().match(p)).toList();
            List<FieldCacheInfo> allFieldCacheInfo = new ArrayList<>(LocalAbstractFieldPlaceholderResolver.getInstance()
                .resolvePlaceholderToFieldCacheInfos(localPlaceholderValueListUnmodifiable));
            // 数据库
            List<String> dbPlaceholderValueListUnmodifiable = distinctValues.stream().distinct()
                .filter(p -> DBAbstractFieldPlaceholderResolver.getInstance().match(p)).toList();
            List<FieldCacheInfo> fieldCacheInfos = DBAbstractFieldPlaceholderResolver.getInstance()
                .resolvePlaceholderToFieldCacheInfos(dbPlaceholderValueListUnmodifiable);
            // 过滤数据库占位符中的token占位符
            // 先简单这么过滤, 后面重构规整token占位符再调整
            List<FieldCacheInfo> filtedFieldCacheList = fieldCacheInfos
                .stream().filter(p -> p.tableCode != 111111111111111111L
                    && p.tableCode != ENTERPRISE_VIRTUAL_DM_TABLE.getValue() && p.getTableCode() != 333333333333333333L)
                .toList();

            Map<String,
                FieldCacheInfo> filterTokenList = fieldCacheInfos.stream()
                    .filter(p -> p.tableCode == 111111111111111111L
                        || p.tableCode == ENTERPRISE_VIRTUAL_DM_TABLE.getValue() || p.tableCode == 333333333333333333L)
                    .distinct().collect(Collectors.toMap(FieldCacheInfo::getPlaceholderValue, Function.identity()));

            allFieldCacheInfo.addAll(filtedFieldCacheList);

            // 没有校验value一定是占位符
            Map<String, FieldLogicInfo> fieldLogicInfoMap =
                generateFieldLogicInfos(tableFieldFunction, tableFunction, allFieldCacheInfo, ownedEnterpriseCode);

            for (Map.Entry<String, LocalFieldPlaceholder> entry : TokenPlaceholder.INSTANCE.getTokenPlaceholder()
                .entrySet()) {
                LocalFieldPlaceholder localFieldPlaceholder = entry.getValue();
                FieldCacheInfo fieldCacheInfo = filterTokenList.get(entry.getKey());
                if (fieldCacheInfo != null) {
                    fieldLogicInfoMap.put(fieldCacheInfo.generatePlaceholderKey(),
                        new FieldLogicInfo(localFieldPlaceholder.getFieldCode(), localFieldPlaceholder.getName(),
                            localFieldPlaceholder.getFieldLogicType(), localFieldPlaceholder.getAdditionalValue(),
                            localFieldPlaceholder.isNullable()));
                }
            }

            // 存在解析错误的占位符
            Map<String, String> errMap = PLACEHOLDER_ERR_THREAD_LOCAL.get();
            AssertInjecter.inject(errMap, "errMap").and(CollUtil::isEmpty)
                .judge(ExceptionMsg.builder("placeholder for a resolution error exists, errInfo: {}", errMap.toString())
                    .msgView(errMap.toString()).build());
            Map<String, LocalFieldPlaceholder> localFieldPlaceholderMap = LocalAbstractFieldPlaceholderResolver
                .getInstance().analysisFieldPlaceholders(localPlaceholderValueListUnmodifiable, fieldLogicInfoMap);
            Map<String, DbFieldPlaceholder> dbFieldPlaceholderMap = DBAbstractFieldPlaceholderResolver.getInstance()
                .analysisFieldPlaceholders(dbPlaceholderValueListUnmodifiable, fieldLogicInfoMap);
            Map<String, AbstractFieldBasePositionInfo> fieldBasePositionInfoMap = getPlaceholderThreadLocal().get();
            fieldBasePositionInfoMap.putAll(localFieldPlaceholderMap);
            fieldBasePositionInfoMap.putAll(dbFieldPlaceholderMap);
            fieldBasePositionInfoMap.putAll(tokenPlaceholder);
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The placeholder could not be obtained").build());
        }
    }

    /**
     * @description 生成字段占位符
     * @param fieldCacheInfoList 待生成占位符的字段集合
     * @param ownedEnterpriseCode 试用企业标识
     * @return 生成的结果
     * @throws ExceptionPack 生成异常
     *
     * @author zhangqi
     * @date 2023/6/15 15:13
     * @initVersion 3.0.1.300
     */
    private static Map<String, FieldLogicInfo> generateFieldLogicInfos(TableFieldFunction tableFieldFunction,
        TableFunction tableFunction, List<FieldCacheInfo> fieldCacheInfoList, Long ownedEnterpriseCode)
        throws ExceptionPack {
        try {
            if (CollUtil.isEmpty(fieldCacheInfoList)) {
                return new HashMap<>();
            }
            FieldCacheInfo.checkLogic(fieldCacheInfoList);
            // 添加主键字段逻辑信息
            Map<String, FieldLogicInfo> virtualFields =
                getTablePrimaryKeyAndNameLocalFieldPlaceholder(tableFunction, fieldCacheInfoList, ownedEnterpriseCode);
            Map<String, FieldLogicInfo> result = new HashMap<>(virtualFields);
            // 数据库虚拟字段会在这之前被过滤掉
            List<Long> fieldCodeListUnmodifiable =
                fieldCacheInfoList.stream().map(FieldCacheInfo::getFieldCode).distinct().toList();
            // 数据库
            boolean includeDisabledTableFields = includeDisabledTableFields().get(); // 是否包含已停用的表和字段(这边要跨服务了，接力一下)
            List<TableFieldModel> startedFields =
                tableFieldFunction.getStartedFieldsByCodes(fieldCodeListUnmodifiable, includeDisabledTableFields);
            Map<Long, TableFieldModel> moduleTableFieldPpcDTOMap =
                startedFields.stream().collect(Collectors.toMap(TableFieldModel::getFieldCode, Function.identity()));

            CouplingTableField couplingTableField = getCouplingTableField().get();
            if (couplingTableField.isNeedPut()) {
                // startedFields.stream().collect(Collectors.groupingBy(TableFieldModel::getTableCode)).forEach((tableCode,
                // fieldModels) ->
                // tableFields.getTableFields().put(tableCode,
                // fieldModels.stream().map(TableFieldModel::getFieldCode).collect(Collectors.toSet())));
                couplingTableField.setCouplingTableCodes(
                    startedFields.stream().map(TableFieldModel::getTableCode).distinct().collect(Collectors.toList()));
                couplingTableField.setCouplingFieldCodes(new ArrayList<>(moduleTableFieldPpcDTOMap.keySet()));

                if (CollectionUtil.isNotEmpty(virtualFields)) {
                    // 若只关联了某张表的虚拟主键或署名虚拟字段，也要将表code放进去，需要验证其是否已启用
                    virtualFields.values().stream().map(FieldLogicInfo::getAdditionalValue).map(Long::valueOf)
                        .distinct().filter(v -> !couplingTableField.getCouplingTableCodes().contains(v))
                        .forEach(v -> couplingTableField.getCouplingTableCodes().add(v));
                }
            }

            Map<String, String> placeholderErr = PLACEHOLDER_ERR_THREAD_LOCAL.get();
            Iterator<FieldCacheInfo> fieldCacheInfoIterator = fieldCacheInfoList.iterator();
            while (fieldCacheInfoIterator.hasNext()) {
                FieldCacheInfo next = fieldCacheInfoIterator.next();
                TableFieldModel moduleTableField = moduleTableFieldPpcDTOMap.get(next.getFieldCode());
                if (moduleTableField == null) {
                    placeholderErr.put(next.generatePlaceholderKey(), "字段查询不合规");
                    fieldCacheInfoIterator.remove();
                    continue;
                }
                if (moduleTableField.getTableCode() != next.getTableCode()) {
                    placeholderErr.put(next.generatePlaceholderKey(), "字段表编号不对");
                    fieldCacheInfoIterator.remove();
                    continue;
                }
                if (next.getPlaceholderType().equals(PlaceholderLogicTypeEnum.UNIQUE)
                    && moduleTableField.getIndexType() != 1) {
                    placeholderErr.put(next.generatePlaceholderKey(), "唯一索引不对应");
                    fieldCacheInfoIterator.remove();
                    continue;
                }
                if ((next.getPlaceholderType().equals(PlaceholderLogicTypeEnum.DB)
                    || next.getPlaceholderType().equals(PlaceholderLogicTypeEnum.LOCAL_INSERT))
                    && next.isNullAble() != moduleTableField.isNullable()) {
                    placeholderErr.put(next.generatePlaceholderKey(), "数据库占位符和本地insert占位符的可空标识要和dm保持一致");
                    fieldCacheInfoIterator.remove();
                    continue;
                }
                FieldLogicInfo fieldLogicInfo = FieldLogicTypeEnum.obtainFieldLogicInfo(moduleTableField);
                if (next.setFlag) {
                    if (FieldLogicTypeEnum.ENUM.equals(fieldLogicInfo.getFieldLogicType())) {
                        fieldLogicInfo.setFieldLogicType(FieldLogicTypeEnum.ENUM_SET);
                    }
                    if (FieldLogicTypeEnum.ASSOCIATION.equals(fieldLogicInfo.getFieldLogicType())) {
                        fieldLogicInfo.setFieldLogicType(FieldLogicTypeEnum.ASSOCIATION_SET);
                    }
                }
                result.put(next.generatePlaceholderKey(), fieldLogicInfo);
            }
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Failed to generate field placeholders").build());
        }
    }

    /**
     * @description 生成企业虚拟字段逻辑对象
     * @param fieldCacheInfoList 待处理的字段
     * @return 企业虚拟字段map集合
     *
     * @author zhangqi
     * @date 2023/6/15 14:01
     * @initVersion 3.0.1.300
     */
    // private static Map<String, FieldLogicInfo>
    // generateEnterpriseVirtualTableField(List<FieldCacheInfo> fieldCacheInfoList) {
    // Map<String, FieldLogicInfo> result = new HashMap<>();
    // Iterator<FieldCacheInfo> fieldCacheInfoIterator = fieldCacheInfoList.iterator();
    // Map<String, String> placeholderErr = PLACEHOLDER_ERR_THREAD_LOCAL.get();
    // while (fieldCacheInfoIterator.hasNext()) {
    // FieldCacheInfo next = fieldCacheInfoIterator.next();
    // if (next.getTableCode() != GlobalDynamicalMagicValue.ENTERPRISE_VIRTUAL_DM_TABLE.getValue()) {
    // continue;
    // }
    // if (Boolean.TRUE.equals(next.nullAble)) {
    // placeholderErr.put(next.generatePlaceholderKey(), "企业虚拟占位符必须非空");
    // fieldCacheInfoIterator.remove();
    // continue;
    // }
    // if (next.getFieldCode() == GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue()) {
    // fieldCacheInfoIterator.remove();
    // result.put(next.generatePlaceholderKey(), ENTERPRISE_CODE);
    // continue;
    // }
    // if (next.getFieldCode() == GlobalDynamicalMagicValue.NAME_VIRTUAL_CODE.getValue()) {
    // fieldCacheInfoIterator.remove();
    // if (next.getPlaceholderType().equals(PlaceholderLogicTypeEnum.UNIQUE)) {
    // placeholderErr.put(next.generatePlaceholderKey(), "企业虚拟名称占位符不能是唯一索引");
    // continue;
    // }
    // result.put(next.generatePlaceholderKey(), ENTERPRISE_NAME);
    // continue;
    // }
    // placeholderErr.put(next.generatePlaceholderKey(), "不合法的企业虚拟占位符");
    // fieldCacheInfoIterator.remove();
    // }
    // return result;
    // }

    /**
     * @description 获得表的主键虚拟逻辑对象
     * @param fieldCacheInfoList 待处理的字段
     * @param ownedEnterpriseCode 使用企业编号
     * @return 表的主键本地占位符
     * @throws ExceptionPack 获得异常
     *
     * @author zhangqi
     * @date 2023/6/14 19:01
     * @initVersion 3.0.1.300
     */
    private static Map<String, FieldLogicInfo> getTablePrimaryKeyAndNameLocalFieldPlaceholder(
        TableFunction tableFunction, List<FieldCacheInfo> fieldCacheInfoList, Long ownedEnterpriseCode)
        throws ExceptionPack {
        try {
            Map<String, FieldLogicInfo> result = new HashMap<>();
            // List<Long> tableCodeListUnmodifiable = fieldCacheInfoList.stream()
            // .filter(p -> p.getFieldCode() == GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue()
            // || p.getFieldCode() == GlobalDynamicalMagicValue.NAME_VIRTUAL_CODE.getValue())
            // .map(FieldCacheInfo::getTableCode).toList();
            Map<String, String> placeholderErr = PLACEHOLDER_ERR_THREAD_LOCAL.get();
            // List<Long> tableCodesUnmodifiable =
            // MODULE_TABLE_SERVICE.verifyTableWithEnterprise(tableCodeListUnmodifiable, ownedEnterpriseCode);
            // if (!CollUtil.isEmpty(tableCodesUnmodifiable)) {
            // tableCodesUnmodifiable.forEach(p -> placeholderErr.put(String.valueOf(p), "表未启动或企业无权使用"));
            // }
            Map<Long,
                String> tableNameList = tableFunction.getTableNames(fieldCacheInfoList.stream()
                    .filter(p -> p.getFieldCode() == GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue())
                    .map(FieldCacheInfo::getTableCode).toList());
            Iterator<FieldCacheInfo> fieldCacheInfoIterator = fieldCacheInfoList.iterator();
            while (fieldCacheInfoIterator.hasNext()) {
                FieldCacheInfo next = fieldCacheInfoIterator.next();
                long tableCode = next.getTableCode();
                if (next.getFieldCode() != GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue()
                    && next.getFieldCode() != GlobalDynamicalMagicValue.NAME_VIRTUAL_CODE.getValue()) {
                    continue;
                }
//                if (next.nullAble) {
//                    placeholderErr.put(next.generatePlaceholderKey(), "虚拟字段不能为空");
//                    fieldCacheInfoIterator.remove();
//                    continue;
//                }
                if (next.getFieldCode() == GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue()) {
                    result.put(next.generatePlaceholderKey(),
                        new FieldLogicInfo(next.getFieldCode(), tableNameList.get(tableCode) + "编号",
                            FieldLogicTypeEnum.ASSOCIATION, String.valueOf(tableCode), false));
                    fieldCacheInfoIterator.remove();
                    continue;
                }
                // 目前dm 不采用 NAME_VIRTUAL_CODE 名称虚拟code
                if (next.getFieldCode() == GlobalDynamicalMagicValue.NAME_VIRTUAL_CODE.getValue()) {
                    result.put(next.generatePlaceholderKey(), new FieldLogicInfo(next.getFieldCode(), "员工姓名",
                        FieldLogicTypeEnum.VARCHAR, String.valueOf(tableCode), false));
                    fieldCacheInfoIterator.remove();
                }
            }
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder(
                    "Unable to obtain table primary key placeholder, fieldCacheInfoList: {}, ownedEnterpriseCode: {}",
                    fieldCacheInfoList, ownedEnterpriseCode).build());
        }
    }

    /**
     * @description 从占位符角度判断真实值是否可空
     * @important 没有校验占位符本身是否合法
     * @param value 待校验的占位符
     * @return 判断的结果
     * @throws ExceptionPack 判断异常
     *
     * @author zhangqi
     * @date 2023/12/6 15:13
     * @initVersion 3.0.1.300
     */
    public abstract boolean realValueNullableFlag(String value) throws ExceptionPack;
}