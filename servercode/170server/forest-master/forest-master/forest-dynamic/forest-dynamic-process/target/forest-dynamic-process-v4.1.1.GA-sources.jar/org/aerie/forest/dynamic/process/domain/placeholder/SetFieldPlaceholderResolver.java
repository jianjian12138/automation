/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;

import java.util.*;

import static org.aerie.forest.dynamic.process.domain.placeholder.GlobalPlaceholderPatternMagicValue.*;

/**
 * @description 集合字段占位符解析器
 *
 * @author nimj
 * @date 2023/6/24
 */
public class SetFieldPlaceholderResolver {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private SetFieldPlaceholderResolver() {}

    /**
     * @description 静态内部类单例
     */
    private static final class ForestInstance {
        private static final SetFieldPlaceholderResolver SET_FIELD_PLACEHOLDER_RESOLVER =
            new SetFieldPlaceholderResolver();
    }

    public static SetFieldPlaceholderResolver getInstance() {
        return ForestInstance.SET_FIELD_PLACEHOLDER_RESOLVER;
    }

    public boolean match(String value) {
        return SET_PLACEHOLDER.getValue().matcher(value).matches();
    }

    public List<String> resolve2Placeholders(String value) {
        try {
            List<String> result = new ArrayList<>();

            SetFieldPlaceholder setFieldPlaceholder = resolve2SetFieldPlaceholder(value);
            result.add(setFieldPlaceholder.getPre());
            result.add(setFieldPlaceholder.getPost());

            return result;
        } catch (Exception e) {
            // 这里不抛出ExceptionPack异常，否则上层多个地方需要跟着改
            throw new RuntimeException(String.format("集合占位符解析失败： %s", value), e);
        }
    }

    public SetFieldPlaceholder resolve2SetFieldPlaceholder(String value) throws ExceptionPack {
        try {
            return OBJECT_MAPPER.readValue(value.substring(1), new TypeReference<>() {});
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("集合占位符解析失败, value: {}").build());
        }
    }

}
