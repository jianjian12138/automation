/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare;

import java.util.List;

import cn.hutool.core.util.StrUtil;
import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.calculate.CalculateException;
import org.aerie.forest.core.brick.exception.compare.CompareException;
import org.aerie.forest.core.brick.function.generatethrowable.GenerateException;
import org.aerie.forest.core.brick.magicvalue.GlobalPatternMagicValue;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.BaseOperatorEnum;
import org.aerie.forest.dynamic.process.domain.calculate.processor.OperationNodeTransverter;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractComparable;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractNumericalValue;
import org.aerie.forest.dynamic.process.domain.compare.comparable.BigDecimalValue;
import org.aerie.forest.dynamic.process.domain.compare.comparable.CalculateValue;
import org.aerie.forest.dynamic.process.domain.compare.operator.number.NumericalIsNull;
import org.aerie.forest.dynamic.process.domain.compare.operator.number.NumericalNotNull;
import org.aerie.forest.dynamic.process.domain.placeholder.GlobalPlaceholderFixedPatternMagicValue;
import org.aerie.forest.dynamic.process.domain.placeholder.GlobalPlaceholderPatternMagicValue;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import cn.hutool.core.util.RandomUtil;

/**
 * @description 数字符号
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/17 9:50
 * @version 3.0.1.300
 */
public abstract class AbstractNumberSymbol extends AbstractCompareSymbol<AbstractNumericalValue<?>> {

    /**
     * @description jackson
     */
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    static {
        OBJECT_MAPPER.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
    }

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     * @param operatorName 符号名称
     * @param paramNullableFlag 参数可空标识
     * @param flag 标识
     *
     * @author zhangqi
     * @date 2023/5/17 9:49
     * @initVersion 3.0.1.300
     */
    protected AbstractNumberSymbol(String displaySymbol, String operatorName, boolean paramNullableFlag, String flag) {
        super(displaySymbol, operatorName, FieldLogicTypeEnum.NUMBER, paramNullableFlag, flag);
    }

    @Override
    public AbstractNumericalValue<?> generateComparable(String value) throws ExceptionPack {
        try {
            if (NULL_FLAG.equals(value)) {
                return null;
            }
            if (StrUtil.isBlank(value)) {
                return new BigDecimalValue(null);
            }
            if (GlobalPatternMagicValue.REAL_NUMBER.getValue().matcher(value).matches()) {
                return new BigDecimalValue(value);
            }
            return new CalculateValue(OperationNodeTransverter.getInstance()
                .convert(OBJECT_MAPPER.readValue(value, new TypeReference<>() {})));
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to map number fields").build());
        }
    }

    @Override
    public String checkComparable(String value) throws ExceptionPack {
        try {
            if (NULL_FLAG.equals(value)) {
                return null;
            }
            if (GlobalPlaceholderFixedPatternMagicValue.FIXED_VALUE_NUMBER.getValue().matcher(value).matches()) {
                return null;
            }
            if (verifyPlaceholderRealFieldType(value, fieldLogicTypeEnum, true) != null) {
                return null;
            }
            if (GlobalPlaceholderPatternMagicValue.CALCULATION_PLACEHOLDER.getValue().matcher(value).matches()) {
                String substring = value.substring(2, value.length() - 1);
                List<String> formula = OBJECT_MAPPER.readValue(substring, new TypeReference<>() {});
                int index = 0;
                while (index < formula.size()) {
                    String formulaValue = formula.get(index);
                    // 占位符的数据在设计阶段无法获得, 将由随机数替代
                    if (verifyPlaceholderRealFieldType(formulaValue, fieldLogicTypeEnum, true) != null) {
                        // 占位替代
                        formula.set(index, String.valueOf(RandomUtil.getSecureRandom().nextDouble()));
                        continue;
                    }
                    // 计算器中除了上述占位符代替的真实值以外, 只能是数字和运算符
                    AssertInjecter.inject(formulaValue, "formulaValue")
                        .and(p -> GlobalPatternMagicValue.REAL_NUMBER.getValue().matcher(formulaValue).matches()).or()
                        .and(p -> BaseOperatorEnum.getBaseOperatorEnum(formulaValue) != null).judge(
                            (GenerateException<CalculateException>)(embeddedValue, exception,
                                exceptionMsg) -> new CalculateException(exceptionMsg),
                            "Invalid formula argument, formulaValue: {}", formulaValue);
                    index++;
                }
                OperationNodeTransverter.getInstance().convert(formula);
                return null;
            }
            throw new CompareException(ExceptionMsg.builder("Cannot match a number value: {}", value).build());
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to map number fields").build());
        }
    }

    /**
     * @description 获得判空符号
     * @return 判空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:40
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public final AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNullSymbol() {
        return NumericalIsNull.getInstance();
    }

    /**
     * @description 获得判非空符号
     * @return 判非空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:41
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public final AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNotNullSymbol() {
        return NumericalNotNull.getInstance();
    }
}
