/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */
/**
 * @description 动态流程业务 - 领域 - 基本计算 - 运算符
 *
 * @author zhangqi
 * @organization aerie
 * @date 2022/8/22 16:52
 * @version v2.2.1.RC
 */
package org.aerie.forest.dynamic.process.domain.calculate.operator;