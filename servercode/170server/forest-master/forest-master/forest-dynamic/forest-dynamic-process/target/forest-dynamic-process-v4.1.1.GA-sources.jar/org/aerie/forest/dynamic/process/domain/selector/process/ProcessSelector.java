/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector.process;

import java.io.Serial;
import java.io.Serializable;
import java.util.Map;

import org.aerie.forest.core.brick.domain.view.CodeMapName;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.selector.UnselectedException;
import org.aerie.forest.dynamic.process.domain.selector.AbstractSelector;
import org.aerie.forest.dynamic.process.domain.selector.ValidationParam;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @description 流程选择器
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/6/25 9:35
 * @version v3.1.1.GA
 */
public final class ProcessSelector extends AbstractSelector<SelectMapProcessNode, CodeMapName> implements Serializable {

    @Serial
    private static final long serialVersionUID = -1045568113899528560L;

    @JsonIgnore
    @Override
    public CodeMapName getResult(Map<String, String> placeholderValueMap) throws ExceptionPack {
        try {
            return super.getResult(placeholderValueMap);
        } catch (UnselectedException e) {
            // 没有命中返回null
            return null;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The selector cannot get the result").build());
        }
    }

    @Override
    protected ProcessSelector detailedValidation(ValidationParam validationParam) throws ExceptionPack {
        try {
            super.detailedValidation(validationParam);
            return this;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The Turnoff Selector is invalid").build());
        }
    }
}
