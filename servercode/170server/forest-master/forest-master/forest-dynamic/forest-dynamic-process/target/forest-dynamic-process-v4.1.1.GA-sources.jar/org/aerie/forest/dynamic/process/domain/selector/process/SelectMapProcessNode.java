/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector.process;

import org.aerie.forest.core.brick.domain.view.CodeMapName;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.compare.processor.ComparisonExpression;
import org.aerie.forest.dynamic.process.domain.selector.AbstractSelectNode;
import org.aerie.forest.dynamic.process.domain.selector.ValidationParam;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/**
 * @description 流程选择节点
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/6/25 9:27
 * @version v3.1.1.GA
 */
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public final class SelectMapProcessNode extends AbstractSelectNode<CodeMapName> {

    /**
     * @description Constructor
     * @param value 选择节点输出结果
     * @param comparisonExpressions 比较器集合 需要单独的处理器校验
     *
     * @author zhangqi
     * @date 2024/6/26 18:42
     * @initVersion v3.1.1.GA
     */
    public SelectMapProcessNode(@JsonProperty("value") CodeMapName value,
        @JsonProperty("comparisonExpressions") List<ComparisonExpression> comparisonExpressions) {
        super(value, comparisonExpressions);
    }

    @Override
    protected SelectMapProcessNode detailedValidation(ValidationParam validationParam) throws ExceptionPack {
        try {
            super.detailedValidation(validationParam);
            return this;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Selector node validation failed").build());
        }
    }
}
