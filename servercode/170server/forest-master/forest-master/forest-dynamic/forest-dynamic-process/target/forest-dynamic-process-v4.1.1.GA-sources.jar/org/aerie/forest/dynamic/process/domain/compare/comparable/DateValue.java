/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.pact.time.TimeFormatEnum;
import org.aerie.forest.core.brick.pact.time.TimeTypeEnum;

/**
 * @description 日期
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 14:23
 * @version 3.0.1.300
 */
public final class DateValue extends AbstractTimeValue<LocalDate> {

    /**
     * @description Constructor
     * @param value 值
     *
     * @author zhangqi
     * @date 2023/5/18 14:31
     * @initVersion 3.0.1.300
     */
    DateValue(String value, TimeFormatEnum timeFormatEnum) {
        super(value, timeFormatEnum);
    }

    @Override
    public LocalDate getComparableValue(boolean canBeNull) throws ExceptionPack {
        try {
            if (canBeNull && value == null) {
                return null;
            }
            AssertInjecter.inject(value, "value").and(ObjectJudgementShelf.NOT_NULL).or().and(() -> canBeNull)
                .judge(ExceptionMsg.builder("The value to be compared cannot be null").build());
            return LocalDate.parse(value,
                DateTimeFormatter.ofPattern(
                    AssertInjecter.inject(timeFormat, "timeFormat").and(p -> TimeTypeEnum.checkTimeType(p, 1))
                        .judgeAndGet(ExceptionMsg.builder("The date format is not valid").build()).getTimeFormat()));
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg
                    .builder("The date could not be obtained, value: {}, format: {}", value, timeFormat.getTimeFormat())
                    .build());
        }
    }
}
