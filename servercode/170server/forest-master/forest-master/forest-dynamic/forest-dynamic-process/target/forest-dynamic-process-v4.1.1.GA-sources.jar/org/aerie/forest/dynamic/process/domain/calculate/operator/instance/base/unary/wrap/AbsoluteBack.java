/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.wrap;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.calculate.ParamPosition;

/**
 * @description 后绝对值
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/20 15:11
 * @version 3.0.1.300
 */
public final class AbsoluteBack extends AbstractWrapUnaryOperator {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 后绝对值
         */
        private static final AbsoluteBack ABSOLUTE_BACK = new AbsoluteBack("|");
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static AbsoluteBack getInstance() {
        return INSTANCE.ABSOLUTE_BACK;
    }

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     *
     * @author zhangqi
     * @date 2023/4/20 11:43
     * @initVersion 3.0.1.300
     */
    private AbsoluteBack(String displaySymbol) {
        super(displaySymbol, "Absolute - back", 9);
    }

    @Override
    public AbstractWrapUnaryOperator getMirrorWrapOperator() {
        return AbsoluteFront.getInstance();
    }

    @Override
    protected BigDecimal calculateResult(int scale, BigDecimal param) throws ExceptionPack {
        return param.abs().setScale(scale, RoundingMode.HALF_UP);
    }

    @Override
    public ParamPosition getParamPosition() {
        return ParamPosition.LEFT;
    }

}
