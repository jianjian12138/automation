/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate;

import java.math.BigDecimal;

import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractOperator;

import lombok.Getter;

/**
 * @description 计算结点
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/26 10:06
 * @version 3.0.1.300
 */
@Getter
public enum CalculateNodeEnum {

    /**
     * @description 高精度浮点
     */
    BIG_DECIMAL(BigDecimal.class),

    /**
     * @description 运算符
     */
    OPERATOR(AbstractOperator.class);

    /**
     * @description 类型
     */
    private final Class<?> zclass;

    /**
     * @description Constructor
     * @param zclass 类型
     *
     * @author zhangqi
     * @date 2023/4/26 10:10
     * @initVersion 3.0.1.300
     */
    CalculateNodeEnum(Class<?> zclass) {
        this.zclass = zclass;
    }

    /**
     * @description 判断是否属于计算结点
     * @param zclass 待校验的类型
     * @return 判断结果
     *
     * @author zhangqi
     * @date 2023/4/26 10:50
     * @initVersion 3.0.1.300
     */
    public static boolean isCalculateNode(Class<?> zclass) {
        for (CalculateNodeEnum calculateNodeEnum : CalculateNodeEnum.values()) {
            if (calculateNodeEnum.zclass.equals(zclass)) {
                return true;
            }
        }
        return false;
    }
}
