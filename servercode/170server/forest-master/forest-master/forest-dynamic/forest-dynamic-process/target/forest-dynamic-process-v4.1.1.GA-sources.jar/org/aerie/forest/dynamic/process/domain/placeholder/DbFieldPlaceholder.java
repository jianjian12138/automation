/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * @description 本地字段占位符
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/29 15:10
 * @version 3.0.1.300
 */
@Getter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DbFieldPlaceholder extends AbstractFieldBasePositionInfo {

    /**
     * @description 唯一索引字段编号
     */
    private final long uniqueIndexFieldCode;

    /**
     * @description 本地占位符
     */
    private final LocalFieldPlaceholder localFieldPlaceholder;

    /**
     * @description Constructor
     * @param tableCode 表编号
     * @param fieldCode 字段编号
     * @param name 字段名称
     * @param nullableFlag 可空标识
     * @param fieldLogicType 字段逻辑类型
     * @param additionalValue 附加属性
     *
     * @author zhangqi
     * @date 2023/6/14 17:37
     * @initVersion 3.0.1.300
     */
    public DbFieldPlaceholder(long tableCode, long fieldCode, String name, boolean nullableFlag,
        FieldLogicTypeEnum fieldLogicType, String additionalValue, long uniqueIndexFieldCode,
        LocalFieldPlaceholder localFieldPlaceholder) {
        super(tableCode, fieldCode, name, nullableFlag, fieldLogicType, additionalValue, false);
        this.uniqueIndexFieldCode = uniqueIndexFieldCode;
        this.localFieldPlaceholder = localFieldPlaceholder;
    }

    public DbFieldPlaceholder(long tableCode, long fieldCode, String name, boolean nullableFlag,  FieldLogicTypeEnum fieldLogicType,
        String additionalValue, long uniqueIndexFieldCode, LocalFieldPlaceholder localFieldPlaceholder, Integer status) {
        this(tableCode, fieldCode, name, nullableFlag, fieldLogicType, additionalValue, uniqueIndexFieldCode, localFieldPlaceholder);
    }

    /**
     * @description 浅相等, 必填标识可以不等
     * @param fieldBasePositionInfo 待比较的字段基础定位信息
     * @return 比较的结果
     *
     * @author zhangqi
     * @date 2023/5/30 21:26
     * @initVersion 3.0.1.300
     */
    @Override
    public boolean shallowEquals(AbstractFieldBasePositionInfo fieldBasePositionInfo) {
        if (!super.shallowEquals(fieldBasePositionInfo)
            || !(fieldBasePositionInfo instanceof DbFieldPlaceholder dbFieldPlaceholder)) {
            return false;
        }
        return this.uniqueIndexFieldCode == dbFieldPlaceholder.getUniqueIndexFieldCode()
            && this.localFieldPlaceholder.shallowEquals(dbFieldPlaceholder.getLocalFieldPlaceholder());
    }

    /**
     * @description 全等
     * @param fieldBasePositionInfo 待比较的字段基础定位信息
     * @return 比较结果
     *
     * @author zhangqi
     * @date 2023/5/30 21:22
     * @initVersion 3.0.1.300
     */
    @Override
    public boolean logicalEquals(AbstractFieldBasePositionInfo fieldBasePositionInfo) {
        if (!super.shallowEquals(fieldBasePositionInfo)
            || !(fieldBasePositionInfo instanceof DbFieldPlaceholder dbFieldPlaceholder)) {
            return false;
        }
        return this.uniqueIndexFieldCode == dbFieldPlaceholder.getUniqueIndexFieldCode()
            && this.localFieldPlaceholder.logicalEquals(dbFieldPlaceholder.getLocalFieldPlaceholder());
    }

    @Override
    public boolean isNullable() {
        return this.isNullableFlag() || this.localFieldPlaceholder.isNullable();
    }

    @Override
    public String generatePlaceholder() {
        return DBAbstractFieldPlaceholderResolver.getInstance().generatePlaceholder(String.valueOf(getTableCode()),
            String.valueOf(getFieldCode()), String.valueOf(getUniqueIndexFieldCode()), isNullable(),
            String.valueOf(getLocalFieldPlaceholder().getTableCode()),
            String.valueOf(getLocalFieldPlaceholder().getFieldCode()), getLocalFieldPlaceholder().isNullable());
    }

//    /**
//     * @description 判断字段逻辑类型, additionValue是否兼容
//     * @param dbFieldPlaceholder 待匹配的数据库占位符
//     * @return
//     *
//     * @author zhangqi
//     * @date 2023/6/12 15:34
//     * @initVersion 3.0.1.300
//     */
//    @Override
//    public boolean compatibleFieldLogicalType(DbFieldPlaceholder dbFieldPlaceholder) {
//
//        FieldLogicTypeEnum fieldLogicTypeA = super.getFieldLogicType();
//
//        FieldLogicTypeEnum fieldLogicTypeB = dbFieldPlaceholder.getFieldLogicType();
//
//        Boolean nullableA = isNullable();
//
//        Boolean nullableB = dbFieldPlaceholder.isNullable();
//
//        String additionalValueA = super.getAdditionalValue();
//
//        String additionalValueB = dbFieldPlaceholder.getAdditionalValue();
//
//        return FieldLogicTypeEnum.fieldLogicTypeAndAdditionValueMatch(fieldLogicTypeA, additionalValueA, nullableA,
//            fieldLogicTypeB, additionalValueB, nullableB);
//    }

//     /**
//     * @description 校验字段
//     * @return 查询到的字段传输对象
//     * @throws ExceptionPack 校验异常
//     *
//     * @author zhangqi
//     * @date 2023/5/31 15:30
//     * @initVersion 3.0.1.300
//     */
//     @Override
//     public ModuleTableFieldPpcDTO verifyField(Long ownedEnterpriseCode) throws ExceptionPack {
//     try {
//     ModuleTableFieldPpcDTO fieldPpcDTO = super.verifyField(ownedEnterpriseCode);
//     ErpAssert.INSTANCE.equalExpectValue(Objects.equals(fieldPpcDTO.isNullable(), this.isNullableFlag()), true,
//     "DbField Placeholder Nullable flags are inconsistent");
//     ModuleTableFieldPpcDTO localFieldPpcDTO = localFieldPlaceholder.verifyField(ownedEnterpriseCode);
//     ModuleTableFieldPpcDTO uniqueIndexField =
//     getFieldVerifyEnterpriseOwner(getTableCode(), uniqueIndexFieldCode, ownedEnterpriseCode);
//     ErpAssert.INSTANCE.equalExpectValue(uniqueIndexField.getFieldType().equals(localFieldPpcDTO.getFieldType()),
//     true,
//     "The type of the database placeholder unique field must be equal to the field type of the corresponding local
//     placeholder, localFieldType: {}, uniqueIndexFieldType: {}",
//     localFieldPpcDTO.getFieldType(), uniqueIndexField.getFieldType());
//     ErpAssert.INSTANCE.equalExpectValue(uniqueIndexField.getIndexType(), (short)1,
//     "The unique index field number is not valid");
//     return fieldPpcDTO;
//     } catch (Exception e) {
//     throw new ExceptionPack(e, "Validation field failed");
//     }
//     }
}
