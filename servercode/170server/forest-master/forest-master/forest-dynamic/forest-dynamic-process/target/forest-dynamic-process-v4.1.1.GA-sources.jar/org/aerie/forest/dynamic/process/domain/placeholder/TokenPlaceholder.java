/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import static org.aerie.forest.dynamic.common.domain.mv.GlobalDynamicalMagicValue.NAME_VIRTUAL_CODE;
import static org.aerie.forest.dynamic.common.domain.mv.GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import cn.hutool.core.util.StrUtil;
import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.placeholder.PlaceholderRuntimeException;
import org.aerie.forest.core.brick.function.generatethrowable.GenerateRuntimeException;
import org.aerie.forest.core.brick.pact.time.TimeFormatEnum;
import org.aerie.forest.core.brick.processor.datapenetrate.GlobalTokenPenetrate;
import org.aerie.forest.core.brick.processor.datapenetrate.InfoPenetrateProcessor;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;
import org.aerie.forest.dynamic.common.domain.TableFieldModel;
import org.aerie.forest.dynamic.common.domain.VirtualFieldEnum;
import org.aerie.forest.dynamic.common.domain.function.AssociatedValueInfo;
import org.aerie.forest.dynamic.common.domain.function.BaseTableFunction;
import org.aerie.forest.dynamic.common.domain.function.TableFieldFunction;
import org.aerie.forest.dynamic.common.domain.mv.GlobalDynamicalMagicValue;

import cn.hutool.core.collection.CollUtil;
import lombok.Setter;

/**
 * @description token占位符
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/11/27 11:05
 * @version 3.0.1.300
 */
public enum TokenPlaceholder {

    /**
     * @description 单例
     */
    INSTANCE;

    /**
     * @description 员工虚拟表编号
     */
    private static final String STAFF_VIRTUAL_TABLE_CODE = "111111111111111111";

    /**
     * @description 企业虚拟表编号
     */
    private static final String ENTERPRISE_VIRTUAL_TABLE_CODE = "222222222222222222";

    /**
     * @description 编号虚拟字段编号
     */
    private static final String CODE_VIRTUAL_FIELD_CODE =
        VirtualFieldEnum.CODE_VIRTUAL_FIELD_CODE.getVirtualFieldCodeValue();

    /**
     * @description 署名虚拟字段编号
     */
    private static final String SIGNATURE_VIRTUAL_FIELD_CODE =
        VirtualFieldEnum.SIGNATURE_VIRTUAL_FIELD_CODE.getVirtualFieldCodeValue();

    /**
     * @description 当前时间虚拟表编号
     */
    private static final String CURRENT_TIME_VIRTUAL_TABLE_CODE = "333333333333333333";

    /**
     * @description 部门虚拟表编号
     */
    private static final String DEPARTMENT_VIRTUAL_TABLE_CODE = "444444444444444444";

    /**
     * @description 岗位虚拟表编号
     */
    private static final String POST_VIRTUAL_TABLE_CODE = "555555555555555555";

    /**
     * @description 时间格式虚拟字段编号1 - yyyy-MM-dd HH:mm:ss
     */
    private static final String TIME_FORMAT_VIRTUAL_FIELD_CODE_1 =
        VirtualFieldEnum.TIME_FORMAT_VIRTUAL_FIELD_CODE_1.getVirtualFieldCodeValue();

    /**
     * @description 时间格式虚拟字段编号2 - yyyy-MM-dd HH:mm
     */
    private static final String TIME_FORMAT_VIRTUAL_FIELD_CODE_2 =
        VirtualFieldEnum.TIME_FORMAT_VIRTUAL_FIELD_CODE_2.getVirtualFieldCodeValue();

    /**
     * @description 时间格式虚拟字段编号3 - yyyy-MM-dd HH
     */
    private static final String TIME_FORMAT_VIRTUAL_FIELD_CODE_3 =
        VirtualFieldEnum.TIME_FORMAT_VIRTUAL_FIELD_CODE_3.getVirtualFieldCodeValue();

    /**
     * @description 时间格式虚拟字段编号4 - yyyy-MM-dd
     */
    private static final String TIME_FORMAT_VIRTUAL_FIELD_CODE_4 =
        VirtualFieldEnum.TIME_FORMAT_VIRTUAL_FIELD_CODE_4.getVirtualFieldCodeValue();

    /**
     * @description 时间格式虚拟字段编号5 - yyyy-MM
     */
    private static final String TIME_FORMAT_VIRTUAL_FIELD_CODE_5 =
        VirtualFieldEnum.TIME_FORMAT_VIRTUAL_FIELD_CODE_5.getVirtualFieldCodeValue();

    /**
     * @description token占位符
     */
    private final Map<String, LocalFieldPlaceholder> tokenPlaceholderMap = new HashMap<>();

    /**
     * @description 基础表功能
     */
    @Setter
    private BaseTableFunction baseTableFunction;

    /**
     * @description Constructor
     *
     * @author quark
     * @date 2024/4/19 10:41
     * @initVersion v3.1.0.GA
     */
    TokenPlaceholder() {}

    /**
     * @description 获得所有的虚拟表编号 更好的做法可以是将这些虚拟表编号定义在枚举类中，这边获取该枚举类中的所有实例，这样就不用每次跟着改了
     */
    public static List<Long> getVirtualTableCodes() {
        return List.of(Long.parseLong(STAFF_VIRTUAL_TABLE_CODE), Long.parseLong(ENTERPRISE_VIRTUAL_TABLE_CODE),
            Long.parseLong(CURRENT_TIME_VIRTUAL_TABLE_CODE), Long.parseLong(DEPARTMENT_VIRTUAL_TABLE_CODE),
            Long.parseLong(POST_VIRTUAL_TABLE_CODE));
    }

    /**
     * @description 获得token占位符
     * @return 所有的token占位符
     *
     * @author zhangqi
     * @date 2023/11/27 11:48
     * @initVersion 3.0.1.300
     */
    public final Map<String, LocalFieldPlaceholder> getTokenPlaceholder() {
        try {
            if (CollUtil.isEmpty(tokenPlaceholderMap)) {
                synchronized (tokenPlaceholderMap) {
                    if (CollUtil.isEmpty(tokenPlaceholderMap)) {
                        long staffTableCode = AssertInjecter.notNullAndGet(baseTableFunction, "baseTableFunction",
                            (GenerateRuntimeException<PlaceholderRuntimeException>)(embeddedValue, e, msg,
                                args) -> new PlaceholderRuntimeException(e, msg, args))
                            .getStaffTableCode();
                        // 人员编号本地占位符
                        tokenPlaceholderMap.put(
                            "${" + STAFF_VIRTUAL_TABLE_CODE + "_" + CODE_VIRTUAL_FIELD_CODE + "-f-f}",
                            new LocalFieldPlaceholder(Long.parseLong(STAFF_VIRTUAL_TABLE_CODE),
                                GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue(), "员工编号 - token", false,
                                FieldLogicTypeEnum.ASSOCIATION, String.valueOf(staffTableCode), false));
                        // 人员姓名本地占位符
                        tokenPlaceholderMap.put(
                            "${" + STAFF_VIRTUAL_TABLE_CODE + "_" + SIGNATURE_VIRTUAL_FIELD_CODE + "-f-f}",
                            new LocalFieldPlaceholder(Long.parseLong(STAFF_VIRTUAL_TABLE_CODE),
                                NAME_VIRTUAL_CODE.getValue(), "员工姓名 - token", false, FieldLogicTypeEnum.VARCHAR, null,
                                false));
                        // 企业编号本地占位符
                        tokenPlaceholderMap.put(
                            "${" + ENTERPRISE_VIRTUAL_TABLE_CODE + "_" + CODE_VIRTUAL_FIELD_CODE + "-f-f}",
                            new LocalFieldPlaceholder(GlobalDynamicalMagicValue.ENTERPRISE_VIRTUAL_DM_TABLE.getValue(),
                                GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue(), "企业编号 - token", false,
                                FieldLogicTypeEnum.ASSOCIATION,
                                String.valueOf(GlobalDynamicalMagicValue.ENTERPRISE_VIRTUAL_DM_TABLE.getValue()),
                                false));
                        // 企业名称本地占位符
                        tokenPlaceholderMap.put(
                            "${" + ENTERPRISE_VIRTUAL_TABLE_CODE + "_" + SIGNATURE_VIRTUAL_FIELD_CODE + "-f-f}",
                            new LocalFieldPlaceholder(GlobalDynamicalMagicValue.ENTERPRISE_VIRTUAL_DM_TABLE.getValue(),
                                NAME_VIRTUAL_CODE.getValue(), "企业名称 - token", false, FieldLogicTypeEnum.VARCHAR, null,
                                false));

                        // 部门编号
                        tokenPlaceholderMap.put(
                            "${" + DEPARTMENT_VIRTUAL_TABLE_CODE + "_" + CODE_VIRTUAL_FIELD_CODE + "-t-f}",
                            new LocalFieldPlaceholder(Long.parseLong(DEPARTMENT_VIRTUAL_TABLE_CODE),
                                PRIMARY_KEY_VIRTUAL_CODE.getValue(), "部门编号 - token", false,
                                FieldLogicTypeEnum.ASSOCIATION, DEPARTMENT_VIRTUAL_TABLE_CODE, false));
                        // 部门名称
                        tokenPlaceholderMap.put(
                            "${" + DEPARTMENT_VIRTUAL_TABLE_CODE + "_" + SIGNATURE_VIRTUAL_FIELD_CODE + "-t-f}",
                            new LocalFieldPlaceholder(Long.parseLong(DEPARTMENT_VIRTUAL_TABLE_CODE),
                                NAME_VIRTUAL_CODE.getValue(), "部门名称 - token", false, FieldLogicTypeEnum.VARCHAR, null,
                                false));
                        // 岗位编号
                        tokenPlaceholderMap.put(
                            "${" + POST_VIRTUAL_TABLE_CODE + "_" + CODE_VIRTUAL_FIELD_CODE + "-t-f}",
                            new LocalFieldPlaceholder(Long.parseLong(POST_VIRTUAL_TABLE_CODE),
                                PRIMARY_KEY_VIRTUAL_CODE.getValue(), "岗位编号 - token", false,
                                FieldLogicTypeEnum.ASSOCIATION, POST_VIRTUAL_TABLE_CODE, false));
                        // 岗位名称
                        tokenPlaceholderMap.put(
                            "${" + POST_VIRTUAL_TABLE_CODE + "_" + SIGNATURE_VIRTUAL_FIELD_CODE + "-t-f}",
                            new LocalFieldPlaceholder(Long.parseLong(POST_VIRTUAL_TABLE_CODE),
                                NAME_VIRTUAL_CODE.getValue(), "岗位名称 - token", false, FieldLogicTypeEnum.VARCHAR, null,
                                false));

                        // 当前时间 - yyyy-MM-dd HH:mm:ss
                        tokenPlaceholderMap.put(
                            "${" + CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_1 + "-f-f}",
                            new LocalFieldPlaceholder(Long.parseLong(CURRENT_TIME_VIRTUAL_TABLE_CODE),
                                Long.parseLong(TIME_FORMAT_VIRTUAL_FIELD_CODE_1), "当前时间 - yyyy-MM-dd HH:mm:ss", false,
                                FieldLogicTypeEnum.TIME, String.valueOf(TimeFormatEnum.DATE_TIME_SEC), false));
                        // 当前时间 - yyyy-MM-dd HH:mm
                        tokenPlaceholderMap.put(
                            "${" + CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_2 + "-f-f}",
                            new LocalFieldPlaceholder(Long.parseLong(CURRENT_TIME_VIRTUAL_TABLE_CODE),
                                Long.parseLong(TIME_FORMAT_VIRTUAL_FIELD_CODE_2), "当前时间 - yyyy-MM-dd HH:mm", false,
                                FieldLogicTypeEnum.TIME, String.valueOf(TimeFormatEnum.DATE_TIME_MIN), false));
                        // 当前时间 - yyyy-MM-dd HH
                        tokenPlaceholderMap.put(
                            "${" + CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_3 + "-f-f}",
                            new LocalFieldPlaceholder(Long.parseLong(CURRENT_TIME_VIRTUAL_TABLE_CODE),
                                Long.parseLong(TIME_FORMAT_VIRTUAL_FIELD_CODE_3), "当前时间 - yyyy-MM-dd HH", false,
                                FieldLogicTypeEnum.TIME, String.valueOf(TimeFormatEnum.DATE_TIME_HOUR), false));
                        // 当前时间 - yyyy-MM-dd
                        tokenPlaceholderMap.put(
                            "${" + CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_4 + "-f-f}",
                            new LocalFieldPlaceholder(Long.parseLong(CURRENT_TIME_VIRTUAL_TABLE_CODE),
                                Long.parseLong(TIME_FORMAT_VIRTUAL_FIELD_CODE_4), "当前时间 - yyyy-MM-dd", false,
                                FieldLogicTypeEnum.TIME, String.valueOf(TimeFormatEnum.DATE_DAY), false));
                        // 当前时间 - yyyy-MM
                        tokenPlaceholderMap.put(
                            "${" + CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_5 + "-f-f}",
                            new LocalFieldPlaceholder(Long.parseLong(CURRENT_TIME_VIRTUAL_TABLE_CODE),
                                Long.parseLong(TIME_FORMAT_VIRTUAL_FIELD_CODE_5), "当前时间 - yyyy-MM", false,
                                FieldLogicTypeEnum.TIME, String.valueOf(TimeFormatEnum.DATE_MTH), false));
                    }
                }
            }
            return tokenPlaceholderMap;
        } catch (Exception e) {
            throw new RuntimeException("dm service unStart", e);
        }
    }

    /**
     * @description 获得token占位符值map
     * @param tableCode 关联表编号
     * @param tablePrimaryKeyList 关联表主键值集合[可能传入不可更改集合]
     * @return token占位符
     * @throws ExceptionPack 获得异常
     *
     * @author zhangqi
     * @date 2023/6/25 22:03
     * @initVersion 3.0.1.300
     */
    public final Map<String, String> getTokenPlaceholderValueMap(Long tableCode, List<Long> tablePrimaryKeyList,
        boolean isSet, TableFieldFunction fieldFunction) throws ExceptionPack {
        try {
            Long staffCode =
                InfoPenetrateProcessor.INSTANCE.getPenetrateInfoNotNull(GlobalTokenPenetrate.USER_CODE_THREAD_LOCAL);
            String staffName =
                InfoPenetrateProcessor.INSTANCE.getPenetrateInfoNotNull(GlobalTokenPenetrate.USER_NAME_THREAD_LOCAL);
            Long enterpriseCode = InfoPenetrateProcessor.INSTANCE
                .getPenetrateInfoNotNull(GlobalTokenPenetrate.ENTERPRISE_CODE_THREAD_LOCAL);
            String enterpriseName = InfoPenetrateProcessor.INSTANCE
                .getPenetrateInfoNotNull(GlobalTokenPenetrate.ENTERPRISE_NAME_THREAD_LOCAL);

            Long departmentCode = InfoPenetrateProcessor.INSTANCE
                .getPenetrateInfo(GlobalTokenPenetrate.USER_DEPARTMENT_CODE_MAIN_SYSTEM_THREAD_LOCAL);
            String departmentName = InfoPenetrateProcessor.INSTANCE
                .getPenetrateInfo(GlobalTokenPenetrate.USER_DEPARTMENT_NAME_MAIN_SYSTEM_THREAD_LOCAL);
            Long postCode = InfoPenetrateProcessor.INSTANCE
                .getPenetrateInfo(GlobalTokenPenetrate.USER_POST_CODE_MAIN_SYSTEM_THREAD_LOCAL);
            String postName = InfoPenetrateProcessor.INSTANCE
                .getPenetrateInfo(GlobalTokenPenetrate.USER_DEPARTMENT_NAME_MAIN_SYSTEM_THREAD_LOCAL);

            Map<String, String> result = new HashMap<>();
            // 人员编号
            result.put(STAFF_VIRTUAL_TABLE_CODE + "_" + CODE_VIRTUAL_FIELD_CODE, String.valueOf(staffCode));
            // 人员名称
            result.put(STAFF_VIRTUAL_TABLE_CODE + "_" + SIGNATURE_VIRTUAL_FIELD_CODE, staffName);
            // 企业编号
            result.put(ENTERPRISE_VIRTUAL_TABLE_CODE + "_" + CODE_VIRTUAL_FIELD_CODE, String.valueOf(enterpriseCode));
            // 企业名称
            result.put(ENTERPRISE_VIRTUAL_TABLE_CODE + "_" + SIGNATURE_VIRTUAL_FIELD_CODE,
                String.valueOf(enterpriseName));

            // 部门编号
            if (departmentCode != null) {
                result.put(DEPARTMENT_VIRTUAL_TABLE_CODE + "_" + CODE_VIRTUAL_FIELD_CODE,
                    String.valueOf(departmentCode));
            }
            // 部门名称
            if (departmentName != null) {
                result.put(DEPARTMENT_VIRTUAL_TABLE_CODE + "_" + SIGNATURE_VIRTUAL_FIELD_CODE, departmentName);
            }
            // 岗位编号
            if (postCode != null) {
                result.put(POST_VIRTUAL_TABLE_CODE + "_" + CODE_VIRTUAL_FIELD_CODE, String.valueOf(postCode));
            }
            // 岗位名称
            if (postName != null) {
                result.put(POST_VIRTUAL_TABLE_CODE + "_" + SIGNATURE_VIRTUAL_FIELD_CODE, postName);
            }

            // 当前时间 - yyyy-MM-dd HH:mm:ss
            result.put(CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_1,
                TimeFormatEnum.DATE_TIME_SEC.currentTime());
            // 当前时间 - yyyy-MM-dd HH:mm
            result.put(CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_2,
                TimeFormatEnum.DATE_TIME_MIN.currentTime());
            // 当前时间 - yyyy-MM-dd HH
            result.put(CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_3,
                TimeFormatEnum.DATE_TIME_HOUR.currentTime());
            // 当前时间 - yyyy-MM-dd
            result.put(CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_4,
                TimeFormatEnum.DATE_DAY.currentTime());
            // 当前时间 - yyyy-MM
            result.put(CURRENT_TIME_VIRTUAL_TABLE_CODE + "_" + TIME_FORMAT_VIRTUAL_FIELD_CODE_5,
                TimeFormatEnum.DATE_MTH.currentTime());
            if (CollUtil.isNotEmpty(tablePrimaryKeyList)) {
                // 关联表流程处理
                if (isSet) {
                    // 特别的兼容集合
                    result.put(tableCode + "_" + GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue(),
                        "[" + StrUtil.join(",", tablePrimaryKeyList) + "]");
                } else {
                    result.put(tableCode + "_" + GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue(),
                        String.valueOf(AssertInjecter.inject(tablePrimaryKeyList, "tablePrimaryKeyList")
                            .and(p -> p.size() == 1)
                            .judgeAndGet(
                                ExceptionMsg.builder("Single associative table operation parameter missing").build())
                            .getFirst()));

                    // 还返回当前关联表的所有外联表集合字段所属表的主键
                    Map<Long, AssociatedValueInfo> associatedSetValueTableCodes =
                        fieldFunction.getSetAssociatedFieldValueList(tableCode, tablePrimaryKeyList.getFirst());
                    Map<Long, TableFieldModel> setAssociatedFieldMap =
                        fieldFunction.getSetAssociatedFieldList(tableCode).stream()
                            .collect(Collectors.toMap(TableFieldModel::getFieldCode, Function.identity()));
                    associatedSetValueTableCodes.entrySet().stream().filter(p -> p.getKey() != 268172000000000001L)
                        .forEach(p -> result.put(
                            setAssociatedFieldMap.get(p.getKey()).getAssociatedTable() + "_"
                                + GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE.getValue(),
                            StrUtil.isBlank(p.getValue().getValue()) ? null : p.getValue().isFlagSet()
                                ? "[" + p.getValue().getValue() + "]" : p.getValue().getValue()));
                }
            }
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The token parameter cannot be obtained").build());
        }
    }
}
