/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.compare.CompareException;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractComparable;
import org.aerie.forest.dynamic.process.domain.compare.comparable.StringValue;
import org.aerie.forest.dynamic.process.domain.compare.operator.varchar.StringIsBlank;
import org.aerie.forest.dynamic.process.domain.compare.operator.varchar.StringNotBlank;
import org.aerie.forest.dynamic.process.domain.placeholder.GlobalPlaceholderFixedPatternMagicValue;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @description 枚举符号
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/17 9:50
 * @version 3.0.1.300
 */
public abstract class AbstractStringSymbol extends AbstractCompareSymbol<StringValue> {

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     * @param operatorName 符号名称
     * @param paramNullableFlag 参数可空标识
     * @param flag 标识
     *
     * @author zhangqi
     * @date 2023/5/17 9:49
     * @initVersion 3.0.1.300
     */
    protected AbstractStringSymbol(String displaySymbol, String operatorName, boolean paramNullableFlag, String flag) {
        super(displaySymbol, operatorName, FieldLogicTypeEnum.VARCHAR, paramNullableFlag, flag);
    }

    @Override
    public StringValue generateComparable(String value) throws ExceptionPack {
        try {
            if (NULL_FLAG.equals(value)) {
                return null;
            }
            return new StringValue(value);
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to map String fields").build());
        }
    }

    @Override
    public String checkComparable(String value) throws ExceptionPack {
        try {
            if (NULL_FLAG.equals(value)) {
                return null;
            }
            if (verifyPlaceholderRealFieldType(value, fieldLogicTypeEnum, true) != null) {
                return null;
            }
            if (GlobalPlaceholderFixedPatternMagicValue.FIXED_VALUE_VARCHAR.getValue().matcher(value).matches()) {
                return null;
            }
            throw new CompareException(ExceptionMsg.builder("Cannot match a varchar value").build());
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to map varchar fields").build());
        }
    }

    /**
     * @description 获得判空符号
     * @return 判空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:40
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public final AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNullSymbol() {
        return StringIsBlank.getInstance();
    }

    /**
     * @description 获得判非空符号
     * @return 判非空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:41
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public final AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNotNullSymbol() {
        return StringNotBlank.getInstance();
    }
}
