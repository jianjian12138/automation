/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import java.math.BigDecimal;

/**
 * @description 数值
 * @param <T> 数值的实际类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 14:23
 * @version 3.0.1.300
 */
public abstract class AbstractNumericalValue<T> extends AbstractComparable<T, BigDecimal> {

    protected AbstractNumericalValue(T value) {
        super(value);
    }
}
