/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ComparableJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractDyadicOperator;

/**
 * @description 除法
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 16:43
 * @version 3.0.1.300
 */
public final class Division extends AbstractDyadicOperator {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 除法
         */
        private static final Division DIVISION = new Division("/");
    }

    /**
     * @description 获得单例对象
     * @return
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static Division getInstance() {
        return INSTANCE.DIVISION;
    }

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     *
     * @author zhangqi
     * @date 2023/4/19 17:32
     * @initVersion 3.0.1.300
     */
    private Division(String displaySymbol) {
        super(displaySymbol, "Division", 6);
    }

    @Override
    protected BigDecimal calculateResult(int scale, BigDecimal front, BigDecimal back) throws ExceptionPack {
        try {
            AssertInjecter.inject(back, "back").and(ComparableJudgementShelf.NOT_EQUAL, new BigDecimal("0"))
                .judge(ExceptionMsg.builder("The divisor cannot be zero").build());
            return front.divide(back, scale, RoundingMode.HALF_UP);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The multiply calculation failed, front: {}, back: {}", front, back).build());
        }
    }
}
