/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.date;

import java.time.LocalDateTime;
import java.time.temporal.TemporalUnit;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.bannew.statical.AbstractStaticResource;
import org.aerie.forest.core.brick.exception.AbstractForestException;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.pact.time.TimeFormatEnum;

/**
 * @description 时间转化器库
 *
 * @author quark
 * @organization futurecraftsmen
 * @date 2024/4/29 15:54
 * @version v3.1.1.GA
 */

public final class DateConverterStore extends AbstractStaticResource {

    /**
     * @description 推迟时间
     */
    public static final AbstractDateConverter<TimeIntervalInfo, LocalDateTime> POSTPONE_TIME =
        new AbstractDateConverter<>() {
            @Override
            protected LocalDateTime transformAction(LocalDateTime localDateTime, TimeIntervalInfo param)
                throws AbstractForestException {
                try {
                    return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                        .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build())
                        .plus(param.interval, param.timeUnit);
                } catch (Exception e) {
                    throw new ExceptionPack(e, ExceptionMsg.builder("Delay time failure").build());
                }
            }

            @Override
            public TimeIntervalInfo verify(TimeIntervalInfo timeIntervalInfo) throws AbstractForestException {
                return AssertInjecter.inject(timeIntervalInfo, "timeIntervalInfo").and(ObjectJudgementShelf.NOT_NULL)
                    .and(p -> p.timeUnit != null).judgeAndGet(ExceptionMsg
                        .builder("timeIntervalInfo is invalid, timeIntervalInfo: {}", timeIntervalInfo).build());
            }
        };

    /**
     * @description 提前时间
     */
    public static final AbstractDateConverter<TimeIntervalInfo, LocalDateTime> LEAD_TIME =
        new AbstractDateConverter<>() {
            @Override
            protected LocalDateTime transformAction(LocalDateTime localDateTime, TimeIntervalInfo param)
                throws AbstractForestException {
                try {
                    return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                        .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build())
                        .minus(param.interval, param.timeUnit);
                } catch (Exception e) {
                    throw new ExceptionPack(e, ExceptionMsg.builder("Delay time failure").build());
                }
            }

            @Override
            public TimeIntervalInfo verify(TimeIntervalInfo timeIntervalInfo) throws AbstractForestException {
                return AssertInjecter.inject(timeIntervalInfo, "timeIntervalInfo").and(ObjectJudgementShelf.NOT_NULL)
                    .and(p -> p.timeUnit != null).judgeAndGet(ExceptionMsg
                        .builder("timeIntervalInfo is invalid, timeIntervalInfo: {}", timeIntervalInfo).build());
            }
        };

    /**
     * @description 时间格式转换
     */
    public static final AbstractDateConverter<TimeFormatEnum, String> TIME_FORMAT_CONVERSION =
        new AbstractDateConverter<>() {
            @Override
            protected String transformAction(LocalDateTime localDateTime, TimeFormatEnum param)
                throws AbstractForestException {
                try {
                    return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                        .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build())
                        .format(param.getDateTimeFormatter());
                } catch (Exception e) {
                    throw new ExceptionPack(e, ExceptionMsg.builder("Delay time failure").build());
                }
            }

            @Override
            public TimeFormatEnum verify(TimeFormatEnum timeFormat) throws AbstractForestException {
                return AssertInjecter.inject(timeFormat, "timeFormat").and(ObjectJudgementShelf.NOT_NULL)
                    .judgeAndGet(ExceptionMsg.builder("timeFormat cannot be null").build());
            }
        };

    /**
     * @description 判断时间是否在前面
     */
    public static final AbstractDateConverter<LocalDateTime, Boolean> TIME_BEFORE = new AbstractDateConverter<>() {
        @Override
        protected Boolean transformAction(LocalDateTime localDateTime, LocalDateTime param)
            throws AbstractForestException {
            try {
                return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                    .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build()).isBefore(param);
            } catch (Exception e) {
                throw new ExceptionPack(e,
                    ExceptionMsg.builder("It is not possible to tell if the time is before").build());
            }
        }

        @Override
        public LocalDateTime verify(LocalDateTime localDateTime) throws AbstractForestException {
            return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build());
        }
    };

    /**
     * @description 判断时间是否在前面
     */
    public static final AbstractDateConverter<LocalDateTime, Boolean> TIME_AFTER = new AbstractDateConverter<>() {
        @Override
        protected Boolean transformAction(LocalDateTime localDateTime, LocalDateTime param)
            throws AbstractForestException {
            try {
                return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                    .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build()).isAfter(param);
            } catch (Exception e) {
                throw new ExceptionPack(e,
                    ExceptionMsg.builder("It is not possible to tell if the time is after").build());
            }
        }

        @Override
        public LocalDateTime verify(LocalDateTime localDateTime) throws AbstractForestException {
            return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build());
        }
    };

    /**
     * @description 判断时间是否在前面
     */
    public static final AbstractDateConverter<LocalDateTime, Boolean> TIME_EQUAL = new AbstractDateConverter<>() {

        @Override
        protected Boolean transformAction(LocalDateTime localDateTime, LocalDateTime param)
            throws AbstractForestException {
            try {
                return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                    .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build()).isEqual(param);
            } catch (Exception e) {
                throw new ExceptionPack(e,
                    ExceptionMsg.builder("It is not possible to tell if the time is equal").build());
            }
        }

        @Override
        public LocalDateTime verify(LocalDateTime localDateTime) throws AbstractForestException {
            return AssertInjecter.inject(localDateTime, "localDateTime").and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndGet(ExceptionMsg.builder("localDateTime cannot be null").build());
        }
    };

    /**
     * @description 时间间隔信息
     * @param interval 时间间隔
     * @param timeUnit 时间单位
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2024/5/8 11:38
     * @version v3.1.1.GA
     */
    public record TimeIntervalInfo(long interval, TemporalUnit timeUnit) {
    }
}
