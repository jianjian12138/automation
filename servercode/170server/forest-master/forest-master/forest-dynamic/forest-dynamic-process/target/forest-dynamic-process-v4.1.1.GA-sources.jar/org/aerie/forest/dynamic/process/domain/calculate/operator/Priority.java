/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator;

/**
 * @description 优先级
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 15:36
 * @version 3.0.1.300
 */
public interface Priority {

    /**
     * @description 获得优先级
     * @return 优先级
     *
     * @author zhangqi
     * @date 2023/4/19 15:36
     * @initVersion 3.0.1.300
     */
    byte getPriority();
}
