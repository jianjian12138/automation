/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator;

import org.aerie.forest.dynamic.process.domain.calculate.ParamPosition;

/**
 * @description 包裹符
 * @param <T> 包裹付类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/12/11 15:55
 * @version 3.0.1.300
 */
public interface WrapFunction<T extends AbstractOperator> {

    /**
     * @description 获得镜像包装运算符
     * @return 镜像包装运算符
     *
     * @author zhangqi
     * @date 2023/4/20 14:45
     * @initVersion 3.0.1.300
     */
    T getMirrorWrapOperator();

    /**
     * @description 获得参数位置
     * @return 符号参数位置
     *
     * @author zhangqi
     * @date 2023/12/13 19:39
     * @initVersion 3.0.1.300
     */
    ParamPosition getParamPosition();
}
