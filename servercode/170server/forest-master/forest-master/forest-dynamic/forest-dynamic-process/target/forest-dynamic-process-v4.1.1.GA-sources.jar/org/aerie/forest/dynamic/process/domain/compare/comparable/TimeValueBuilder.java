/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.compare.CompareException;
import org.aerie.forest.core.brick.pact.time.TimeFormatEnum;
import org.aerie.forest.core.brick.pact.time.TimeTypeEnum;

/**
 * @description 时间比较值生成器
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/23 14:47
 * @version 3.0.1.300
 */
public enum TimeValueBuilder {
    /**
     * @description 单例对象
     */
    INSTANCE;

    /**
     * @description 生成时间可比较对象
     * @param value 对应的值
     * @return 生成的时间可比较对象
     * @throws ExceptionPack 生成异常
     *
     * @author zhangqi
     * @date 2023/5/23 14:55
     * @initVersion 3.0.1.300
     */
    public AbstractTimeValue<?> generateTimeComparable(String value) throws ExceptionPack {
        try {
            TimeFormatEnum timeFormatEnum =
                AssertInjecter.inject(TimeFormatEnum.matchTimeFormatEnum(value), "").and(ObjectJudgementShelf.NOT_NULL)
                    .judgeAndGet(ExceptionMsg.builder("Invalid time format, time: {}", value).build());
            TimeTypeEnum timeTypeEnum = AssertInjecter.inject(TimeTypeEnum.matchTimeTypeOfFormat(timeFormatEnum), "")
                .and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndGet(ExceptionMsg.builder("Invalid time type, timeFormat: {}", timeFormatEnum).build());
            switch (timeTypeEnum) {
                case DATE_TIME -> {
                    return new DateTimeValue(value, timeFormatEnum);
                }
                case DATE -> {
                    return new DateValue(value, timeFormatEnum);
                }
                case TIME -> {
                    return new TimeValue(value, timeFormatEnum);
                }
                default -> throw new CompareException(
                    ExceptionMsg.builder("Cannot match a valid time format or type, value: {}", value).build());
            }
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to map time fields").build());
        }
    }
}
