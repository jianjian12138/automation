/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.text;

import org.aerie.forest.core.brick.exception.AbstractForestException;
import org.aerie.forest.core.brick.function.verify.self.SelfVerifiableByParam;

/**
 * @description 文本转化器 - // TODO 设计时的参数校验后面要处理， 目前通过前后端的严格匹配处理
 *
 * @author quark
 * @organization futurecraftsmen
 * @date 2024/4/29 14:37
 * @version v3.1.1.GA
 */
public abstract class AbstractTextConverter<T> implements SelfVerifiableByParam<T, T, AbstractForestException> {

    /**
     * @description 转化的实际操作
     * @param text 待转化的文本
     * @param param 需要的参数
     * @return 转化后的文本
     * @throws AbstractForestException 转化异常
     *
     * @author quark
     * @date 2024/4/29 14:38
     * @initVersion v3.1.1.GA
     */
    protected abstract String transformAction(String text, T param) throws AbstractForestException;

    /**
     * @description 转化
     * @param text 待转化的文本
     * @param param 需要的参数
     * @return 转化后的文本
     * @throws AbstractForestException 转化异常
     *
     * @author quark
     * @date 2024/4/30 10:26
     * @initVersion v3.1.1.GA
     */
    public final String transform(String text, T param) throws AbstractForestException {
        return transformAction(text, verify(param));
    }
}