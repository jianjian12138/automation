/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;

/**
 * @description 数值
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 14:23
 * @version 3.0.1.300
 */
public final class StringValue extends AbstractComparable<String, String> {

    /**
     * @description Constructor
     * @param value 实际的值
     *
     * @author zhangqi
     * @date 2023/5/15 14:20
     * @initVersion 3.0.1.300
     */
    public StringValue(String value) {
        super(value);
    }

    @Override
    public String getComparableValue(boolean canBeNull) throws ExceptionPack {
        try {
            if (canBeNull && value == null) {
                return null;
            }
            AssertInjecter.inject(value, "value").and(ObjectJudgementShelf.NOT_NULL).or().and(() -> canBeNull)
                .judge(ExceptionMsg.builder("The string cannot be empty").build());
            return value;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to retrieve the string").build());
        }
    }
}
