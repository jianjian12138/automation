/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import java.util.List;

import cn.hutool.core.util.StrUtil;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;

import lombok.ToString;

/**
 * @description 本地字段占位符
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/29 15:10
 * @version 3.0.1.300
 */
@ToString(callSuper = true)
public class LocalFieldPlaceholder extends AbstractFieldBasePositionInfo {

    /**
     * @description Constructor
     * @param tableCode 表编号
     * @param fieldCode 字段编号
     * @param name 字段名称
     * @param nullableFlag 可空标识
     * @param fieldLogicType 字段逻辑类型
     * @param additionalValue 附加属性
     *
     * @author zhangqi
     * @date 2023/6/14 17:30
     * @initVersion 3.0.1.300
     */
    public LocalFieldPlaceholder(long tableCode, long fieldCode, String name, boolean nullableFlag,
        FieldLogicTypeEnum fieldLogicType, String additionalValue, boolean isInsertReturn) {
        super(tableCode, fieldCode, name, nullableFlag, fieldLogicType, additionalValue, isInsertReturn);
    }

    /**
     * @description Constructor
     * @param tableCode 表编号
     * @param fieldCode 字段编号
     * @param name 字段名称
     * @param nullableFlag 字段名称
     * @param fieldLogicType 字段逻辑类型
     * @param setFlag 集合标识
     * @param additionalValue 附加属性
     *
     * @author pms
     * @date 2023/9/20 9:43
     * @initVersion 3.0.1.300
     */
    public LocalFieldPlaceholder(long tableCode, long fieldCode, String name, boolean nullableFlag,
        FieldLogicTypeEnum fieldLogicType, boolean setFlag, String additionalValue, boolean isInsertReturn) {
        super(tableCode, fieldCode, name, nullableFlag, fieldLogicType, setFlag, additionalValue, isInsertReturn);
    }

    @Override
    public boolean isNullable() {
        return this.isNullableFlag();
    }

    @Override
    public String generatePlaceholder() {
        String tokenLocalFieldPlaceholderValue =
            LocalAbstractFieldPlaceholderResolver.getInstance().getTokenLocalFieldPlaceholderValue(this);
        if (StrUtil.isNotBlank(tokenLocalFieldPlaceholderValue)) {
            return tokenLocalFieldPlaceholderValue;
        }

        return LocalAbstractFieldPlaceholderResolver.getInstance().generatePlaceholder(String.valueOf(getTableCode()),
            String.valueOf(getFieldCode()), isNullable(), isSetFlag(), isInsertReturn());
    }

    /**
     * @description 判断字段逻辑类型兼容性
     * @param fieldLogicType 字段逻辑类型
     * @param additionalValue 附加属性
     * @param nullable 可空标识
     * @return 兼容性
     *
     * @author quark
     * @date 2024/4/15 10:50
     * @initVersion v3.1.0.GA
     */
    public boolean compatibleFieldLogicalType(FieldLogicTypeEnum fieldLogicType, String additionalValue,
        boolean nullable) {
        return compatibleFieldLogicalType(List.of(fieldLogicType), additionalValue, nullable);
    }

    public boolean compatibleFieldLogicalType(List<FieldLogicTypeEnum> fieldLogicTypes, String additionalValue,
        boolean nullable) {
        for (FieldLogicTypeEnum fieldLogicType : fieldLogicTypes) {
            if (FieldLogicTypeEnum.fieldLogicTypeAndAdditionValueMatch(this.getFieldLogicType(),
                this.getAdditionalValue(), this.isNullable(), fieldLogicType, additionalValue, nullable)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean equals(Object object) {
        if (object instanceof LocalFieldPlaceholder localFieldPlaceholder) {
            return this.getTableCode() == localFieldPlaceholder.getTableCode()
                && this.getFieldCode() == localFieldPlaceholder.getFieldCode()
                && this.isNullableFlag() == localFieldPlaceholder.isNullableFlag()
                && this.isSetFlag() == localFieldPlaceholder.isSetFlag();
        }
        return false;
    }
}