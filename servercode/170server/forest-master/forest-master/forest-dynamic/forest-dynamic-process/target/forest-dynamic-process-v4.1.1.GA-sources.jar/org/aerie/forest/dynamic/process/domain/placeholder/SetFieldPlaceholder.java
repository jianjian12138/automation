/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import lombok.Getter;
import lombok.Setter;

/**
 * @description 集合占位符
 *
 * @author nimj
 * @date 2024/6/20
 */
@Getter
@Setter
public class SetFieldPlaceholder {
    /**
     * 前缀，本地占位符或数据库占位符
     */
    private String pre;

    /**
     * 集合操作
     * U:并集，I:交集，D:差集
     */
    private String operation;

    /**
     * 后缀，本地占位符或数据库占位符
     */
    private String post;
}