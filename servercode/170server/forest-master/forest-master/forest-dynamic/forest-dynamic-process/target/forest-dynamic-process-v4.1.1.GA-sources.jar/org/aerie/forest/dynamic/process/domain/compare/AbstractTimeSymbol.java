/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.BooleanJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.compare.CompareException;
import org.aerie.forest.core.brick.pact.time.TimeFormatEnum;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractComparable;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractTimeValue;
import org.aerie.forest.dynamic.process.domain.compare.comparable.TimeValueBuilder;
import org.aerie.forest.dynamic.process.domain.compare.operator.time.TimeIsNull;
import org.aerie.forest.dynamic.process.domain.compare.operator.time.TimeNotNull;
import org.aerie.forest.dynamic.process.domain.placeholder.AbstractFieldBasePositionInfo;
import org.aerie.forest.dynamic.process.domain.placeholder.GlobalPlaceholderFixedPatternMagicValue;

import com.fasterxml.jackson.annotation.JsonIgnore;

import cn.hutool.core.util.StrUtil;

/**
 * @description 枚举符号
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/17 9:50
 * @version 3.0.1.300
 */
public abstract class AbstractTimeSymbol extends AbstractCompareSymbol<AbstractTimeValue<?>> {

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     * @param operatorName 符号名称
     * @param paramNullableFlag 参数可空标识
     * @param flag 标识
     *
     * @author zhangqi
     * @date 2023/5/17 9:49
     * @initVersion 3.0.1.300
     */
    protected AbstractTimeSymbol(String displaySymbol, String operatorName, boolean paramNullableFlag, String flag) {
        super(displaySymbol, operatorName, FieldLogicTypeEnum.TIME, paramNullableFlag, flag);
    }

    @Override
    public AbstractTimeValue<?> generateComparable(String value) throws ExceptionPack {
        if (NULL_FLAG.equals(value)) {
            return null;
        }
        if (StrUtil.isBlank(value)) {
            return new AbstractTimeValue<>(null, null) {
                @Override
                public Object getComparableValue(boolean canBeNull) {
                    return null;
                }
            };
        }
        return TimeValueBuilder.INSTANCE.generateTimeComparable(value);
    }

    @Override
    public String checkComparable(String value) throws ExceptionPack {
        try {
            if (NULL_FLAG.equals(value)) {
                return null;
            }
            AbstractFieldBasePositionInfo fieldBasePositionInfo =
                verifyPlaceholderRealFieldType(value, fieldLogicTypeEnum, true);
            if (fieldBasePositionInfo != null) {
                AssertInjecter
                    .inject(fieldBasePositionInfo.getFieldLogicType().equals(FieldLogicTypeEnum.TIME), "fieldLogicType")
                    .and(BooleanJudgementShelf.IS_TRUE)
                    .judge(ExceptionMsg.builder("The argument to the time comparator is not a time type").build());
                return fieldBasePositionInfo.getAdditionalValue();
            }
            if (GlobalPlaceholderFixedPatternMagicValue.FIXED_VALUE_TIME.getValue().matcher(value).matches()) {
                TimeValueBuilder.INSTANCE.generateTimeComparable(value.substring(2, value.indexOf("|")));
                TimeFormatEnum timeFormatEnum =
                    TimeFormatEnum.matchTimeFormatEnum(value.substring(2, value.indexOf("|")));
                return String.valueOf(timeFormatEnum);
            }
            throw new CompareException(ExceptionMsg.builder("Cannot match a time value").build());
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to map time fields").build());
        }
    }

    /**
     * @description 获得判空符号
     * @return 判空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:40
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    @Override
    public final AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNullSymbol() {
        return TimeIsNull.getInstance();
    }

    /**
     * @description 获得判非空符号
     * @return 判非空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:41
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    @Override
    public final AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNotNullSymbol() {
        return TimeNotNull.getInstance();
    }
}
