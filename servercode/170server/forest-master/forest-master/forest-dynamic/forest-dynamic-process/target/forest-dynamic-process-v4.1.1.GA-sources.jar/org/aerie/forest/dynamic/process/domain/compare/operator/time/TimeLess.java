/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.operator.time;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.JudgmentExecutor;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.compare.AbstractTimeSymbol;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractTimeValue;

import cn.hutool.core.util.StrUtil;

/**
 * @description 时间比较 小于
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 17:59
 * @version 3.0.1.300
 */
public final class TimeLess extends AbstractTimeSymbol {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 时间小于
         */
        private static final TimeLess TIME_LESS = new TimeLess();
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static TimeLess getInstance() {
        return INSTANCE.TIME_LESS;
    }

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2023/5/15 17:14
     * @initVersion 3.0.1.300
     */
    private TimeLess() {
        super("<", "小于", false, "TIME_LESS");
    }

    @Override
    protected boolean compare(AbstractTimeValue<?> pre, AbstractTimeValue<?> post) throws ExceptionPack {
        try {
            Class<?> genericityClassPre = pre.getGenericityClass(AbstractTimeValue.class);
            Class<?> genericityClassPost =
                AssertInjecter.inject(post.getGenericityClass(AbstractTimeValue.class), "genericityClassPost")
                    .and(ObjectJudgementShelf.EQUAL, genericityClassPre)
                    .judgeAndGet(ExceptionMsg.builder("Only the same time type can be compared, per: {}, post: {}",
                        genericityClassPre, JudgmentExecutor.This.INSTANCE).build());
            if (LocalDate.class.equals(genericityClassPre)) {
                return ((LocalDate)(pre.getComparableValue(false)))
                    .compareTo((LocalDate)(post.getComparableValue(false))) < 0;
            } else if (LocalDateTime.class.equals(genericityClassPre)) {
                return ((LocalDateTime)(pre.getComparableValue(false)))
                    .compareTo((LocalDateTime)(post.getComparableValue(false))) < 0;
            } else if (LocalTime.class.equals(genericityClassPre)) {
                return ((LocalTime)(pre.getComparableValue(false)))
                    .compareTo((LocalTime)(post.getComparableValue(false))) < 0;
            }
            throw new Exception(
                StrUtil.format("Unsupported time types, per: {}, post: {}", genericityClassPre, genericityClassPost));
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to compare successfully, comparison expression: {}",
                pre.getValue() + getDisplaySymbol() + post.getValue()).build());
        }
    }

    // 序列化单例
    private Object readResolve() {
        return INSTANCE.TIME_LESS;
    }
}
