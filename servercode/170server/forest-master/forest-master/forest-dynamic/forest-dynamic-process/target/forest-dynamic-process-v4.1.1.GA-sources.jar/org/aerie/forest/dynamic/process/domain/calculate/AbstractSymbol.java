/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate;

import org.aerie.forest.core.genericity.ContainsGenericity;

import lombok.Getter;

/**
 * @description 符号
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 17:26
 * @version 3.0.1.300
 */
@Getter
public abstract class AbstractSymbol implements ContainsGenericity {

    /**
     * @description 展示的符号
     */
    private final String displaySymbol;

    /**
     * @description 符号名称
     */
    private final String operatorName;

    /**
     * @description Constructor
     * @param displaySymbol 展示的符号
     *
     * @author zhangqi
     * @date 2023/4/19 17:25
     * @initVersion 3.0.1.300
     */
    protected AbstractSymbol(String displaySymbol, String operatorName) {
        this.displaySymbol = displaySymbol;
        this.operatorName = operatorName;
    }
}
