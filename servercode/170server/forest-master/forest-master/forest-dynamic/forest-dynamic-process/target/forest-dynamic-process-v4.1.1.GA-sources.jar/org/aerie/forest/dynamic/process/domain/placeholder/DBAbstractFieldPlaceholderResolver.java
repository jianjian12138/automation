/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.StringJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.common.domain.FieldLogicInfo;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;

import lombok.*;

/**
 * @description 数据库字段占位符解析器
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/29 15:18
 * @version 3.0.1.300
 */
public final class DBAbstractFieldPlaceholderResolver
    extends AbstractFieldBasePositionInfoResolver<DbFieldPlaceholder> {

    /**
     * @description forest静态内部类单例
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/5/3 11:44
     * @version 3.0.1.300
     */
    private static final class ForestInstance {

        /**
         * @description 单例对象
         */
        private static final DBAbstractFieldPlaceholderResolver DB_FIELD_PLACEHOLDER_RESOLVER =
            new DBAbstractFieldPlaceholderResolver();
    }

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2023/5/3 11:44
     * @initVersion 3.0.1.300
     */
    private DBAbstractFieldPlaceholderResolver() {

    }

    /**
     * @description 获得数据库字段占位符解析器
     * @return 数据库字段占位符解析器
     *
     * @author zhangqi
     * @date 2023/5/4 10:25
     * @initVersion 3.0.1.300
     */
    public static DBAbstractFieldPlaceholderResolver getInstance() {
        return ForestInstance.DB_FIELD_PLACEHOLDER_RESOLVER;
    }

    @NoArgsConstructor
    @AllArgsConstructor
    @Data
    @ToString
    @EqualsAndHashCode
    public static class DbPlaceholderInfo {

        /**
         * @description 表编号
         */
        private long tableCode;

        /**
         * @description 字段编号
         */
        private long fieldCode;

        /**
         * @description 唯一键编号
         */
        private long uniqueCode;

        /**
         * @description 可空标识
         */
        private boolean nullable;

        /**
         * @description 本地占位符
         */
        private String localPlaceholder;

    }

    /**
     * @description 替换标识
     */
    private static final String DETAIL_PLACEHOLDER =
        "tableCodeD_fieldCodeD_uniqueIndex-nullableD^{tableCodeL_fieldCodeL-nullableL}";

    /**
     * @description 占位符框架
     */
    private static final String PLACEHOLDER_FRAME = "#{" + DETAIL_PLACEHOLDER + "}";

    /**
     * @description 表编号d占位符
     */
    private static final String TABLE_CODE_D_PLACEHOLDER = "tableCodeD";

    /**
     * @description 字段编号d占位符
     */
    private static final String FIELD_CODE_D_PLACEHOLDER = "fieldCodeD";

    /**
     * @description 唯一索引字段编号占位符
     */
    private static final String UNIQUE_INDEX_PLACEHOLDER = "uniqueIndex";

    /**
     * @description 可空d占位符
     */
    private static final String NULLABLE_D_PLACEHOLDER = "nullableD";

    /**
     * @description 表编号l占位符
     */
    private static final String TABLE_CODE_L_PLACEHOLDER = "tableCodeL";

    /**
     * @description 字段编号l占位符
     */
    private static final String FIELD_CODE_L_PLACEHOLDER = "fieldCodeL";

    /**
     * @description 可空l占位符
     */
    private static final String NULLABLE_L_PLACEHOLDER = "nullableL";

    /**
     * @description 生成占位符
     * @param tableCodeD 表编号d
     * @param fieldCodeD 字段编号d
     * @param uniqueIndex 唯一索引字段编号
     * @param nullableD 可空标识d
     * @param tableCodeL 表编号l
     * @param fieldCodeL 字段编号l
     * @param nullableL 可空标识l
     * @return 数据库占位符
     *
     * @author zhangqi
     * @date 2023/11/29 10:37
     * @initVersion 3.0.1.300
     */
    public String generatePlaceholder(String tableCodeD, String fieldCodeD, String uniqueIndex, boolean nullableD,
        String tableCodeL, String fieldCodeL, boolean nullableL) {
        return PLACEHOLDER_FRAME.replace(TABLE_CODE_D_PLACEHOLDER, tableCodeD)
            .replace(FIELD_CODE_D_PLACEHOLDER, fieldCodeD).replace(UNIQUE_INDEX_PLACEHOLDER, uniqueIndex)
            .replace(NULLABLE_D_PLACEHOLDER, nullableD ? TURE_FLAG : FALSE_FLAG)
            .replace(TABLE_CODE_L_PLACEHOLDER, tableCodeL).replace(FIELD_CODE_L_PLACEHOLDER, fieldCodeL)
            .replace(NULLABLE_L_PLACEHOLDER, nullableL ? TURE_FLAG : FALSE_FLAG);
    }

    @Override
    public Pattern getPlaceholderPattern() {
        return GlobalPlaceholderPatternMagicValue.DB_PLACEHOLDER.getValue();
    }

    @Override
    protected List<FieldCacheInfo> resolvePlaceholderToFieldCacheInfo(String value) throws ExceptionPack {
        try {
            List<FieldCacheInfo> result = new ArrayList<>();
            String[] split1 = value.split(SEPARATOR_3);
            String pre = split1[0].substring(2);
            String[] split2 = pre.split(SEPARATOR_1);
            String[] split3 = split2[2].split(SEPARATOR_2);
            String[] split4 = split1[1].substring(1, split1[1].length() - 2).split(SEPARATOR_1);
            String[] split5 = split4[1].split(SEPARATOR_2);
            // 数据库占位符信息
            String tableCodeD = split2[0];
            String fieldCodeD = split2[1];
            String uniqueIndex = split3[0];
            String nullableD = split3[1];
            // 本地占位符信息
            String tableCodeL = split4[0];
            String fieldCodeL = split5[0];
            String nullableL = split5[1];
            // AssertInjecter.inject(fieldCodeD, "fieldCodeD").and(ObjectJudgementShelf.NOT_EQUAL, uniqueIndex)
            // .judgeAndReturn("The database output field and the query unique index cannot be the same")
            // .and(ObjectJudgementShelf.NOT_EQUAL, fieldCodeL)
            // .judge("The database output field and the local field cannot be the same");
            result.add(new FieldCacheInfo(Long.parseLong(tableCodeD), Long.parseLong(fieldCodeD),
                nullableD.equals(TURE_FLAG), PlaceholderLogicTypeEnum.DB));
            result.add(new FieldCacheInfo(Long.parseLong(tableCodeD), Long.parseLong(uniqueIndex), false,
                PlaceholderLogicTypeEnum.UNIQUE));
            result.add(new FieldCacheInfo(Long.parseLong(tableCodeL), Long.parseLong(fieldCodeL),
                nullableL.equals(TURE_FLAG), PlaceholderLogicTypeEnum.LOCAL));
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("Cannot be resolved to fieldCacheInfo, value: {}", value).build());
        }
    }

    /**
     * @description 获得数据库占位符信息
     * @param dbPlaceholder 待解析的数据库占位符
     * @return 数据库占位符信息
     * @throws ExceptionPack 获取异常
     *
     * @author zhangqi
     * @date 2023/6/26 9:55
     * @initVersion 3.0.1.300
     */
    public DbPlaceholderInfo getDbPlaceholderInfo(String dbPlaceholder) throws ExceptionPack {
        try {
            AssertInjecter.inject(dbPlaceholder, "dbPlaceholder")
                .and(StringJudgementShelf.MATCHES, GlobalPlaceholderPatternMagicValue.DB_PLACEHOLDER.getValue())
                .judge(ExceptionMsg.builder("It is not a database placeholder that cannot be resolved").build());
            String[] split1 = dbPlaceholder.split(SEPARATOR_3);
            String pre = split1[0].substring(2);
            String[] split2 = pre.split(SEPARATOR_1);
            String[] split3 = split2[2].split(SEPARATOR_2);
            // 数据库占位符信息
            String tableCodeD = split2[0];
            String fieldCodeD = split2[1];
            String uniqueIndex = split3[0];
            String nullableD = split3[1];
            // 本地占位符信息
            String local = "$" + split1[1].substring(0, split1[1].length() - 1);
            return new DbPlaceholderInfo(Long.parseLong(tableCodeD), Long.parseLong(fieldCodeD),
                Long.parseLong(uniqueIndex), !nullableD.equals(FALSE_FLAG), local);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg
                    .builder("Unable to parse database placeholders to placeholder information, dbPlaceholder: {}",
                        dbPlaceholder)
                    .build());
        }
    }

    @Override
    Map<String, DbFieldPlaceholder> analysisFieldPlaceholders(List<String> values,
        Map<String, FieldLogicInfo> fieldLogicInfoMap) throws ExceptionPack {
        try {
            Map<String, DbFieldPlaceholder> result = new HashMap<>();
            for (String value : values) {
                List<FieldCacheInfo> fieldCacheInfos = AssertInjecter
                    .inject(resolvePlaceholderToFieldCacheInfo(value), "fieldCacheInfos").and(p -> p.size() == 3)
                    .judgeAndGet(ExceptionMsg.builder("Database placeholder assembly is missing").build());
                FieldCacheInfo fieldCacheInfoDb = fieldCacheInfos.get(0);
                FieldCacheInfo fieldCacheInfoUnique = fieldCacheInfos.get(1);
                FieldCacheInfo fieldCacheInfoLocal = fieldCacheInfos.get(2);
                FieldLogicInfo fieldLogicInfoDb = fieldLogicInfoMap.get(fieldCacheInfoDb.generatePlaceholderKey());
                FieldLogicInfo fieldLogicInfoLocal =
                    fieldLogicInfoMap.get(fieldCacheInfoLocal.generatePlaceholderKey());

                // 内部本地参数
                LocalFieldPlaceholder localFieldPlaceholder =
                    new LocalFieldPlaceholder(fieldCacheInfoLocal.getTableCode(), fieldCacheInfoLocal.getFieldCode(),
                        fieldLogicInfoLocal.getName(), fieldCacheInfoLocal.isNullAble(),
                        fieldLogicInfoLocal.getFieldLogicType(), fieldLogicInfoLocal.getAdditionalValue(), false);
                // 数据库占位符匹配条件本地占位符的维度
                FieldLogicTypeEnum dbFieldLogicType = fieldLogicInfoDb.getFieldLogicType();
                if (fieldLogicInfoLocal.getFieldLogicType().equals(FieldLogicTypeEnum.ASSOCIATION_SET)) {
                    if (dbFieldLogicType.equals(FieldLogicTypeEnum.ASSOCIATION)) {
                        dbFieldLogicType = FieldLogicTypeEnum.ASSOCIATION_SET;
                    }
                    if (dbFieldLogicType.equals(FieldLogicTypeEnum.ENUM)) {
                        dbFieldLogicType = FieldLogicTypeEnum.ENUM_SET;
                    }
                }
                DbFieldPlaceholder dbFieldPlaceholder = new DbFieldPlaceholder(fieldCacheInfoDb.getTableCode(),
                    fieldCacheInfoDb.getFieldCode(), fieldLogicInfoDb.getName(), fieldLogicInfoDb.isNullable(),
                    dbFieldLogicType, fieldLogicInfoDb.getAdditionalValue(), fieldCacheInfoUnique.getFieldCode(),
                    localFieldPlaceholder);

                result.put(value, dbFieldPlaceholder);
            }
            PLACEHOLDER_THREAD_LOCAL.get().putAll(result);
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to resolve local placeholder").build());
        }
    }

    @Override
    public boolean realValueNullableFlag(String value) throws ExceptionPack {
        try {
            AssertInjecter
                .inject(GlobalPlaceholderPatternMagicValue.matchGlobalPlaceholderPatternMagicValue(value),
                    "globalPlaceholderPatternMagicValue")
                .and(ObjectJudgementShelf.EQUAL, GlobalPlaceholderPatternMagicValue.DB_PLACEHOLDER)
                .judge(ExceptionMsg.builder("Not a database placeholder, fail to judge").build());
            String[] split1 = value.split(SEPARATOR_3);
            String pre = split1[0].substring(2);
            String[] split2 = pre.split(SEPARATOR_1);
            String[] split3 = split2[2].split(SEPARATOR_2);
            String[] split4 = split1[1].substring(1, split1[1].length() - 2).split(SEPARATOR_1);
            String[] split5 = split4[1].split(SEPARATOR_2);
            // 数据库占位符信息
            String nullableD = split3[1];
            String nullableL = split5[1];
            return nullableL.equals(TURE_FLAG) || nullableD.equals(TURE_FLAG);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The optional identity of the true value cannot be determined").build());
        }
    }
}
