/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.multivariate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;

import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.calculate.ParamPosition;
import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractMultivariateOperator;

/**
 * @description 求和函数前包裹符 - 后
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/12/11 15:39
 * @version 3.0.1.300
 */
public class SumFunctionBack extends AbstractMultivariateOperator {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 前绝对值
         */
        private static final SumFunctionBack SUM_FUNCTION_FRONT = new SumFunctionBack(")");
    }

    /**
     * @description Constructor
     * @param displaySymbol 显示符号
     *
     * @author zhangqi
     * @date 2023/12/11 18:26
     * @initVersion 3.0.1.300
     */
    private SumFunctionBack(String displaySymbol) {
        super(displaySymbol, "SUM - back", 9);
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static SumFunctionBack getInstance() {
        return SumFunctionBack.INSTANCE.SUM_FUNCTION_FRONT;
    }

    @Override
    protected BigDecimal calculateResult(int scale, BigDecimal... params) throws ExceptionPack {
        return Arrays.stream(params).reduce(BigDecimal.ZERO, BigDecimal::add).setScale(scale, RoundingMode.HALF_UP);
    }

    @Override
    public ParamPosition getParamPosition() {
        return ParamPosition.LEFT;
    }

    @Override
    public AbstractMultivariateOperator getMirrorWrapOperator() {
        return SumFunctionFront.getInstance();
    }
}
