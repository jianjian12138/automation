/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector.turnoff;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.TurnoutJunction;
import org.aerie.forest.dynamic.process.domain.compare.processor.ComparisonExpression;
import org.aerie.forest.dynamic.process.domain.selector.AbstractSelectNode;
import org.aerie.forest.dynamic.process.domain.selector.ValidationParam;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 流程岔道
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/22 9:52
 * @version 3.0.1.300
 */
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public final class SelectTurnoffNode extends AbstractSelectNode<TurnoutJunction> implements Serializable {

    @Serial
    private static final long serialVersionUID = 5024164280658003538L;

    /**
     * @description Constructor
     * @param value 选择节点输出结果
     * @param comparisonExpressions 比较器集合 需要单独的处理器校验
     *
     * @author zhangqi
     * @date 2024/6/26 18:42
     * @initVersion v3.1.1.GA
     */
    @JsonCreator
    public SelectTurnoffNode(@JsonProperty("value") TurnoutJunction value,
        @JsonProperty("comparisonExpressions") List<ComparisonExpression> comparisonExpressions) {
        super(value, comparisonExpressions);
    }

    @Override
    protected SelectTurnoffNode detailedValidation(ValidationParam validationParam) throws ExceptionPack {
        try {
            super.detailedValidation(validationParam);
            return this;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Selector node validation failed").build());
        }
    }

}
