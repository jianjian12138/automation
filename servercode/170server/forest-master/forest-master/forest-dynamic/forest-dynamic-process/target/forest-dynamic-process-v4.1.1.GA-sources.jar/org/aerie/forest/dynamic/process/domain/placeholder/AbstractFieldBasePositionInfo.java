/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Setter;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.db.BaseFieldException;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;

import cn.hutool.core.collection.CollUtil;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * @description 字段基础定位信息
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/29 15:07
 * @version 3.0.1.300
 */
// @NoArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
public abstract class AbstractFieldBasePositionInfo {

    /**
     * @description 表编号
     */
    private final long tableCode;

    /**
     * @description 字段编号
     */
    private final long fieldCode;

    /**
     * @description 名称
     */
    private final String name;

    /**
     * @description 可空标识
     */
    private final boolean nullableFlag;

    /**
     * @description 字段逻辑类型
     */
    private final FieldLogicTypeEnum fieldLogicType;

    /**
     * @description 集合序号
     */
    private final boolean setFlag;

    /**
     * @description 附加属性
     */
    private final String additionalValue;

    /**
     * @description 是否是插入返回的
     */
    private final boolean isInsertReturn;

    /**
     * @description Constructor
     * @param tableCode 表编号
     * @param fieldCode 字段编号
     * @param name 名称
     * @param nullableFlag 可空标识
     * @param fieldLogicType 字段类型
     * @param additionalValue 附加属性
     *
     * @author pms
     * @date 2023/9/20 9:33
     * @initVersion 3.0.1.300
     */
    protected AbstractFieldBasePositionInfo(long tableCode, long fieldCode, String name, boolean nullableFlag,
        FieldLogicTypeEnum fieldLogicType, String additionalValue, boolean isInsertReturn) {
        this.tableCode = tableCode;
        this.fieldCode = fieldCode;
        this.name = name;
        this.nullableFlag = nullableFlag;
        this.fieldLogicType = fieldLogicType;
        this.setFlag = false;
        this.additionalValue = additionalValue;
        this.isInsertReturn = isInsertReturn;
    }

    /**
     * @description Constructor
     * @param tableCode 表编号
     * @param fieldCode 字段编号
     * @param name 名称
     * @param nullableFlag 可空标识
     * @param fieldLogicType 字段类型
     * @param setFlag 集合标识
     * @param additionalValue 附加属性
     *
     * @author pms
     * @date 2023/9/20 9:36
     * @initVersion 3.0.1.300
     */
    protected AbstractFieldBasePositionInfo(long tableCode, long fieldCode, String name, boolean nullableFlag,
        FieldLogicTypeEnum fieldLogicType, boolean setFlag, String additionalValue, boolean isInsertReturn) {
        this.tableCode = tableCode;
        this.fieldCode = fieldCode;
        this.name = name;
        this.nullableFlag = nullableFlag;
        this.fieldLogicType = fieldLogicType;
        this.setFlag = setFlag;
        this.additionalValue = additionalValue;
        this.isInsertReturn = isInsertReturn;
    }

    /**
     * @description 浅相等, 必填标识可以不等
     * @param fieldBasePositionInfo 待比较的字段基础定位信息
     * @return 比较的结果
     *
     * @author zhangqi
     * @date 2023/5/30 21:26
     * @initVersion 3.0.1.300
     */
    public boolean shallowEquals(AbstractFieldBasePositionInfo fieldBasePositionInfo) {
        if (fieldBasePositionInfo == null) {
            return false;
        }
        return this.tableCode == fieldBasePositionInfo.getTableCode()
            && this.fieldCode == fieldBasePositionInfo.getFieldCode();
    }

    /**
     * @description 逻辑相等
     * @param fieldBasePositionInfo 待比较的字段基础定位信息
     * @return 比较结果
     *
     * @author zhangqi
     * @date 2023/5/30 21:22
     * @initVersion 3.0.1.300
     */
    public boolean logicalEquals(AbstractFieldBasePositionInfo fieldBasePositionInfo) {
        if (fieldBasePositionInfo == null) {
            return false;
        }
        return this.tableCode == fieldBasePositionInfo.getTableCode()
            && this.fieldCode == fieldBasePositionInfo.getFieldCode()
            && this.nullableFlag == fieldBasePositionInfo.isNullableFlag();
    }

    /**
     * @description 获得字段基础值
     * @return 字段基础值
     *
     * @author zhangqi
     * @date 2023/5/30 22:12
     * @initVersion 3.0.1.300
     */
    public String getFieldBaseValue() {
        return tableCode + "_" + fieldCode;
    }

    /**
     * @description 根据基础字段去重
     * @param fieldBasePositionInfos 待去重的集合
     * @return 去重后的集合
     *
     * @author zhangqi
     * @date 2023/5/31 10:13
     * @initVersion 3.0.1.300
     */
    public static <T extends AbstractFieldBasePositionInfo> List<T> distinctWithBase(List<T> fieldBasePositionInfos) {
        if (CollUtil.isEmpty(fieldBasePositionInfos)) {
            return new ArrayList<>();
        }
        Map<String, T> result = new HashMap<>();
        for (T fieldBasePositionInfo : fieldBasePositionInfos) {
            result.put(fieldBasePositionInfo.getFieldBaseValue(), fieldBasePositionInfo);
        }
        return new ArrayList<>(result.values());
    }

    /**
     * @description 根据逻辑去重
     * @param fieldBasePositionInfos 待去重的集合
     * @return 去重后的集合
     * @param <T> 去重集合的泛型
     *
     * @author zhangqi
     * @date 2023/5/31 10:40
     * @initVersion 3.0.1.300
     */
    public static <T extends AbstractFieldBasePositionInfo> List<T> distinctLogic(List<T> fieldBasePositionInfos) {
        if (CollUtil.isEmpty(fieldBasePositionInfos)) {
            return new ArrayList<>();
        }
        Map<String, T> result = new HashMap<>();
        for (T fieldBasePositionInfo : fieldBasePositionInfos) {
            T t = result.get(fieldBasePositionInfo.getFieldBaseValue());
            // 不存在或者之前值是非必填, 新增或替换
            if (t == null || t.isNullableFlag()) {
                result.put(fieldBasePositionInfo.getFieldBaseValue(), fieldBasePositionInfo);
            }
        }
        return new ArrayList<>(result.values());
    }

    /**
     * @description 根据基础字段去重并校验可空标识
     * @param fieldBasePositionInfos 待去重的集合
     * @return 去重后的集合
     * @param <T> 去重集合的泛型
     *
     * @author zhangqi
     * @date 2023/6/5 20:54
     * @initVersion 3.0.1.300
     */
    public static <T extends AbstractFieldBasePositionInfo> List<T>
        distinctWithBaseCheckNullable(List<T> fieldBasePositionInfos) throws ExceptionPack {
        try {
            if (CollUtil.isEmpty(fieldBasePositionInfos)) {
                return new ArrayList<>();
            }
            Map<String, T> result = new HashMap<>();
            for (T fieldBasePositionInfo : fieldBasePositionInfos) {
                T t = result.get(fieldBasePositionInfo.getFieldBaseValue());
                // 不存在或者之前值是非必填, 新增或替换
                if (t == null) {
                    result.put(fieldBasePositionInfo.getFieldBaseValue(), fieldBasePositionInfo);
                } else if (t.isNullableFlag() != fieldBasePositionInfo.isNullableFlag()) {
                    throw new BaseFieldException(ExceptionMsg.builder(
                        "There cannot be fields with equal underlying information and inconsistent optional identifiers")
                        .build());
                }
            }
            return new ArrayList<>(result.values());
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Deduplication failure").build());
        }
    }

    // /**
    // * @description 校验字段
    // * @return 查询到的字段传输对象
    // * @throws ExceptionPack 校验异常
    // *
    // * @author zhangqi
    // * @date 2023/5/31 15:30
    // * @initVersion 3.0.1.300
    // */
    // public ModuleTableFieldPpcDTO verifyField(Long ownedEnterpriseCode) throws ExceptionPack {
    // try {
    // ModuleTableFieldPpcDTO fieldsByCodes =
    // getFieldVerifyEnterpriseOwner(this.tableCode, this.fieldCode, ownedEnterpriseCode);
    // ErpAssert.INSTANCE.equalExpectValue(fieldsByCodes.getFieldState(), true, "Field not enabled, fieldCode: {}",
    // this.fieldCode);
    // ErpAssert.INSTANCE.equalExpectValue(Objects.equals(this.tableCode, fieldsByCodes.getTableCode()), true,
    // "The table number and the field number do not match, fieldCode: {}, tableCode: {}", this.fieldCode,
    // this.tableCode);
    // return fieldsByCodes;
    // } catch (Exception e) {
    // throw new ExceptionPack(e, "Validation field failed");
    // }
    // }

    // /**
    // * @description 根据字段编号获取字段传输对象
    // * @param tableCode 表编号
    // * @param fieldCode 字段编号
    // * @return 查询到的字段传输对象
    // * @throws ExceptionPack 查询异常
    // *
    // * @author zhangqi
    // * @date 2023/5/31 16:57
    // * @initVersion 3.0.1.300
    // */
    // protected ModuleTableFieldPpcDTO getFieldVerifyEnterpriseOwner(long tableCode, long fieldCode,
    // Long ownedEnterpriseCode) throws ExceptionPack {
    // try {
    // ModuleTableFieldService moduleTableFieldService =
    // MicgenERPStarter.INSTANCE.getApplicationContext().getBean(ModuleTableFieldService.class);
    // return moduleTableFieldService.getStartedFieldsByCodesAndEnterprise(tableCode, fieldCode,
    // ownedEnterpriseCode);
    // } catch (Exception e) {
    // throw new ExceptionPack(e, "Validation field failed");
    // }
    // }

    /**
     * @description 判断占位符是否可空
     * @return 判断结果
     *
     * @author zhangqi
     * @date 2023/6/18 14:46
     * @initVersion 3.0.1.300
     */
    public abstract boolean isNullable();

    /**
     * @description 生成占位符
     * @return 占位符
     *
     * @author zhangqi
     * @date 2023/6/19 9:15
     * @initVersion 3.0.1.300
     */
    public abstract String generatePlaceholder();
}
