/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain;

/**
 * @description 流程道岔类型枚举
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/11/5 12:01
 * @version 3.0.1.300
 */
public enum TurnoutJunctionTypeEnum {

    /**
     * @description 跳过审批不执行
     */
    SKIP_APPROVAL_AND_INEXECUTION,

    /**
     * @description 跳过审批执行
     */
    SKIP_APPROVAL_AND_EXECUTION,

    /**
     * @description 阻断审批
     */
    BLOCKING_APPROVAL;
}
