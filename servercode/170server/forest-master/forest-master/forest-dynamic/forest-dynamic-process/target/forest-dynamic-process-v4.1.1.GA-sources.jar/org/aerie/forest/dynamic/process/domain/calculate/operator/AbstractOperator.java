/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator;

import java.math.BigDecimal;
import java.util.Arrays;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.ExceptionMsg;

import lombok.Getter;
import org.aerie.forest.core.brick.exception.calculate.OperatorNodeException;
import org.aerie.forest.dynamic.process.domain.calculate.AbstractSymbol;
import org.aerie.forest.dynamic.process.domain.calculate.ParamPosition;

/**
 * @description 运算符
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 14:57
 * @version 3.0.1.300
 */
@Getter
public abstract class AbstractOperator extends AbstractSymbol {

    /**
     * @description 优先级
     */
    private final int priority;

    /**
     * @description Constructor
     * @param displaySymbol 展示的符号
     *
     * @author zhangqi
     * @date 2023/4/19 17:30
     * @initVersion 3.0.1.300
     */
    protected AbstractOperator(String displaySymbol, String operatorName, int priority) {
        super(displaySymbol, operatorName);
        this.priority = priority;
    }

    /**
     * @description 运算符
     * @param scale 精度
     * @param params 运行所需参数
     * @return 运算结果
     *
     * @author zhangqi
     * @date 2023/4/19 14:56
     * @initVersion 3.0.1.300
     */
    public abstract BigDecimal getResult(int scale, BigDecimal... params) throws ExceptionPack;

    /**
     * @description 校验计算参数
     * @param params 计算参数
     * @throws ExceptionPack 校验异常
     *
     * @author zhangqi
     * @date 2023/4/19 16:31
     * @initVersion 3.0.1.300
     */
    protected final void checkParam(BigDecimal... params) throws ExceptionPack {
        try {
            AssertInjecter.injectIfNotNull(params, "").and(p -> p.length > 0)
                .judge(ExceptionMsg.builder("Parameters invalid").build());
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Operation parameter verification failed, params: {}",
                params == null ? null : Arrays.toString(params)).build());
        }
    }

    /**
     * @description 运算符参数位置
     * @return 获得的参数的位置
     *
     * @author zhangqi
     * @date 2023/4/20 9:20
     * @initVersion 3.0.1.300
     */
    public abstract ParamPosition getParamPosition();

    /**
     * @description 校验前置对象
     * @param pre 前置对象
     * @throws OperatorNodeException 校验异常
     *
     * @author zhangqi
     * @date 2023/4/21 16:05
     * @initVersion 3.0.1.300
     */
    public abstract void verifyPre(Object pre) throws OperatorNodeException;

    /**
     * @description 校验后置对象
     * @param next 后置对象
     * @throws OperatorNodeException 校验异常
     *
     * @author zhangqi
     * @date 2023/4/26 9:00
     * @initVersion 3.0.1.300
     */
    public abstract void verifyNext(Object next) throws OperatorNodeException;

}
