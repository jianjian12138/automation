/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare;

import cn.hutool.core.util.StrUtil;
import lombok.Getter;

/**
 * @description 集合比较类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/11/27 16:17
 * @version 3.0.1.300
 */
@Getter
public enum SetComparisonTypeEnum {

    /**
     * @description 存在匹配
     */
    EXISTENCE_MATCH(),

    /**
     * @description 存在不匹配
     */
    EXISTENCE_NOT_MATCH(),

    /**
     * @description 全部匹配
     */
    ALL_MATCH(),

    /**
     * @description 全不匹配
     */
    ALL_NOT_MATCH();

    /**
     * @description 匹配集合比较类型
     * @param setComparisonType 集合比较类型值
     * @return 集合比较类型
     *
     * @author zhangqi
     * @date 2023/11/27 18:36
     * @initVersion 3.0.1.300
     */
    public static SetComparisonTypeEnum getSetComparisonTypeEnum(String setComparisonType) {
        if (StrUtil.isBlank(setComparisonType)) {
            return null;
        }
        for (SetComparisonTypeEnum setComparisonTypeEnum : SetComparisonTypeEnum.values()) {
            if (setComparisonTypeEnum.name().equalsIgnoreCase(setComparisonType)) {
                return setComparisonTypeEnum;
            }
        }
        return null;
    }
}
