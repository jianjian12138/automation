/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base;

import lombok.Getter;
import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractOperator;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic.Addition;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic.Division;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic.Minus;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic.Multiply;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.Opposite;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.Percent;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.wrap.AbsoluteBack;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.wrap.AbsoluteFront;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.wrap.BracketBack;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.wrap.BracketFront;

/**
 * @description 基础运算
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 18:28
 * @version 3.0.1.300
 */
public enum BaseOperatorEnum {

    /**
     * @description 加法
     */
    ADDITION(Addition.getInstance(), "ADDITION"),

    /**
     * @description 减法
     */
    MINUS(Minus.getInstance(), "MINUS"),

    /**
     * @description 乘法
     */
    MULTIPLY(Multiply.getInstance(), "MULTIPLY"),

    /**
     * @description 除法
     */
    DIVISION(Division.getInstance(), "DIVISION"),

    /**
     * @description 相反数
     */
    OPPOSITE(Opposite.getInstance(), "OPPOSITE"),

    /**
     * @description 百分号
     */
    PERCENT(Percent.getInstance(), "PERCENT"),

    /**
     * @description 前括号
     */
    BRACKET_FRONT(BracketFront.getInstance(), "BRACKET_FRONT"),

    /**
     * @description 后括号
     */
    BRACKET_BACK(BracketBack.getInstance(), "BRACKET_BACK"),

    /**
     * @description 前绝对值
     */
    ABSOLUTE_FRONT(AbsoluteFront.getInstance(), "ABSOLUTE_FRONT"),

    /**
     * @description 后绝对值
     */
    ABSOLUTE_BACK(AbsoluteBack.getInstance(), "ABSOLUTE_BACK");

    /**
     * @description 运算符实例[单例]
     */
    @Getter
    private final AbstractOperator operator;

    /**
     * @description 标识
     */
    private final String flag;

    /**
     * @description Constructor
     * @param operator 符号
     *
     * @author zhangqi
     * @date 2023/4/20 15:17
     * @initVersion 3.0.1.300
     */
    BaseOperatorEnum(AbstractOperator operator, String flag) {
        this.operator = operator;
        this.flag = flag;
    }

    /**
     * @description 映射获得枚举值
     * @param operatorValue
     * @return
     *
     * @author zhangqi
     * @date 2023/5/17 15:46
     * @initVersion 3.0.1.300
     */
    public static BaseOperatorEnum getBaseOperatorEnum(String operatorValue) {
        for (BaseOperatorEnum baseOperator : BaseOperatorEnum.values()) {
            if (baseOperator.flag.equals(operatorValue)) {
                return baseOperator;
            }
        }
        return null;
    }
}
