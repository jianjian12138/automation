/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate;

/**
 * @description 参数位置
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/20 9:15
 * @version 3.0.1.300
 */
public enum ParamPosition {

    /**
     * @description 左侧
     */
    LEFT,

    /**
     * @description 右侧
     */
    RIGHT,

    /**
     * @description 两侧
     */
    FLANKS;
}
