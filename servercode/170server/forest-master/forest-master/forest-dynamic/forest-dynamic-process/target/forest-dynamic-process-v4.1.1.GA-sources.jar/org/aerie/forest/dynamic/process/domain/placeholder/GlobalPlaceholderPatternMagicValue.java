/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import java.util.regex.Pattern;

import org.aerie.forest.core.brick.function.PatternMagicValue;

import cn.hutool.core.util.StrUtil;

/**
 * @description 全局占位符正则表达式
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/2/16 13:44
 * @version 3.0.1.300
 */
public enum GlobalPlaceholderPatternMagicValue implements PatternMagicValue {

    /**
     * @description 本地占位符 - 无嵌套占位符 - (特殊符号: - _ !)
     */
    LOCAL_PLACEHOLDER(Pattern.compile("(\\$\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]-[f,t]!?})")),

    /**
     * @description 数据库占位符 - 无嵌套占位符
     */
    DB_PLACEHOLDER(Pattern.compile(
        "(#\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]\\^\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]-[f,t]!?}})")),

    /**
     * @description 运算式占位符 - 嵌套本地、数据库、固定值
     */
    CALCULATION_PLACEHOLDER(Pattern.compile("^(&\\{(?!.*[%*@]).*})$")),

    /**
     * @description 文本操作占位符 - 嵌套本地、数据库、固定值、计算器
     */
    TEXT_MANIPULATION_PLACEHOLDER(Pattern.compile("^(\\*\\{(?!.*@).*})$")),

    /**
     * @description 编码占位符 示例：%{268172000000001234_BJD-YYYYMMDD-4-t} 或者 %{268172000000001234_BJD-YYMMDD-4-t}
     *              无嵌套(里面的表编号和字段编号是用来做redis唯一主键的)
     */
    CODE_PLACEHOLDER(
        Pattern.compile("^%\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}_[A-Z]{1,8}-(yyyy|yyMM|yyMMdd|yyyyMM|yyyyMMdd)-[1-8]}$")),

    /**
     * @description 集合占位符 - 嵌套本地占位符和数据库占位符
     */
    // SET_PLACEHOLDER(Pattern.compile("^@\\{\"pre\":\"((\\$\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]-[f,t]!?})|(#\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]\\^\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]-[f,t]}}))\",\"operation\":\"[UID]\",\"post\":\"((\\$\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]-[f,t]!?})|(#\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]\\^\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[f,t]-[f,t]}}))")),
    SET_PLACEHOLDER(Pattern.compile(
        "^@\\{\"pre\":\"((\\$\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[ft]-[ft]!?})|(#\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}_[1-9]\\d{17,18}-[ft]\\^\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[ft]-[ft]!?}}))\","
            + "\"operation\":\"[UID]\","
            + "\"post\":\"((\\$\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[ft]-[ft]!?})|(#\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}_[1-9]\\d{17,18}-[ft]\\^\\{[1-9]\\d{17,18}_[1-9]\\d{17,18}-[ft]-[ft]!?}}))\"}$"));

    /**
     * @description 值
     */
    private final Pattern value;

    /**
     * @description Constructor
     * @param value 值
     *
     * @author zhangqi
     * @date 2023/2/16 13:45
     * @initVersion 3.0.1.300
     */
    GlobalPlaceholderPatternMagicValue(Pattern value) {
        this.value = value;
    }

    @Override
    public Pattern getValue() {
        return this.value;
    }

    /**
     * @description 匹配占位符正则表达式
     * @param value 待匹配的值
     * @return 匹配的类型
     *
     * @author zhangqi
     * @date 2023/6/12 15:00
     * @initVersion 3.0.1.300
     */
    public static GlobalPlaceholderPatternMagicValue matchGlobalPlaceholderPatternMagicValue(String value) {
        if (StrUtil.isBlank(value)) {
            return null;
        }
        for (GlobalPlaceholderPatternMagicValue placeholderPatternMagicValue : GlobalPlaceholderPatternMagicValue
            .values()) {
            if (placeholderPatternMagicValue.getValue().matcher(value).matches()) {
                return placeholderPatternMagicValue;
            }
        }
        return null;
    }

}
