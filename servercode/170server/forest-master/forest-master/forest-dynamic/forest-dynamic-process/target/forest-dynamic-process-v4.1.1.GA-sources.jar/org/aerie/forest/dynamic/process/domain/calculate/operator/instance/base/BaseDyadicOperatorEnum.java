/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base;


import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractDyadicOperator;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic.Addition;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic.Division;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic.Minus;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic.Multiply;

import lombok.Getter;

/**
 * @description 基础运算
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 18:28
 * @version 3.0.1.300
 */
@Getter
public enum BaseDyadicOperatorEnum {

    /**
     * @description 加法
     */
    ADDITION(Addition.getInstance()),

    /**
     * @description 减法
     */
    MINUS(Minus.getInstance()),

    /**
     * @description 乘法
     */
    MULTIPLY(Multiply.getInstance()),

    /**
     * @description 除法
     */
    DIVISION(Division.getInstance());

    /**
     * @description 运算符实例[单例]
     */
    private final AbstractDyadicOperator dyadicOperator;

    BaseDyadicOperatorEnum(AbstractDyadicOperator dyadicOperator) {
        this.dyadicOperator = dyadicOperator;
    }

}
