/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import static org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum.ASSOCIATION;
import static org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum.ASSOCIATION_SET;
import static org.aerie.forest.dynamic.common.domain.mv.GlobalDynamicalMagicValue.PRIMARY_KEY_VIRTUAL_CODE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.BooleanJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ComparableJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.AbstractForestException;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.common.domain.FieldLogicInfo;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;
import org.aerie.forest.dynamic.common.domain.TableFieldModel;
import org.aerie.forest.dynamic.common.domain.function.TableFieldFunction;
import org.aerie.forest.dynamic.common.domain.function.TableFunction;

import cn.hutool.core.util.StrUtil;

/**
 * @description 本地字段占位符解析器
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/29 15:18
 * @version 3.0.1.300
 */
public final class LocalAbstractFieldPlaceholderResolver
    extends AbstractFieldBasePositionInfoResolver<LocalFieldPlaceholder> {

    /**
     * @description forest静态内部类单例
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/5/3 11:44
     * @version 3.0.1.300
     */
    private static final class ForestInstance {

        /**
         * @description 单例对象
         */
        private static final LocalAbstractFieldPlaceholderResolver LOCAL_FIELD_PLACEHOLDER_RESOLVER =
            new LocalAbstractFieldPlaceholderResolver();
    }

    /**
     * @description 替换标识
     */
    private static final String DETAIL_PLACEHOLDER = "tableCode_fieldCode-nullable-setFlag";

    /**
     * @description 占位符框架
     */
    private static final String PLACEHOLDER_FRAME = "${" + DETAIL_PLACEHOLDER + "}";

    /**
     * @description 表编号占位符
     */
    private static final String TABLE_CODE_PLACEHOLDER = "tableCode";

    /**
     * @description 字段编号占位符
     */
    private static final String FIELD_CODE_PLACEHOLDER = "fieldCode";

    /**
     * @description 可空占位符
     */
    private static final String NULLABLE_PLACEHOLDER = "nullable";

    /**
     * @description 集合占位符
     */
    private static final String SET_PLACEHOLDER = "setFlag";

    /**
     * @description 插入数据标识
     */
    private static final String INSERT_FLAG = "!";

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2023/5/3 11:44
     * @initVersion 3.0.1.300
     */
    private LocalAbstractFieldPlaceholderResolver() {

    }

    /**
     * @description 获得本地字段占位符解析器
     * @return 本地字段占位符解析器
     *
     * @author zhangqi
     * @date 2023/5/4 10:25
     * @initVersion 3.0.1.300
     */
    public static LocalAbstractFieldPlaceholderResolver getInstance() {
        return ForestInstance.LOCAL_FIELD_PLACEHOLDER_RESOLVER;
    }

    /**
     * @description 获得token占位符
     * @param placeholderValue 占位符的值
     * @return token占位符
     *
     * @author pms
     * @date 2023/9/23 17:05
     * @initVersion 3.0.1.300
     */
    public LocalFieldPlaceholder getTokenLocalFieldPlaceholder(String placeholderValue) {
        if (StrUtil.isBlank(placeholderValue)) {
            return null;
        }
        Map<String, LocalFieldPlaceholder> tokenPlaceholderCache = TokenPlaceholder.INSTANCE.getTokenPlaceholder();
        return tokenPlaceholderCache.get(placeholderValue);
    }

    public String getTokenLocalFieldPlaceholderValue(LocalFieldPlaceholder localFieldPlaceholder) {
        if (localFieldPlaceholder == null) {
            return null;
        }
        Map<String, LocalFieldPlaceholder> tokenPlaceholderCache = TokenPlaceholder.INSTANCE.getTokenPlaceholder();
        for (Map.Entry<String, LocalFieldPlaceholder> entry : tokenPlaceholderCache.entrySet()) {
            if (entry.getValue().equals(localFieldPlaceholder)) {
                return entry.getKey();
            }
        }
        return null;
    }

    /**
     * @description 生成占位符
     * @param tableCode 表编号
     * @param fieldCode 字段编号
     * @param nullable 可空标识
     * @param setFlag 集合标识
     * @param insertFlag 插入表示
     * @return 本地占位符
     *
     * @author zhangqi
     * @date 2023/11/29 10:17
     * @initVersion 3.0.1.300
     */
    public String generatePlaceholder(String tableCode, String fieldCode, boolean nullable, boolean setFlag,
        boolean insertFlag) {
        return PLACEHOLDER_FRAME.replace(TABLE_CODE_PLACEHOLDER, tableCode).replace(FIELD_CODE_PLACEHOLDER, fieldCode)
            .replace(NULLABLE_PLACEHOLDER, nullable ? TURE_FLAG : FALSE_FLAG)
            .replace(SET_PLACEHOLDER, (setFlag ? TURE_FLAG : FALSE_FLAG) + (insertFlag ? INSERT_FLAG : ""));
    }

    /**
     * @description 获取本地占位符替换标识
     * @return 本地占位符替换标识
     *
     * @author pms
     * @date 2023/9/18 22:52
     * @initVersion 3.0.1.300
     */
    public String getPlaceholderReplaceFlag() {
        return DETAIL_PLACEHOLDER;
    }

    @Override
    public Pattern getPlaceholderPattern() {
        return GlobalPlaceholderPatternMagicValue.LOCAL_PLACEHOLDER.getValue();
    }

    @Override
    protected List<FieldCacheInfo> resolvePlaceholderToFieldCacheInfo(String value) throws ExceptionPack {
        try {
            List<FieldCacheInfo> result = new ArrayList<>();
            String[] split1 = value.split(SEPARATOR_2);
            String pre = split1[0].substring(2);
            String[] split2 = pre.split(SEPARATOR_1);
            String tableCode = split2[0];
            String fieldCode = split2[1];
            String nullAble = split1[1];
            String setFlag = split1[2].substring(0, 1);
            result.add(
                new FieldCacheInfo(Long.parseLong(tableCode), Long.parseLong(fieldCode), nullAble.equals(TURE_FLAG),
                    split1[2].contains("!") ? PlaceholderLogicTypeEnum.LOCAL_INSERT : PlaceholderLogicTypeEnum.LOCAL,
                    "t".equals(setFlag)));
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Cannot be resolved to fieldCacheInfo").build());
        }
    }

    @Override
    Map<String, LocalFieldPlaceholder> analysisFieldPlaceholders(List<String> values,
        Map<String, FieldLogicInfo> fieldLogicInfoMap) throws ExceptionPack {
        try {
            Map<String, LocalFieldPlaceholder> result = new HashMap<>();
            // 存在
            for (String value : values) {
                List<FieldCacheInfo> fieldCacheInfos = resolvePlaceholderToFieldCacheInfo(value);
                AssertInjecter.inject(fieldCacheInfos.size(), "fieldCacheInfos size")
                    .and(ComparableJudgementShelf.EQUAL_TO, 1)
                    .judge(ExceptionMsg.builder("Database placeholder assembly is missing").build());
                FieldCacheInfo fieldCacheInfo = fieldCacheInfos.get(0);
                FieldLogicInfo fieldLogicInfo = fieldLogicInfoMap.get(fieldCacheInfo.generatePlaceholderKey());
                if (fieldCacheInfo.isSetFlag()) {
                    if (FieldLogicTypeEnum.ENUM.equals(fieldLogicInfo.getFieldLogicType())) {
                        fieldLogicInfo.setFieldLogicType(FieldLogicTypeEnum.ENUM_SET);
                    }
                    if (ASSOCIATION.equals(fieldLogicInfo.getFieldLogicType())) {
                        fieldLogicInfo.setFieldLogicType(ASSOCIATION_SET);
                    }
                }
                LocalFieldPlaceholder localFieldPlaceholder = new LocalFieldPlaceholder(fieldCacheInfo.getTableCode(),
                    fieldCacheInfo.getFieldCode(), fieldLogicInfo.getName(), fieldCacheInfo.isNullAble(),
                    fieldLogicInfo.getFieldLogicType(), fieldCacheInfo.isSetFlag(), fieldLogicInfo.getAdditionalValue(),
                    PlaceholderLogicTypeEnum.LOCAL_INSERT.equals(fieldCacheInfo.getPlaceholderType()));
                result.put(value, localFieldPlaceholder);
            }
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to resolve local placeholder").build());
        }
    }

    @Override
    public boolean realValueNullableFlag(String value) throws ExceptionPack {
        try {
            AssertInjecter
                .inject(GlobalPlaceholderPatternMagicValue.matchGlobalPlaceholderPatternMagicValue(value),
                    "globalPlaceholderPatternMagicValue")
                .and(ObjectJudgementShelf.EQUAL, GlobalPlaceholderPatternMagicValue.LOCAL_PLACEHOLDER)
                .judge(ExceptionMsg.builder("Not a database placeholder, fail to judge").build());
            String[] split1 = value.split(SEPARATOR_2);
            String nullAble = split1[1];
            return nullAble.equals(TURE_FLAG);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The optional identity of the true value cannot be determined").build());
        }
    }

    // /**
    // * @description 转换字段占位符
    // * @param fieldBaseInfos 待转换的字段基本对象集合
    // * @return 转换成的占位符
    // * @throws ExceptionPack 转换异常
    // *
    // * @author zhangqi
    // * @date 2023/6/14 17:11
    // * @initVersion 3.0.1.300
    // */
    // public Map<Long, LocalFieldPlaceholder> changeIntoFieldPlaceholders(List<FieldBaseInfo> fieldBaseInfos,
    // Long ownedEnterpriseCode) throws ExceptionPack {
    // try {
    // ErpAssert.INSTANCE.notNull(fieldBaseInfos, "The set to be parsed cannot be empty");
    // List<FieldCacheInfo> fieldCacheInfos =
    // BeanGraftEnum.INSTANCE.graftList(fieldBaseInfos, FieldCacheInfo.class);
    // fieldCacheInfos.forEach(p -> p.setPlaceholderType(PlaceholderTypeEnum.LOCAL));
    // return generateFieldPlaceholders(fieldCacheInfos, ownedEnterpriseCode);
    // } catch (Exception e) {
    // throw new ExceptionPack(e, ExceptionMsg.builder("").build()"Unable to resolve local placeholder");
    // }
    // }

    /**
     * @description 获得初始化字段占位符
     * @param tableCode 表编号
     * @param enterpriseCode 企业编号
     * @return 初始化字段占位符
     * @throws ExceptionPack 获得异常
     *
     * @author zhangqi
     * @date 2023/6/19 10:06
     * @initVersion 3.0.1.300
     */
    public List<LocalFieldPlaceholder> getInitFieldPlaceholderInfo(TableFunction tableFunction,
        TableFieldFunction fieldFunction, Long tableCode, Long enterpriseCode, boolean setOperationFlag)
        throws ExceptionPack {
        try {
            List<LocalFieldPlaceholder> result =
                new ArrayList<>(TokenPlaceholder.INSTANCE.getTokenPlaceholder().values());
            // 添加关联表的主键占位符
            if (tableCode != null) {
                List<TableFieldModel> setAssociatedFieldList;
                // 若是非集合操作，则再加入外联集合字段所属表的主键占位符
                List<Long> tableCodes = new ArrayList<>();
                tableCodes.add(tableCode);
                Map<Long, String> tableNameMap = tableFunction.getTableNames(tableCodes);
                if (!setOperationFlag) {
                    setAssociatedFieldList = fieldFunction.getSetAssociatedFieldList(tableCode);
                    result.add(new LocalFieldPlaceholder(tableCode, PRIMARY_KEY_VIRTUAL_CODE.getValue(),
                        AssertInjecter.notNullAndGet(tableNameMap.get(tableCode), "") + "编号(入)", false, ASSOCIATION,
                        false, String.valueOf(tableCode), false));
                    setAssociatedFieldList.forEach(setAssociatedField -> {
                        if (setAssociatedField.isCollectionFieldFlag()) {
                            result.add(new LocalFieldPlaceholder(setAssociatedField.getAssociatedTable(),
                                PRIMARY_KEY_VIRTUAL_CODE.getValue(),
                                setAssociatedField.getFieldNameChn() + " - 集合关联编号(入)", setAssociatedField.isNullable(),
                                ASSOCIATION_SET, true, String.valueOf(setAssociatedField.getAssociatedTable()), false));
                            return;
                        }
                        result.add(new LocalFieldPlaceholder(setAssociatedField.getAssociatedTable(),
                            PRIMARY_KEY_VIRTUAL_CODE.getValue(), setAssociatedField.getFieldNameChn() + " - 单关联编号(入)",
                            setAssociatedField.isNullable(), ASSOCIATION, false,
                            String.valueOf(setAssociatedField.getAssociatedTable()), false));
                    });
                    return result;
                }

                // 流程前置集合操作
                result.add(new LocalFieldPlaceholder(tableCode, PRIMARY_KEY_VIRTUAL_CODE.getValue(),
                    AssertInjecter.notNullAndGet(tableNameMap.get(tableCode), "") + "集合编号(入)", false, ASSOCIATION_SET,
                    true, String.valueOf(tableCode), false));
            }
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("Could not get process initialization local parameters").build());
        }
    }

    /**
     * @description 提取本地占位符的model值
     * @param localPlaceholder 本地占位符
     * @return model值
     * @throws ExceptionPack 提取异常
     *
     * @author zhangqi
     * @date 2023/6/27 13:48
     * @initVersion 3.0.1.300
     */
    public String getModelValue(String localPlaceholder) throws ExceptionPack {
        try {
            matchLocalPlaceholder(localPlaceholder);
            return localPlaceholder.substring(2, localPlaceholder.indexOf("-"));
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The mode value cannot be advanced").build());
        }
    }

    /**
     * @description 获得本地占位符中的字段编号
     * @param localPlaceholder 本地占位符
     * @return fieldCode
     * @throws ExceptionPack 获得异常
     *
     * @author zhangqi
     * @date 2023/7/9 16:05
     * @initVersion 3.0.1.300
     */
    public long getFieldCode(String localPlaceholder) throws ExceptionPack {
        try {
            matchLocalPlaceholder(localPlaceholder);
            String[] split1 = localPlaceholder.split(SEPARATOR_2);
            String pre = split1[0].substring(2);
            String[] split2 = pre.split(SEPARATOR_1);
            return Long.parseLong(split2[1]);
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Failed to get the field code").build());
        }
    }

    /**
     * @description 获得本地占位符的可空标识
     * @param localPlaceholder 待解析的本地占位符
     * @return 可空标识
     * @throws ExceptionPack 获得异常
     *
     * @author zhangqi
     * @date 2023/6/27 17:01
     * @initVersion 3.0.1.300
     */
    public boolean getNullableFlag(String localPlaceholder) throws ExceptionPack {
        try {
            matchLocalPlaceholder(localPlaceholder);
            return localPlaceholder.startsWith(TURE_FLAG, localPlaceholder.indexOf("-") + 1);
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Failed to resolve the optional flag").build());
        }
    }

    /**
     * @description 匹配本地占位符
     * @param localPlaceholder 本地占位符
     * @throws AbstractForestException 匹配异常
     *
     * @author pms
     * @date 2023/9/5 11:18
     * @initVersion 3.0.1.300
     */
    private void matchLocalPlaceholder(String localPlaceholder) throws AbstractForestException {
        AssertInjecter.inject(match(localPlaceholder), "match").and(BooleanJudgementShelf.IS_TRUE)
            .judge(ExceptionMsg
                .builder("model values cannot be extracted unless they are local placeholders, localPlaceholder: {}",
                    localPlaceholder)
                .build());
    }
}
