/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractDyadicOperator;

/**
 * @description 加法
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 16:43
 * @version 3.0.1.300
 */
public final class Addition extends AbstractDyadicOperator {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 加法
         */
        private static final Addition ADDITION = new Addition("+");
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static Addition getInstance() {
        return INSTANCE.ADDITION;
    }

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     *
     * @author zhangqi
     * @date 2023/4/19 17:32
     * @initVersion 3.0.1.300
     */
    private Addition(String displaySymbol) {
        super(displaySymbol, "Addition", 2);
    }

    @Override
    protected BigDecimal calculateResult(int scale, BigDecimal front, BigDecimal back) throws ExceptionPack {
        try {
            return front.add(back).setScale(scale, RoundingMode.HALF_UP);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The addition calculation failed, front: {}, back: {}", front, back).build());
        }
    }
}
