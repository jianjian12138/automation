/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.comparable;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.pact.time.TimeFormatEnum;
import org.aerie.forest.core.brick.pact.time.TimeTypeEnum;

/**
 * @description 时间
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 14:23
 * @version 3.0.1.300
 */
public final class TimeValue extends AbstractTimeValue<LocalTime> {

    /**
     * @description Constructor
     * @param value 值
     *
     * @author zhangqi
     * @date 2023/5/18 14:37
     * @initVersion 3.0.1.300
     */
    TimeValue(String value, TimeFormatEnum timeFormatEnum) {
        super(value, timeFormatEnum);
    }

    @Override
    public LocalTime getComparableValue(boolean canBeNull) throws ExceptionPack {
        try {
            if (canBeNull && value == null) {
                return null;
            }
            AssertInjecter.inject(value, "value").and(ObjectJudgementShelf.NOT_NULL).or().and(() -> canBeNull)
                .judge(ExceptionMsg.builder("The value to be compared cannot be null").build());
            AssertInjecter.inject(timeFormat, "timeFormat").and(p -> TimeTypeEnum.checkTimeType(p, 2))
                .judge(ExceptionMsg.builder("The time format is not valid").build());
            return LocalTime.parse(value, DateTimeFormatter.ofPattern(timeFormat.getTimeFormat()));
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg
                    .builder("The time could not be obtained, value: {}, format: {}", value, timeFormat.getTimeFormat())
                    .build());
        }
    }
}
