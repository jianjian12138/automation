/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain._shelf;

import org.aerie.forest.core.frame.rebar.factory.ForestShelf;
import org.aerie.forest.dynamic.process.domain.calculate.processor.operation.OperationProcessor;
import org.aerie.forest.dynamic.process.domain.calculate.processor.show.ShowProcessor;
import org.aerie.forest.dynamic.process.domain.compare.processor.Comparator;
import org.aerie.forest.dynamic.process.domain.compare.processor.ComparatorLogicCombinatorialCalibrator;

/**
 * @description forest动态流程货架
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2022/11/22 20:29
 * @version 3.0.1.300
 */
public final class ForestDpShelf extends ForestShelf {

    /**
     * @description forest静态内部类单例
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2022/11/22 20:28
     * @version 3.0.1.300
     */
    private static final class ForestInstance {

        /**
         * @description 动态模块货架单例
         */
        private static final ForestDpShelf FOREST_DP_SHELF = new ForestDpShelf();
    }

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2022/11/22 20:29
     * @initVersion 3.0.1.300
     */
    private ForestDpShelf() {
        super("forest动态流程货架");
    }

    /**
     * @description 获得forest架构元素动态模块货架单例
     * @return forest架构元素动态模块货架单例
     *
     * @author zhangqi
     * @date 2022/11/22 20:29
     * @initVersion 3.0.1.300
     */
    public static ForestDpShelf getInstance() {
        return ForestInstance.FOREST_DP_SHELF;
    }

    /**
     * @description 运算展示处理器
     */

    public final RebarScutcheon<ShowProcessor> showProcessor = new RebarScutcheon<>() {

    };

    /**
     * @description 运算处理器
     */
    public final RebarScutcheon<OperationProcessor> operationProcessor = new RebarScutcheon<>() {

    };

    /**
     * @description 比较器
     */
    public final RebarScutcheon<Comparator> comparator = new RebarScutcheon<>() {

    };

    /**
     * @description 比较器组合逻辑校验器
     */
    public final RebarScutcheon<
        ComparatorLogicCombinatorialCalibrator> comparatorLogicCombinatorialCalibratorRebarScutcheon =
            new RebarScutcheon<>() {

            };

}
