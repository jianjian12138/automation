/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.operator.boole;

import java.util.Objects;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.compare.AbstractBooleanSymbol;
import org.aerie.forest.dynamic.process.domain.compare.comparable.BooleanValue;

/**
 * @description 布尔比较 等于
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 17:59
 * @version 3.0.1.300
 */
public final class BooleanUnEqual extends AbstractBooleanSymbol {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 布尔不相等
         */
        private static final BooleanUnEqual BOOLEAN_UN_EQUAL = new BooleanUnEqual();
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static BooleanUnEqual getInstance() {
        return INSTANCE.BOOLEAN_UN_EQUAL;
    }

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2023/5/15 17:14
     * @initVersion 3.0.1.300
     */
    private BooleanUnEqual() {
        super("!=", "不等于", false, "BOOLEAN_UN_EQUAL");
    }

    @Override
    protected boolean compare(BooleanValue pre, BooleanValue post) throws ExceptionPack {
        try {
            return !Objects.equals(pre.getComparableValue(false), post.getComparableValue(false));
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to compare successfully, comparison expression: {}",
                pre.getValue() + getDisplaySymbol() + post.getValue()).build());
        }
    }

}
