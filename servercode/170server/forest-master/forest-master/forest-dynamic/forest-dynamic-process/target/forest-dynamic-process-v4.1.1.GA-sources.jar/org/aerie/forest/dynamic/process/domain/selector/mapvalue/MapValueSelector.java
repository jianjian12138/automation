/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector.mapvalue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.process.ProcessNodeException;
import org.aerie.forest.dynamic.process.domain.placeholder.AbstractFieldBasePositionInfo;
import org.aerie.forest.dynamic.process.domain.placeholder.LocalFieldPlaceholder;
import org.aerie.forest.dynamic.process.domain.selector.AbstractSelector;
import org.aerie.forest.dynamic.process.domain.selector.ValidationParam;

import com.fasterxml.jackson.annotation.JsonIgnore;

import cn.hutool.core.collection.CollUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 选择器
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/22 9:52
 * @version 3.0.1.300
 */
@AllArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public final class MapValueSelector extends AbstractSelector<SelectMapValueNode, String> {

    @JsonIgnore
    @Override
    public String getResult(Map<String, String> placeholderValueMap) throws ExceptionPack {
        try {
            return super.getResult(placeholderValueMap);
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The selector cannot get the result").build());
        }
    }

    @Override
    protected MapValueSelector detailedValidation(ValidationParam validationParam) throws ExceptionPack {
        try {
            super.detailedValidation(validationParam);
            if (!validationParam.isNullAble()) {
                if (!CollUtil.isEmpty(selectNodes.getLast().getComparisonExpressions())) {
                    throw new ProcessNodeException("必填字段的映射的选择器的最后一个比较器必须是空",
                        "The last comparator of a selector for a mapping of required fields must be empty");
                }
            }
            return this;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The mapValue selector is invalid").build());
        }
    }

    @Override
    protected List<LocalFieldPlaceholder> detailedNeedProvideFields() throws ExceptionPack {
        try {
            if (CollUtil.isEmpty(selectNodes)) {
                return new ArrayList<>();
            }
            List<LocalFieldPlaceholder> result = new ArrayList<>();
            for (SelectMapValueNode selectMapValueNode : selectNodes) {
                List<LocalFieldPlaceholder> localFieldPlaceholders = selectMapValueNode.needProvideFields();
                result.addAll(localFieldPlaceholders);
            }
            return AbstractFieldBasePositionInfo.distinctWithBaseCheckNullable(result);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The field information to be used cannot be obtained").build());
        }
    }

    @JsonIgnore
    @Override
    public List<String> getAllPlaceholderValue() {
        List<String> result = new ArrayList<>();
        selectNodes.forEach(p -> result.addAll(p.getAllPlaceholderValue()));
        return result;
    }
}
