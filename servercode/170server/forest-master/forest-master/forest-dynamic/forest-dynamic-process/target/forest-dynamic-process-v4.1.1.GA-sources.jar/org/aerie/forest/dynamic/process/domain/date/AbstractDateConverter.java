/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.date;

import java.time.LocalDateTime;

import org.aerie.forest.core.brick.exception.AbstractForestException;
import org.aerie.forest.core.brick.function.verify.self.SelfVerifiableByParam;

/**
 * @description 时间转化器 - // TODO 设计时的参数校验后面要处理， 目前通过前后端的严格匹配处理
 *
 * @author quark
 * @organization futurecraftsmen
 * @date 2024/4/29 14:37
 * @version v3.1.1.GA
 */
public abstract class AbstractDateConverter<T, R> implements SelfVerifiableByParam<T, T, AbstractForestException> {

    /**
     * @description 转化的实际操作
     * @param localDateTime 待转化的本地时间
     * @param param 需要的参数
     * @return 转化后的本地时间
     * @throws AbstractForestException 转化异常
     *
     * @author quark
     * @date 2024/4/29 14:38
     * @initVersion v3.1.1.GA
     */
    protected abstract R transformAction(LocalDateTime localDateTime, T param) throws AbstractForestException;

    /**
     * @description 转化
     * @param localDateTime 待转化的本地时间
     * @param param 需要的参数
     * @return 转化后的本地时间
     * @throws AbstractForestException 转化异常
     *
     * @author quark
     * @date 2024/4/30 10:26
     * @initVersion v3.1.1.GA
     */
    public final R transform(LocalDateTime localDateTime, T param) throws AbstractForestException {
        return transformAction(localDateTime, verify(param));
    }
}