/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.CollectionJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.selector.UnselectedException;
import org.aerie.forest.core.brick.log.GlobalLogger;
import org.aerie.forest.dynamic.process.domain.calculate.ContinueFieldsLump;
import org.aerie.forest.dynamic.process.domain.placeholder.AbstractFieldBasePositionInfo;
import org.aerie.forest.dynamic.process.domain.placeholder.LocalFieldPlaceholder;

import com.fasterxml.jackson.annotation.JsonIgnore;

import cn.hutool.core.collection.CollUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 选择器
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/22 9:52
 * @version 3.0.1.300
 */
@AllArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractSelector<T extends AbstractSelectNode<V>, V extends Serializable>
    extends ContinueFieldsLump<AbstractSelector<T, V>, ValidationParam> implements GlobalLogger {

    @Serial
    private static final long serialVersionUID = -2578943544580365890L;
    /**
     * @description 选择结点
     */
    protected final List<T> selectNodes = new ArrayList<>();

    @Override
    protected List<String> detailedAllParameterPlaceholder() {
        if (CollUtil.isEmpty(selectNodes)) {
            return new ArrayList<>();
        }
        List<String> result = new ArrayList<>();
        for (T t : selectNodes) {
            List<String> localFieldPlaceholders = t.obtainAllParameterPlaceholder();
            result.addAll(localFieldPlaceholders);
        }
        return result;
    }

    /**
     * @description 获得结果
     * @return 结果
     * @throws ExceptionPack 匹配失败
     *
     * @author zhangqi
     * @date 2023/5/22 11:29
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public V getResult(Map<String, String> placeholderValueMap) throws Exception {
        try {
            for (T t : AssertInjecter.inject(selectNodes, "select nodes").and(CollectionJudgementShelf.NOT_EMPTY)
                .judgeAndGet(ExceptionMsg.builder("The selection node cannot be empty").build())) {
                try {
                    return t.getResult(placeholderValueMap);
                } catch (UnselectedException e) {
                    // 没有命中, 继续下一个选择节点
                    LOGGER.trace("Selector missed, move on to the next one");
                }
            }
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The selector cannot get the result").build());
        }
        // // 全部未命中
        // throw new UnselectedException("Failed to match each comparator in the selector");
        return null;
    }

    @Override
    protected AbstractSelector<T, V> detailedValidation(ValidationParam validationParam) throws ExceptionPack {
        try {
            AssertInjecter.inject(selectNodes, "selectNodes").and(CollectionJudgementShelf.NOT_EMPTY)
                .judge(ExceptionMsg.builder("The selected node cannot be empty").build());
            for (T t : selectNodes) {
                t.verify(validationParam);
            }
            for (int index = 0; index < selectNodes.size() - 1; index++) {
                AssertInjecter.inject(selectNodes.get(index).getComparisonExpressions(), "pre comparison expressions")
                    .and(CollectionJudgementShelf.NOT_EMPTY)
                    .judge(ExceptionMsg.builder("The non-last set of comparators for a selector cannot be empty")
                        .msgView("选择器的非最后一组比较器不能为空").build());
            }
            return this;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The selector is invalid").build());
        }
    }

    @Override
    protected List<LocalFieldPlaceholder> detailedNeedProvideFields() throws ExceptionPack {
        try {
            List<LocalFieldPlaceholder> result = new ArrayList<>();
            for (T t : selectNodes) {
                List<LocalFieldPlaceholder> localFieldPlaceholders = t.needProvideFields();
                result.addAll(localFieldPlaceholders);
            }
            return AbstractFieldBasePositionInfo.distinctWithBaseCheckNullable(result);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The field information to be used cannot be obtained").build());
        }
    }

    @Override
    protected final List<LocalFieldPlaceholder> detailedProvidedFields() throws ExceptionPack {
        // 选择器无法提供任何字段
        return new ArrayList<>();
    }

    @JsonIgnore
    @Override
    public List<String> getAllPlaceholderValue() {
        List<String> result = new ArrayList<>();
        selectNodes.forEach(p -> result.addAll(p.getAllPlaceholderValue()));
        return result;
    }

    @Deprecated
    public List<V> obtainOutputList() {
        return selectNodes.stream().map(AbstractSelectNode::output).collect(Collectors.toList());
    }
}
