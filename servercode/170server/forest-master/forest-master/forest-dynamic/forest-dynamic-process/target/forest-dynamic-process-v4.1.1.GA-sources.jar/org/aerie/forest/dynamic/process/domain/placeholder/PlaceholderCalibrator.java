/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.JudgmentExecutor;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;

/**
 * @description 占位符校验器
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/6/1 10:10
 * @version 3.0.1.300
 */
public interface PlaceholderCalibrator {

    /**
     * @description 校验占位符真实字段类型 - 本地占位符和数据库占位符 存在字段类型
     * @param value 待比较的值
     * @throws ExceptionPack 校验异常
     *
     * @author zhangqi
     * @date 2023/5/31 22:10
     * @initVersion 3.0.1.300
     */
    default AbstractFieldBasePositionInfo verifyPlaceholderRealFieldType(String value,
        FieldLogicTypeEnum fieldLogicTypeEnum, boolean nullAble) throws ExceptionPack {
        try {
            AbstractFieldBasePositionInfo fieldBasePositionInfo = null;
            LocalFieldPlaceholder tokenLocalFieldPlaceholder =
                LocalAbstractFieldPlaceholderResolver.getInstance().getTokenLocalFieldPlaceholder(value);
            if (tokenLocalFieldPlaceholder != null) {
                fieldBasePositionInfo = tokenLocalFieldPlaceholder;
            } else if (GlobalPlaceholderPatternMagicValue.LOCAL_PLACEHOLDER.getValue().matcher(value).matches()
                || GlobalPlaceholderPatternMagicValue.DB_PLACEHOLDER.getValue().matcher(value).matches()) {
                fieldBasePositionInfo = AssertInjecter
                    .inject(
                        AbstractFieldBasePositionInfoResolver.getFieldBasePositionInfo(value), "fieldBasePositionInfo")
                    .and(ObjectJudgementShelf.NOT_NULL)
                    .judgeAndGet(ExceptionMsg
                        .builder("Placeholder cache no, the previous unified query field information is incomplete")
                        .build());
            }
            // 不是占位符无需校验
            if (fieldBasePositionInfo == null) {
                return null;
            }
            AssertInjecter.inject(fieldLogicTypeEnum, "fieldLogicTypeEnum")
                .and(ObjectJudgementShelf.EQUAL, fieldBasePositionInfo.getFieldLogicType())
                .judge(ExceptionMsg.builder("Mismatched field types, fieldType: {}, comparableType: {}",
                    fieldBasePositionInfo.getFieldLogicType(), JudgmentExecutor.This.INSTANCE).build());
            AssertInjecter.inject(fieldBasePositionInfo, "fieldBasePositionInfo").and(() -> nullAble).or()
                .and(p -> p.isNullableFlag() == nullAble)
                .judge(ExceptionMsg.builder("Field placeholder optional is incorrectly identified").build());
            return fieldBasePositionInfo;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Comparator field type match failed").build());
        }
    }
}