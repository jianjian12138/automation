/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.compare.CompareException;
import org.aerie.forest.dynamic.common.domain.FieldLogicTypeEnum;
import org.aerie.forest.dynamic.process.domain.compare.comparable.AbstractComparable;
import org.aerie.forest.dynamic.process.domain.compare.comparable.BooleanValue;
import org.aerie.forest.dynamic.process.domain.compare.operator.boole.BooleanIsNull;
import org.aerie.forest.dynamic.process.domain.compare.operator.boole.BooleanNotNull;
import org.aerie.forest.dynamic.process.domain.placeholder.GlobalPlaceholderFixedPatternMagicValue;

import com.fasterxml.jackson.annotation.JsonIgnore;

import cn.hutool.core.util.StrUtil;

/**
 * @description 布尔符号
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/17 9:50
 * @version 3.0.1.300
 */
public abstract class AbstractBooleanSymbol extends AbstractCompareSymbol<BooleanValue> {

    /**
     * @description false
     */
    private static final String FALSE_VALUE = "false";

    /**
     * @description true
     */
    private static final String TRUE_VALUE = "true";

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     * @param operatorName 符号名称
     * @param paramNullableFlag 参数可空标识
     * @param flag 标识
     *
     * @author zhangqi
     * @date 2023/5/17 9:49
     * @initVersion 3.0.1.300
     */
    protected AbstractBooleanSymbol(String displaySymbol, String operatorName, boolean paramNullableFlag, String flag) {
        super(displaySymbol, operatorName, FieldLogicTypeEnum.BOOLEAN, paramNullableFlag, flag);
    }

    @Override
    public BooleanValue generateComparable(String value) throws ExceptionPack {
        try {
            if (NULL_FLAG.equals(value)) {
                return null;
            }
            if (StrUtil.isBlank(value)) {
                return new BooleanValue(null);
            }
            if (FALSE_VALUE.equals(value)) {
                return new BooleanValue(false);
            }
            if (TRUE_VALUE.equals(value)) {
                return new BooleanValue(true);
            }
            throw new CompareException(ExceptionMsg.builder("Cannot match a Boolean value").build());
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to map Boolean fields").build());
        }
    }

    @Override
    public String checkComparable(String value) throws ExceptionPack {
        try {
            if (NULL_FLAG.equals(value)) {
                return null;
            }
            if (GlobalPlaceholderFixedPatternMagicValue.FIXED_VALUE_BOOLEAN.getValue().matcher(value).matches()) {
                return null;
            }
            if (verifyPlaceholderRealFieldType(value, fieldLogicTypeEnum, true) != null) {
                return null;
            }
            throw new CompareException(ExceptionMsg.builder("Cannot match a Boolean value").build());
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to map Boolean fields").build());
        }
    }

    /**
     * @description 获得判空符号
     * @return 判空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:40
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public final AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNullSymbol() {
        return BooleanIsNull.getInstance();
    }

    /**
     * @description 获得判非空符号
     * @return 判非空符号
     *
     * @author zhangqi
     * @date 2023/12/25 15:41
     * @initVersion 3.0.1.300
     */
    @JsonIgnore
    public final AbstractCompareSymbol<? extends AbstractComparable<?, ?>> getJudgeNotNullSymbol() {
        return BooleanNotNull.getInstance();
    }
}
