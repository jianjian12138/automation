/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.dyadic;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractDyadicOperator;

/**
 * @description 乘法
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/19 16:43
 * @version 3.0.1.300
 */
public class Multiply extends AbstractDyadicOperator {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 乘法
         */
        private static final Multiply MULTIPLY = new Multiply("*");
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static Multiply getInstance() {
        return INSTANCE.MULTIPLY;
    }

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     *
     * @author zhangqi
     * @date 2023/4/19 17:32
     * @initVersion 3.0.1.300
     */
    private Multiply(String displaySymbol) {
        super(displaySymbol, "Multiply", 6);
    }

    @Override
    protected BigDecimal calculateResult(int scale, BigDecimal front, BigDecimal back) throws ExceptionPack {
        try {
            return front.multiply(back).setScale(scale, RoundingMode.HALF_UP);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The multiply calculation failed, front: {}, back: {}", front, back).build());
        }
    }
}
