/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.placeholder.PlaceholderRuntimeException;
import org.aerie.forest.core.brick.function.verify.self.AbstractSelfVerifiableByParam;
import org.aerie.forest.dynamic.process.domain.placeholder.*;

import cn.hutool.core.util.StrUtil;

/**
 * @description 承接字段
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/28 17:12
 * @version 3.0.1.300
 */
public abstract class ContinueFieldsLump<T, V> extends AbstractSelfVerifiableByParam<T, V, ExceptionPack> implements Serializable {

    @Serial
    private static final long serialVersionUID = -767305351421279195L;

    /**
     * @description 获得所有的参数占位符 - 参数占位符就是原来的固定值占位符
     * @return 所有的参数占位符
     *
     * @author zhangqi
     * @date 2024/8/22 11:30
     * @initVersion v4.0.1.GA
     */
    public final List<String> obtainAllParameterPlaceholder() {
        return detailedAllParameterPlaceholder();
    }

    /**
     * @description 详细活动所有的参数占位符 - 参数占位符就是原来的固定值占位符
     * @return 所有的参数占位符
     *
     * @author zhangqi
     * @date 2024/8/22 11:30
     * @initVersion v4.0.1.GA
     */
    protected abstract List<String> detailedAllParameterPlaceholder();

    /**
     * @description 获取需要提供的字段
     * @return 需要提供的字段
     * @throws ExceptionPack 获取异常
     *
     * @author zhangqi
     * @date 2023/5/26 17:47
     * @initVersion 3.0.1.300
     */
    public final List<LocalFieldPlaceholder> needProvideFields() throws ExceptionPack {
        try {
            return detailedNeedProvideFields();
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The required field could not be obtained").build());
        }
    }

    /**
     * @description 获取需要提供的字段
     * @return 需要提供的字段
     * @throws ExceptionPack 获取异常
     *
     * @author zhangqi
     * @date 2023/5/26 17:47
     * @initVersion 3.0.1.300
     */
    protected abstract List<LocalFieldPlaceholder> detailedNeedProvideFields() throws ExceptionPack;

    /**
     * @description 获取可以提供的字段
     * @return 可以提供的字段
     * @throws ExceptionPack 获取异常
     *
     * @author zhangqi
     * @date 2023/5/28 17:11
     * @initVersion 3.0.1.300
     */
    public final List<LocalFieldPlaceholder> providedFields() throws ExceptionPack {
        try {
            return detailedProvidedFields();
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("The required field could not be obtained").build());
        }
    }

    /**
     * @description 获取可以提供的字段
     * @return 可以提供的字段
     * @throws ExceptionPack 获取异常
     *
     * @author zhangqi
     * @date 2023/11/26 10:18
     * @initVersion 3.0.1.300
     */
    protected abstract List<LocalFieldPlaceholder> detailedProvidedFields() throws ExceptionPack;

    /**
     * @description 获得所有的占位符
     * @return 所有的占位符
     *
     * @author zhangqi
     * @date 2023/6/16 16:53
     * @initVersion 3.0.1.300
     */
    public abstract List<String> getAllPlaceholderValue() throws ExceptionPack;

    /**
     * @description 解析出所有的占位符
     * @param value 待解析的值
     * @return 解析出的占位符值
     *
     * @author zhangqi
     * @date 2023/6/16 17:13
     * @initVersion 3.0.1.300
     */
    public static List<String> resolveAllPlaceholderValue(String value) {
        if (StrUtil.isBlank(value)) {
            return new ArrayList<>();
        }
        List<String> result = new ArrayList<>();
        LocalFieldPlaceholder tokenLocalFieldPlaceholder =
            LocalAbstractFieldPlaceholderResolver.getInstance().getTokenLocalFieldPlaceholder(value);
        if (tokenLocalFieldPlaceholder != null) {
            result.add(value);
            return result;
        }
        if (DBAbstractFieldPlaceholderResolver.getInstance().match(value)) {
            result.add(value);
            return result;
        }
        if (LocalAbstractFieldPlaceholderResolver.getInstance().match(value)) {
            result.add(value);
            return result;
        }
        if (SetFieldPlaceholderResolver.getInstance().match(value)) {
            result.addAll(SetFieldPlaceholderResolver.getInstance().resolve2Placeholders(value));
        }
        if (GlobalPlaceholderPatternMagicValue.CALCULATION_PLACEHOLDER.getValue().matcher(value).matches()) {
            Matcher matcherDb = GlobalPlaceholderPatternMagicValue.DB_PLACEHOLDER.getValue().matcher(value);
            while (matcherDb.find()) {
                result.add(matcherDb.group());
            }
            Matcher matcherLocal = GlobalPlaceholderPatternMagicValue.LOCAL_PLACEHOLDER.getValue().matcher(value);
            while (matcherLocal.find()) {
                result.add(matcherLocal.group());
            }
        }
        if (GlobalPlaceholderPatternMagicValue.TEXT_MANIPULATION_PLACEHOLDER.getValue().matcher(value).matches()) {
            String substring = value.substring(2, value.length() - 1);
            String[] split = substring.split("\\|\\|");
            String textFlag = split[0];
            // 截取
            if (TextManipulationTypeEnum.SUBSTRING.getValue().equals(textFlag)) {
                // 截取的第二个参数是待截取的字符, 可能是本地或者数据库占位符
                result.addAll(resolveAllPlaceholderValue(split[1]));
            } else if (TextManipulationTypeEnum.CONCAT.getValue().equals(textFlag)) {
                // 拼接的第二个开始后面的都可能是本地或者数据库占位符或者计算器占位符
                int length = split.length;
                for (int index = 1; index < length; index++) {
                    result.addAll(resolveAllPlaceholderValue(split[index]));
                }
            } else if (TextManipulationTypeEnum.SECRET.getValue().equals(textFlag)) {
                // 加密的第二个参数是待加密的字符, 可能是本地或者数据库占位符
                result.addAll(resolveAllPlaceholderValue(split[1]));
            } else {
                throw new PlaceholderRuntimeException("Invalid text editing placeholder");
            }
        }
        // TODO 其他的占位符
        return result;
    }

    /**
     * @description 解析所有的本地占位符
     * @param value 待解析的值
     * @return 本地占位符
     * @throws ExceptionPack 获取异常
     *
     * @author zhangqi
     * @date 2023/6/18 22:19
     * @initVersion 3.0.1.300
     */
    public static List<LocalFieldPlaceholder> resolveAllLocalPlaceholder(String value) throws ExceptionPack {
        try {
            if (StrUtil.isBlank(value)) {
                return new ArrayList<>();
            }
            List<LocalFieldPlaceholder> result = new ArrayList<>();
            LocalFieldPlaceholder tokenLocalFieldPlaceholder =
                LocalAbstractFieldPlaceholderResolver.getInstance().getTokenLocalFieldPlaceholder(value);
            if (tokenLocalFieldPlaceholder != null) {
                result.add(tokenLocalFieldPlaceholder);
                return result;
            }
            if (DBAbstractFieldPlaceholderResolver.getInstance().match(value)) {
                result.add(DBAbstractFieldPlaceholderResolver.getInstance().getFieldBasePositionInfoByType(value)
                    .getLocalFieldPlaceholder());
                return result;
            }
            if (LocalAbstractFieldPlaceholderResolver.getInstance().match(value)) {
                result.add(LocalAbstractFieldPlaceholderResolver.getInstance().getFieldBasePositionInfoByType(value));
                return result;
            }
            if (GlobalPlaceholderPatternMagicValue.SET_PLACEHOLDER.getValue().matcher(value).matches()) {
                // 集合占位符的 pre 和 post 均必须是本地占位符或者数据库占位符
                List<String> placeholderList = SetFieldPlaceholderResolver.getInstance().resolve2Placeholders(value);
                for (String placeholder : placeholderList) {
                    result.addAll(resolveAllLocalPlaceholder(placeholder));
                }
                return result;
            }
            if (GlobalPlaceholderPatternMagicValue.CALCULATION_PLACEHOLDER.getValue().matcher(value).matches()) {
                Matcher matcherLocal = GlobalPlaceholderPatternMagicValue.LOCAL_PLACEHOLDER.getValue().matcher(value);
                while (matcherLocal.find()) {
                    result.addAll(resolveAllLocalPlaceholder(matcherLocal.group()));
                }
                Matcher matcherDb = GlobalPlaceholderPatternMagicValue.DB_PLACEHOLDER.getValue().matcher(value);
                while (matcherDb.find()) {
                    result.addAll(resolveAllLocalPlaceholder(matcherDb.group()));
                }
            }
            if (GlobalPlaceholderPatternMagicValue.TEXT_MANIPULATION_PLACEHOLDER.getValue().matcher(value).matches()) {
                String substring = value.substring(2, value.length() - 1);
                String[] split = substring.split("\\|\\|");
                String textFlag = split[0];
                // 截取
                if (TextManipulationTypeEnum.SUBSTRING.getValue().equals(textFlag)) {
                    // 截取的第二个参数是待截取的字符, 可能是本地或者数据库占位符
                    result.addAll(resolveAllLocalPlaceholder(split[1]));
                } else if (TextManipulationTypeEnum.CONCAT.getValue().equals(textFlag)) {
                    // 拼接的第二个开始后面的都可能是本地或者数据库占位符或者计算器占位符
                    int length = split.length;
                    for (int index = 1; index < length; index++) {
                        result.addAll(resolveAllLocalPlaceholder(split[index]));
                    }
                } else if (TextManipulationTypeEnum.SECRET.getValue().equals(textFlag)) {
                    // 加密的第二个参数是待加密的字符, 可能是本地或者数据库占位符
                    result.addAll(resolveAllLocalPlaceholder(split[1]));
                } else {
                    throw new PlaceholderRuntimeException("Invalid text editing placeholder");
                }
            }
            return result;
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("A local placeholder cannot be obtained").build());
        }
    }
}
