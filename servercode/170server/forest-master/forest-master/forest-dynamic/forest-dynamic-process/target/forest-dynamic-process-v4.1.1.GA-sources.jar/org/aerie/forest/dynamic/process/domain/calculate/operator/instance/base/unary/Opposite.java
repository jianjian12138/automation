/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.calculate.OperatorNodeException;
import org.aerie.forest.dynamic.process.domain.calculate.ParamPosition;
import org.aerie.forest.dynamic.process.domain.calculate.operator.AbstractUnaryOperator;
import org.aerie.forest.dynamic.process.domain.calculate.operator.instance.base.unary.wrap.AbstractWrapUnaryOperator;
import org.aerie.forest.dynamic.process.domain.calculate.processor.StartNode;

/**
 * @description 相反数
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/4/20 9:37
 * @version 3.0.1.300
 */
public final class Opposite extends AbstractUnaryOperator {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 加法
         */
        private static final Opposite OPPOSITE = new Opposite("-");
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static Opposite getInstance() {
        return INSTANCE.OPPOSITE;
    }

    /**
     * @description Constructor
     * @param displaySymbol 展示符号
     *
     * @author zhangqi
     * @date 2023/4/19 17:32
     * @initVersion 3.0.1.300
     */
    private Opposite(String displaySymbol) {
        super(displaySymbol, "Opposite", 5);
    }

    @Override
    protected BigDecimal calculateResult(int scale, BigDecimal param) throws ExceptionPack {
        try {
            return param.negate().setScale(scale, RoundingMode.HALF_UP);
        } catch (Exception e) {
            throw new ExceptionPack(e,
                ExceptionMsg.builder("The multiply calculation failed, param: {}", param).build());
        }
    }

    @Override
    public ParamPosition getParamPosition() {
        return ParamPosition.RIGHT;
    }

    @Override
    public void verifyPre(Object pre) throws OperatorNodeException {
        super.verifyPre(pre);
        if (pre instanceof StartNode || (pre instanceof AbstractWrapUnaryOperator wrapOperator
            && wrapOperator.getParamPosition().equals(ParamPosition.RIGHT))) {
            return;
        }
        throw new OperatorNodeException(ExceptionMsg
            .builder("The prefix operator is illegal, present operator: {}, pre operator: {}", this, pre).build());
    }
}
