/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare;

import java.io.Serial;
import java.io.Serializable;

import lombok.*;

/**
 * @description 比较器逻辑组合结果
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/12/7 17:41
 * @version 3.0.1.300
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@EqualsAndHashCode
public class ComparatorLogicCombinatorialResult implements Serializable {

    @Serial
    private static final long serialVersionUID = 1249984141057171689L;

    /**
     * @description 占位符
     */
    private String placeholder;

    /**
     * @description 逻辑或层序号
     */
    private int logicOrLayerIndex;

    /**
     * @description 逻辑并且层序号
     */
    private int logicAndLayerIndex;
}
