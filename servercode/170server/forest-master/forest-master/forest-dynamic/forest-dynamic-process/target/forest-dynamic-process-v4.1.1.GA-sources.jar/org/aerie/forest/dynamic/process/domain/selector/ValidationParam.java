/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.selector;

import lombok.*;

/**
 * @description 校验参数
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/6/18 14:33
 * @version 3.0.1.300
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@EqualsAndHashCode
public class ValidationParam {

    /**
     * @description 所属企业编号
     */
    private Long ownedEnterpriseCode;

    /**
     * @description 可空标识
     */
    private boolean nullAble;
}
