/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import lombok.Getter;

/**
 * @description 文本操作占位符操作类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/9/4 18:08
 * @version v4.0.1.GA
 */
@Getter
public enum TextManipulationTypeEnum {

    /**
     * @description 截取
     */
    SUBSTRING("substring"),

    /**
     * @description 拼接
     */
    CONCAT("concat"),

    /**
     * @description 截取并拼接
     */
    SECRET("secret");

    /**
     * @description 操作类型标识
     */
    private final String value;

    /**
     * @description Constructor
     * @param value 标识值
     *
     * @author zhangqi
     * @date 2024/9/4 18:01
     * @initVersion v4.0.1.GA
     */
    TextManipulationTypeEnum(String value) {
        this.value = value;
    }
}
