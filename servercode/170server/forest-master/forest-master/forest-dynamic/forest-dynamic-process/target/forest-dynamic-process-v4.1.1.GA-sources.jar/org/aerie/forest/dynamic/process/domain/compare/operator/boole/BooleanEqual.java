/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.operator.boole;

import java.util.Objects;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.compare.AbstractBooleanSymbol;
import org.aerie.forest.dynamic.process.domain.compare.comparable.BooleanValue;

import lombok.ToString;

/**
 * @description 布尔比较 等于
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 17:59
 * @version 3.0.1.300
 */
@ToString(callSuper = true)
public final class BooleanEqual extends AbstractBooleanSymbol {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 布尔相等
         */
        private static final BooleanEqual BOOLEAN_EQUAL = new BooleanEqual();
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static BooleanEqual getInstance() {
        return INSTANCE.BOOLEAN_EQUAL;
    }

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2023/5/15 17:14
     * @initVersion 3.0.1.300
     */
    private BooleanEqual() {
        super("==", "等于", false, "BOOLEAN_EQUAL");
    }

    @Override
    protected boolean compare(BooleanValue pre, BooleanValue post) throws ExceptionPack {
        try {
            Boolean preValue = pre.getComparableValue(false);
            Boolean postValue = post.getComparableValue(false);

            return Objects.equals(preValue, postValue);
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to compare successfully, comparison expression: {}",
                pre.getValue() + getDisplaySymbol() + post.getValue()).build());
        }
    }

}
