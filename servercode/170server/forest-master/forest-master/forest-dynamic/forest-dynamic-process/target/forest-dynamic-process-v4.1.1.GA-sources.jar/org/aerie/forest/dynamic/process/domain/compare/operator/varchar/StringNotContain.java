/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.compare.operator.varchar;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.dynamic.process.domain.compare.AbstractStringSymbol;
import org.aerie.forest.dynamic.process.domain.compare.comparable.StringValue;

/**
 * @description 字符串比较 不包含
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2023/5/15 17:59
 * @version 3.0.1.300
 */
public final class StringNotContain extends AbstractStringSymbol {

    /**
     * @description 单例对象
     *
     * @author zhangqi
     * @organization futurecraftsmen
     * @date 2023/4/19 17:57
     * @version 3.0.1.300
     */
    private static final class INSTANCE {

        /**
         * @description 字符串包含
         */
        private static final StringNotContain STRING_NOT_CONTAIN = new StringNotContain();
    }

    /**
     * @description 获得单例对象
     * @return 单例对象
     *
     * @author zhangqi
     * @date 2023/4/19 17:59
     * @initVersion 3.0.1.300
     */
    public static StringNotContain getInstance() {
        return INSTANCE.STRING_NOT_CONTAIN;
    }

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2023/5/15 17:14
     * @initVersion 3.0.1.300
     */
    private StringNotContain() {
        super("!⊇", "不包含", false, "STRING_NOT_CONTAIN");
    }

    @Override
    protected boolean compare(StringValue pre, StringValue post) throws ExceptionPack {
        try {
            return !pre.getComparableValue(false).contains(post.getComparableValue(false));
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to compare successfully, comparison expression: {}",
                pre.getValue() + getDisplaySymbol() + post.getValue()).build());
        }
    }

    // 序列化单例
    private Object readResolve() {
        return INSTANCE.STRING_NOT_CONTAIN;
    }
}
