/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

/**
 * @description 动态流程 - 领域 - 文本处理
 *
 * @author zhangqi
 * @organization aerie
 * @date 2022/8/22 16:52
 * @version v2.2.1.RC
 */
package org.aerie.forest.dynamic.process.domain.text;