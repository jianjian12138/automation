/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.dynamic.process.domain.placeholder;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @description 流程模板/动态页/权益等模型关联的所有表和字段
 *
 * @author nimj
 * @date 2024/5/28
 * @version v3.1.1.GA
 */
@Getter
@Setter
public class CouplingTableField {
    /**
     * 是否需要将表和字段放入ThreadLocal
     * 加这个开关是为了只在有需要时才存放，避免不必要的性能和内存消耗
     */
    private boolean needPut = false;

    /**
     * 表和字段的映射
     * key: 表编号
     * value: 字段编号集合
     */
//    private Map<Long, Set<Long>> tableFields = new HashMap<>();

    /**
     * 流程模板关联的所有表
     */
    private List<Long> couplingTableCodes = new ArrayList<>();

    /**
     * 流程模板关联的所有字段
     */
    private List<Long> couplingFieldCodes = new ArrayList<>();

    public List<Long> getCouplingTableCodes() {
        return couplingTableCodes == null ? new ArrayList<>() : couplingTableCodes;
    }

    public List<Long> getCouplingFieldCodes() {
        return couplingFieldCodes == null ? new ArrayList<>() : couplingFieldCodes;
    }
}
