/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.dto;

import java.io.Serial;

import org.aerie.forest.core.brick.domain.dto.VerifiedDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 企业认证通过通知
 *
 * @author chengxinyu
 * @organization futurecraftsmen
 * @date 2023/11/16 17:10
 * @version 3.0.1.300
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode
public class ESignCallbackNotifyRpcDTO implements VerifiedDTO {

    @Serial
    private static final long serialVersionUID = -3912912776213393587L;

    /**
     * @description 请求中传递的签名值,来自 header参数 X-Tsign-Open-SIGNATURE
     */
    private String signature;

    /**
     * @description 本地签名值计算参数1：时间戳 来自 header参数 X-Tsign-Open-TIMESTAMP
     */
    private String timestamp;

    /**
     * @description 本地签名值计算参数2: query请求字符串
     */
    private String requestQuery;

    /**
     * @description 本地签名值计算参数3: body
     */
    private String body;

    /**
     * @description ip
     */
    private String ip;
}
