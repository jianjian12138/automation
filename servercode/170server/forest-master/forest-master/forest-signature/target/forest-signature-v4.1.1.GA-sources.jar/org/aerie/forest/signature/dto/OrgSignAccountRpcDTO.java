/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.dto;

import java.io.Serial;

import org.aerie.forest.core.brick.domain.dto.VerifiedDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 机构签署账号信息
 *
 * @author chengxinyu
 * @organization futurecraftsmen
 * @date 2022/11/2 17:29
 * @version 3.0.1.300
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode
public class OrgSignAccountRpcDTO implements VerifiedDTO {

    @Serial
    private static final long serialVersionUID = 6747879296225074501L;

    /**
     * @description e签宝 机构签署账号
     */
    private String eSignOrgAccountId;

}
