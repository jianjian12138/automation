/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.domain.request;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.assertprocess.AssertRuntimeException;
import org.aerie.forest.core.brick.function.generatethrowable.GenerateRuntimeException;
import org.aerie.forest.core.brick.processor.http.HttpRequestProcessor;
import org.aerie.forest.core.brick.processor.http.ResponseBody;
import org.aerie.forest.signature.domain.config.EsignConfig;

import lombok.AllArgsConstructor;

/**
 * @description 请求执行者
 * @param <T> 响应的类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/7/15 17:32
 * @version v4.0.1.GA
 */
@AllArgsConstructor
public abstract class AbstractRequestExecutor<T> {

    /**
     * @description 请求地址
     */
    protected String url;

    /**
     * @description http请求处理器
     */
    protected final HttpRequestProcessor httpRequestProcessor;

    /**
     * @description 签章配置
     */
    protected volatile static EsignConfig esignConfig;

    /**
     * @description 执行
     * @return 执行响应
     * @throws ExceptionPack 执行异常
     *
     * @author zhangqi
     * @date 2024/7/15 17:34
     * @initVersion v4.0.1.GA
     */
    public abstract ResponseBody<T> execute() throws ExceptionPack;

    /**
     * @description 设置签章配置
     * @param esignConfig 签章配置
     *
     * @author zhangqi
     * @date 2024/8/29 16:27
     * @initVersion v4.0.1.GA
     */
    public static void setEsignConfig(EsignConfig esignConfig) {
        AbstractRequestExecutor.esignConfig = AssertInjecter.inject(esignConfig, "esignConfig")
            .and(EsignConfig::validityJudgement)
            .judgeAndGet((GenerateRuntimeException<
                AssertRuntimeException>)(embeddedValue, exception, msg, args) -> new AssertRuntimeException(msg, args),
                "esignConfig is invalid");
    }
}
