/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.dto;

import java.io.Serial;

import org.aerie.forest.core.brick.domain.dto.VerifiedDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 企业实名认证流程信息
 *
 * @author chengxinyu
 * @organization futurecraftsmen
 * @date 2022/11/2 17:29
 * @version 3.0.1.300
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode
public class OrgAuthIdentityFlowRpcDTO implements VerifiedDTO {

    @Serial
    private static final long serialVersionUID = 61373001277518289L;

    /**
     * @description 检查结果:是否需要进行实名认证
     */
    private boolean needAuth;

    /**
     * @description 如果检查下来发现需要实名认证，该字段是永久实名认证链接
     */
    private String authUrl;

    /**
     * @description 如果检查下来发现需要实名认证，该字段是实名认证的流程id,调用方存储
     */
    private String eSignOrgAuthIdentityFlowId;

}
