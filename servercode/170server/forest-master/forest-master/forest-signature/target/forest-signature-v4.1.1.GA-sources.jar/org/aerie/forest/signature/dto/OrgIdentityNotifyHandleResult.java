/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.dto;

import lombok.Data;
import lombok.ToString;

/**
 * @description 解析企业认证结果通知 的结果
 *
 * @author chengxinyu
 * @organization futurecraftsmen
 * @date 2022/11/2 17:29
 * @version 3.0.1.300
 */
@ToString
@Data
public class OrgIdentityNotifyHandleResult {

    /**
     * @description 请求中的 contextId ,方便找到对应更新的数据
     */
    private Long registerFlowCode;

    /**
     * @description (非标流程中)机构签署账户 ,设置静默签署后，更新条件
     */
    private String orgSignAccount;

    /**
     * @description e签宝企业认证流程id (保留记录)
     */
    private String eSignOrgIdentityFlowId;

}
