/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.dto;

import java.io.Serial;
import java.util.Iterator;
import java.util.Set;

import jakarta.validation.constraints.NotBlank;
import org.aerie.forest.core.brick.domain.dto.VerifiedDTO;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 获取 e签宝企业认证流程
 *
 * @author chengxinyu
 * @organization futurecraftsmen
 * @date 2023/11/16 17:10
 * @version 3.0.1.300
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode
public class GetESignOrgAuthIdentityFlowRpcDTO implements VerifiedDTO {

    @Serial
    private static final long serialVersionUID = 2173674288533536015L;

    @NotNull(message = "企业注册流程编号缺失")
    private Long flowCode;

    /**
     * @description 企业名称
     */
    @NotBlank(message = "企业名称缺失")
    private String enterpriseName;

    /**
     * @description 企业社会统一信用代码
     */
    @NotBlank(message = "企业社会统一信用代码缺失")
    private String usccCode;

    /**
     * @description 操作人手机号
     */
    @NotBlank(message = "操作人手机号缺失")
    private String userTel;

    /**
     * @description 操作人对应的 e签宝个人签署账号
     */
    @NotBlank(message = "e签宝个人签署账号缺失")
    private String eSignUserAccountId;

    /**
     * @description e签宝机构签署账号缺失
     */
    @NotBlank(message = "e签宝机构签署账号缺失")
    private String eSignOrgAccountId;

    public String validate() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<GetESignOrgAuthIdentityFlowRpcDTO>> errors = validator.validate(this);
        if (!errors.isEmpty()) {
            Iterator<ConstraintViolation<GetESignOrgAuthIdentityFlowRpcDTO>> iterator = errors.iterator();
            if (iterator.hasNext()) {
                ConstraintViolation<GetESignOrgAuthIdentityFlowRpcDTO> firstElement = iterator.next();
                iterator.remove();
                return firstElement.getMessage();
            }
        }
        return null;
    }
}
