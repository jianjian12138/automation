/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

/**
 * @description forest - 签章 - 领域模型
 *
 * @author quark
 * @organization aerie
 * @date 2020年2月10日 下午8:11:54
 * @version 1.2.0
 */
package org.aerie.forest.signature.domain;