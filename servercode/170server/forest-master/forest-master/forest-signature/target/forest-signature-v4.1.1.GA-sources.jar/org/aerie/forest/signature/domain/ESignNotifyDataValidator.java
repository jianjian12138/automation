/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.domain;

import java.util.Arrays;
import java.util.List;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.assertprocess.AssertException;
import org.aerie.forest.signature.domain.config.EsignConfig;
import org.aerie.forest.signature.domain.processor.DigestProcessor;
import org.aerie.forest.signature.dto.ESignCallbackNotifyRpcDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @description e签宝通知数据校验器
 *
 * @author chengxinyu
 * @organization futurecraftsmen
 * @date 2022/11/2 17:29
 * @version 3.0.1.300
 */
@Slf4j
public class ESignNotifyDataValidator {

    /**
     * @description esign e签宝相关配置参数
     */
    private final EsignConfig esignConfig;

    public ESignNotifyDataValidator(EsignConfig esignConfig) {
        this.esignConfig = esignConfig;
    }

    /**
     * @description 校验请求
     * @param eSignCallbackNotifyRpcDTO 请求
     * @param isDebugMode debug 模式下,不校验请求签名值
     * @throws Exception 期待的通知类型，如果实际和预期不符，也视为校验失败
     * 
     * @author chengxinyu
     * @date 2023/11/21 10:31
     * @initVersion 3.0.1.300
     */
    public void verify(ESignCallbackNotifyRpcDTO eSignCallbackNotifyRpcDTO, boolean isDebugMode) throws Exception {

        AssertInjecter.notNull(eSignCallbackNotifyRpcDTO, "eSignCallbackNotifyRpcDTO");

        // 本地签名值计算参数3: body
        String body = AssertInjecter.notNullAndGet(eSignCallbackNotifyRpcDTO.getBody(), "body");

        if (!isDebugMode) {
            // 本地签名值计算参数1：时间戳
            String timestamp = AssertInjecter.notNullAndGet(eSignCallbackNotifyRpcDTO.getTimestamp(), "timestamp");
            // 本地签名值计算参数2: query请求字符串
            String requestQuery =
                AssertInjecter.notNullAndGet(eSignCallbackNotifyRpcDTO.getRequestQuery(), "requestQuery");

            // 本地签名值计算参数4: 项目ID对应的密钥
            String appSecret = AssertInjecter.notNullAndGet(esignConfig.getProjectSecret(), "appSecret");

            // 按照规则(hmac-sha256)进行加密
            String signData = timestamp + requestQuery + body;
            String calcSignature = DigestProcessor.INSTANCE.getSignature(signData, appSecret, "HmacSHA256", "UTF-8");
            String signature = AssertInjecter.notNullAndGet(eSignCallbackNotifyRpcDTO.getSignature(), "signature");

            if (!calcSignature.equals(signature)) {
                throw new AssertException(ExceptionMsg
                    .builder("Signature verification failure,calcSignature:{},signature:{}", calcSignature, signature)
                    .build());
            }
            List<String> allowIpList = Arrays.asList("47.96.79.204", "118.31.35.8");

            String ip = AssertInjecter.notNullAndGet(eSignCallbackNotifyRpcDTO.getIp(), "ip");

            if (!allowIpList.contains(ip)) {
                throw new AssertException(ExceptionMsg.builder("ip verification failure,ip:{}", ip).build());
            }

        }

    }
}
