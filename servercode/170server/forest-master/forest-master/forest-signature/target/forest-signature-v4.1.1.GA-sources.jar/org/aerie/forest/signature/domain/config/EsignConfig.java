/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.domain.config;

import org.aerie.forest.core.brick.exception.config.ConfigObjectDataException;
import org.aerie.forest.core.frame.rebar.entity.processer.configuration.ConfigFile;
import org.aerie.forest.core.frame.rebar.entity.processer.configuration.ForestConfig;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description e签宝环境配置
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/7/15 11:43
 * @version v4.0.1.GA
 */
@ConfigFile(configFileName = "esign", createIfNotExist = true)
@Data
@NoArgsConstructor
public class EsignConfig implements ForestConfig {

    /**
     * @description app域名
     */
    private String appDomain;

    /**
     * @description 网关
     */
    private String host;

    /**
     * @description 应用id
     */
    private String projectId;

    /**
     * @description 密钥
     */
    private String projectSecret;

    /**
     * @description 实名认证状态变更通知的地址
     */
    private String orgIdentityAuthSuccessNotifyUrl;

    /**
     * @description 认证结束后页面跳转地址，实际使用时还需要拼接requestParam
     */
    private String orgIdentityAuthSuccessRedirectUrlBase;

    @Override
    public boolean validityJudgement() throws ConfigObjectDataException {
        return true;
    }
}
