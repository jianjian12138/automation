/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.signature.dto;

import java.io.Serial;

import org.aerie.forest.core.brick.domain.dto.VerifiedDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @description 个人签署账号信息
 *
 * @author chengxinyu
 * @organization futurecraftsmen
 * @date 2022/11/2 17:29
 * @version 3.0.1.300
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode
public class UserSignAccountRpcDTO implements VerifiedDTO {

    @Serial
    private static final long serialVersionUID = -8135686683613061661L;

    /**
     * @description e签宝 个人签署账号
     */
    private String eSignUserAccountId;

}
