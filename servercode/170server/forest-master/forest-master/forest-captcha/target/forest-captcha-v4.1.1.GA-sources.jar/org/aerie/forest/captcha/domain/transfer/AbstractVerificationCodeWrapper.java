/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer;

/**
 * @description 验证信息包装者
 * @param <V> 验证信息的类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/5 17:43
 * @version v4.0.1.GA
 */
public abstract class AbstractVerificationCodeWrapper<V> {

    /**
     * @description 获得验证信息
     * @return 验证信息
     *
     * @author zhangqi
     * @date 2024/8/5 17:43
     * @initVersion v4.0.1.GA
     */
    public abstract V obtainVerificationCode();
}