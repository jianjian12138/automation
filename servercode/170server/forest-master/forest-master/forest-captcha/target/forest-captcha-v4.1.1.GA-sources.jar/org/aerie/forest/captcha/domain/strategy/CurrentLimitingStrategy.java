/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.strategy;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ComparableJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.validation.ValidationException;
import org.aerie.forest.core.brick.function.generatethrowable.GenerateException;
import org.aerie.forest.core.brick.function.verify.self.SelfVerifiable;

/**
 * @description 限流策略 - 后面可以优化成 三种模式 全局限制, 企业限制, 个人限制
 * @param max 最大限流
 * @param turnoverTime 翻转时间 - 秒
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/1 11:55
 * @version v4.0.1.GA
 */
public record CurrentLimitingStrategy(int max,
    int turnoverTime) implements SelfVerifiable<CurrentLimitingStrategy, ValidationException> {

    @Override
    public CurrentLimitingStrategy verify() throws ValidationException {
        return AssertInjecter.inject(this, "current-limiting Strategy").and(ObjectJudgementShelf.NOT_NULL)
            // 信号量策略不能为空
            .generateAssertionBinder((GenerateException<
                ValidationException>)(embeddedValue, exception, exceptionMsg) -> new ValidationException(exceptionMsg),
                "current-limiting Strategy cannot be null")
            // 最大通过量需要大于0
            .localSourceAndTransitionAssert(semaphoreStrategy -> semaphoreStrategy.max, "max")
            .and(ComparableJudgementShelf.GREATER_THAN, 0)
            .generateAssertionBinder((GenerateException<
                ValidationException>)(embeddedValue, exception, exceptionMsg) -> new ValidationException(exceptionMsg),
                "max must greater than 0")
            // 翻转时间不能小于一分钟
            .localSourceAndTransitionAssert(semaphoreStrategy -> semaphoreStrategy.turnoverTime, "turnoverTime")
            .and(ComparableJudgementShelf.GREATER_THAN_EQUAL, 60).locateSourceValue(
                (GenerateException<ValidationException>)(embeddedValue, exception,
                    exceptionMsg) -> new ValidationException(exceptionMsg),
                "turnover Time cannot be less than 60 seconds");
    }
}
