/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer.captcha;

import java.io.Serial;
import java.io.Serializable;

import org.aerie.forest.captcha.domain.transfer.AbstractVerificationSubject;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.validation.ValidationException;
import org.aerie.forest.core.brick.function.verify.self.SelfVerifiable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

/**
 * @description 滑块定位指针
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/2 10:01
 * @version v4.0.1.GA
 */
@Getter
public class SlidingBlockPoint extends AbstractVerificationSubject<SlidingBlockPoint>
    implements Serializable, SelfVerifiable<SlidingBlockPoint, ValidationException> {

    @Serial
    private static final long serialVersionUID = -8596553268530452343L;

    /**
     * @description 横坐标
     */
    private final int x;

    /**
     * @description 纵坐标
     */
    private final int y;

    /**
     * @description Constructor
     * @param x 横坐标
     * @param y 纵坐标
     *
     * @author zhangqi
     * @date 2024/8/2 10:01
     * @initVersion v4.0.1.GA
     */
    @JsonCreator
    public SlidingBlockPoint(@JsonProperty(value = "x") int x, @JsonProperty(value = "y") int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public SlidingBlockPoint verify() throws ValidationException {
        if (this.x < 0 || this.y < 0) {
            throw new ValidationException(
                ExceptionMsg.builder("Positioning coordinates are illegal, x: {}, y: {}", this.x, this.y).build());
        }
        return this;
    }

    @Override
    public boolean verificationPassed(SlidingBlockPoint slidingBlockPoint) {
        if (slidingBlockPoint == null) {
            return false;
        }
        return (slidingBlockPoint.getX() >= this.x - 3 && slidingBlockPoint.getX() <= this.x + 3)
            && slidingBlockPoint.getY() == this.y;
    }
}
