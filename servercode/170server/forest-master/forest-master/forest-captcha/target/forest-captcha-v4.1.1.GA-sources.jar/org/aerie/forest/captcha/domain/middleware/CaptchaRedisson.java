/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.middleware;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.aerie.forest.captcha.domain.AbstractCaptchaConsistencyMiddleware;
import org.aerie.forest.captcha.domain.strategy.CurrentLimitingStrategy;
import org.aerie.forest.captcha.domain.transfer.VerificationCodeConsistencyCache;
import org.aerie.forest.captcha.domain.transfer.captcha.SlidingBlockPoint;
import org.redisson.api.RRateLimiter;
import org.redisson.api.RateIntervalUnit;
import org.redisson.api.RateType;
import org.redisson.api.RedissonClient;

/**
 * @description 验证码 redisson客户端
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/19 11:24
 * @version v4.0.1.GA
 */
public final class CaptchaRedisson extends AbstractCaptchaConsistencyMiddleware<RedissonClient,
    VerificationCodeConsistencyCache<SlidingBlockPoint>, SlidingBlockPoint> {

    /**
     * @description Constructor
     * @param redissonClient redisson 客户端
     * @param clientName 客户端名称
     *
     * @author zhangqi
     * @date 2024/8/19 11:31
     * @initVersion v4.0.1.GA
     */
    public CaptchaRedisson(RedissonClient redissonClient, String clientName) {
        super(redissonClient, clientName);
    }

    @Override
    protected void set(String key, VerificationCodeConsistencyCache<SlidingBlockPoint> value, long expireTime) {
        c.getBucket(key + CACHE_FLAG).set(value, Duration.ofSeconds(expireTime));
    }

    @Override
    protected long expireTime(String key) {
        return c.getBucket(key + CACHE_FLAG).getExpireTime();
    }

    @Override
    protected boolean exist(String key) {
        return c.getBucket(key + CACHE_FLAG).isExists();
    }

    @Override
    protected VerificationCodeConsistencyCache<SlidingBlockPoint> get(String key) {
        return c.<VerificationCodeConsistencyCache<SlidingBlockPoint>>getBucket(key + CACHE_FLAG).get();
    }

    @Override
    protected void delete(String key) {
        c.getBucket(key + CACHE_FLAG).delete();
    }

    @Override
    protected boolean hasLock(String key) {
        return c.getLock(key + LOCK_FLAG).isLocked();
    }

    @Override
    protected void lock(String key, long expireTime) {
        if (expireTime < 0) {
            c.getLock(key + LOCK_FLAG).lock();
        }
        c.getLock(key + LOCK_FLAG).lock(expireTime, TimeUnit.SECONDS);
    }

    @Override
    protected long lockRemainTime(String key) {
        return c.getLock(key + LOCK_FLAG).remainTimeToLive();
    }

    @Override
    protected void unlock(String key) {
        c.getLock(key + LOCK_FLAG).unlock();
    }

    @Override
    protected void continuousLockIncrement(String key) {
        c.getAtomicLong(key + CONTINUOUS_LOCK_FLAG).getAndIncrement();
    }

    @Override
    protected long continuousLockTime(String key) {
        return c.getAtomicLong(key + CONTINUOUS_LOCK_FLAG).get();
    }

    @Override
    protected long outLimitCount(String key) {
        return c.getAtomicLong(key + OUT_LIMIT_COUNT_FLAG).get();
    }

    @Override
    protected void outLimitIncrement(String key) {
        c.getAtomicLong(key + OUT_LIMIT_COUNT_FLAG).getAndIncrement();
    }

    @Override
    protected boolean deleteOutLimitCount(String key) {
        return c.getAtomicLong(key + OUT_LIMIT_COUNT_FLAG).delete();
    }

    @Override
    protected boolean tryAcquire(String key, int num) {
        return c.getRateLimiter(key + CURRENT_LIMITING_FLAG).tryAcquire(num);
    }

    @Override
    protected void initCurrentLimiting(String key, CurrentLimitingStrategy currentLimitingStrategy) {
        RRateLimiter rateLimiter = c.getRateLimiter(key + CURRENT_LIMITING_FLAG);
        if (rateLimiter.isExists()) {
            return;
        }
        rateLimiter.trySetRate(RateType.OVERALL, currentLimitingStrategy.max(), currentLimitingStrategy.turnoverTime(),
            RateIntervalUnit.SECONDS);
    }
}