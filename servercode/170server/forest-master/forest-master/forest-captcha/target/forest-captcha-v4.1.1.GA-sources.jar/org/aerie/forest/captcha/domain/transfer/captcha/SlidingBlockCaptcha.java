/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer.captcha;

import java.io.Serial;

import org.aerie.forest.captcha.domain.transfer.AbstractCaptcha;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

/**
 * @description 滑块验证码
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/1 18:26
 * @version v4.0.1.GA
 */
@Getter
public class SlidingBlockCaptcha extends AbstractCaptcha {

    @Serial
    private static final long serialVersionUID = -5115458103673189765L;

    /**
     * @description 滑块底图
     */
    private final String slidingBlockOriginalImage;

    /**
     * @description 滑块图
     */
    private final String slidingBlockImage;

    /**
     * @description 滑块纵坐标
     */
    private final int slidingBlockY;

    /**
     * @description Constructor
     * @param slidingBlockOriginalImage 滑块底图
     * @param slidingBlockImage 滑块图
     * @param slidingBlockY 滑块纵坐标
     *
     * @author zhangqi
     * @date 2024/8/1 18:25
     * @initVersion v4.0.1.GA
     */
    @JsonCreator
    public SlidingBlockCaptcha(@JsonProperty("slidingBlockOriginalImage") String slidingBlockOriginalImage,
        @JsonProperty("slidingBlockImage") String slidingBlockImage, @JsonProperty("slidingBlockY") int slidingBlockY) {
        this.slidingBlockOriginalImage = slidingBlockOriginalImage;
        this.slidingBlockImage = slidingBlockImage;
        this.slidingBlockY = slidingBlockY;
    }
}