/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer;

/**
 * @description 用户定位信息 - 验证码是服务于用户
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/1 16:47
 * @version v4.0.1.GA
 */
public abstract class AbstractUserLocatingInfo {

    /**
     * @description 生成用户定位key
     * @return 用户定位key
     *
     * @author zhangqi
     * @date 2024/8/1 16:48
     * @initVersion v4.0.1.GA
     */
    public abstract String getUserLocatingKey();

    /**
     * @description 生成用户限流分组key
     * @return 用户限流分组key
     *
     * @author zhangqi
     * @date 2024/8/20 11:04
     * @initVersion v4.0.1.GA
     */
    public abstract String getCurrentLimitingGroupKey();

    public Boolean enableCaptcha() {
        return true;
    }
}
