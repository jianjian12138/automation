/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer;

import java.io.Serial;
import java.io.Serializable;

/**
 * @description 验证码 - 后端生成, 交由前端展示
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/7/31 16:49
 * @version v4.0.1.GA
 */
public abstract class AbstractCaptcha implements Serializable {

    @Serial
    private static final long serialVersionUID = -6604288795309645344L;
}