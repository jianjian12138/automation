///*
// * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
// */
//
//package org.aerie.forest.captcha.domain;
//
//import java.io.Serial;
//
//import lombok.Getter;
//
///**
// * @description 有定位序号的加密信息
// *
// * @author zhangqi
// * @organization futurecraftsmen
// * @date 2024/8/1 18:19
// * @version v4.0.1.GA
// */
//@Getter
//public class LocationSequenceSecretSystem extends SecretSystem {
//
//    @Serial
//    private static final long serialVersionUID = 2568891697360954965L;
//
//    /**
//     * @description 定位序号
//     */
//    private final String locationSequence;
//
//    /**
//     * @description Constructor
//     * @param publicKey 公钥
//     * @param locationSequence 定位序号
//     *
//     * @author zhangqi
//     * @date 2024/8/1 18:21
//     * @initVersion v4.0.1.GA
//     */
//    public LocationSequenceSecretSystem(String publicKey, String locationSequence) {
//        super(publicKey);
//        this.locationSequence = locationSequence;
//    }
//}
