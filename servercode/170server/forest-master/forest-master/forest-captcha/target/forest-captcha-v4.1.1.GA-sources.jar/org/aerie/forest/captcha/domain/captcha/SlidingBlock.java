/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.captcha;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import javax.imageio.ImageIO;

import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.captcha.CaptchaRuntimeException;
import org.aerie.forest.core.brick.processor.Base64Processor;
import org.aerie.forest.core.brick.processor.FileCopyProcessor;

import cn.hutool.core.util.RandomUtil;

/**
 * @description 滑块
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/2 9:30
 * @version v4.0.1.GA
 */
public enum SlidingBlock {

    /**
     * @description 单例对象
     */
    INSTANCE;

    /**
     * @description 滑块底图
     */
    private static final String ORIGINAL = "captcha-images/original/";

    /**
     * @description 滑块
     */
    private static final String SLIDING_BLOCK = "captcha-images/sliding-block/";

    /**
     * @description 本地存储的滑块底图
     */
    private final Map<String, String> originalCacheMap = new ConcurrentHashMap<>();

    /**
     * @description 本地存储的滑块
     */
    private final Map<String, String> slidingBlockCacheMap = new ConcurrentHashMap<>();

    /**
     * @description Constructor
     *
     * @author zhangqi
     * @date 2024/8/1 22:06
     * @initVersion v4.0.1.GA
     */
    SlidingBlock() {
        originalCacheMap.putAll(getImagesFile(ORIGINAL,25));
        slidingBlockCacheMap.putAll(getImagesFile(SLIDING_BLOCK,6));
    }

    /**
     * @description 获得文件
     * @param path 文件地址
     * @return image files
     *
     * @author zhangqi
     * @date 2024/8/1 21:39
     * @initVersion v4.0.1.GA
     */
    private Map<String, String> getImagesFile(String path, int num) {
        Map<String, String> imgMap = new HashMap<>();
        for (int index = 1; index <= num; index++) {
            String fileName = index + ".png";
            try (
                InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream(path.concat(fileName))) {
                imgMap.put(fileName, Base64Processor.INSTANCE.encodeToString(
                    FileCopyProcessor.INSTANCE.copyToByteArray(resourceAsStream), StandardCharsets.UTF_8));
            } catch (IOException e) {
                throw new CaptchaRuntimeException(e, "Failed to initialize the slider verification code");
            }
        }
        return imgMap;
    }

    /**
     * @description 获得随机滑块底图
     * @return 随机滑块底图
     * @throws ExceptionPack 获取异常
     *
     * @author zhangqi
     * @date 2024/8/2 9:18
     * @initVersion v4.0.1.GA
     */
    public BufferedImage getRandomOriginal() throws ExceptionPack {
        try {
            Set<String> fileNames = this.originalCacheMap.keySet();
            int randomInt = RandomUtil.randomInt(0, fileNames.size());
            return convertBase64StrToImage(this.originalCacheMap.get(new ArrayList<>(fileNames).get(randomInt)));
        } catch (Exception e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to get the random original image").build());
        }
    }

    /**
     * @description 将base64转化成图像
     * @param base64String base64
     * @return 转化后的图像
     * @throws ExceptionPack 转化异常
     *
     * @author zhangqi
     * @date 2024/8/2 9:17
     * @initVersion v4.0.1.GA
     */
    public BufferedImage convertBase64StrToImage(String base64String) throws ExceptionPack {
        try (ByteArrayInputStream inputStream = new ByteArrayInputStream(Base64.getDecoder().decode(base64String))) {
            return ImageIO.read(inputStream);
        } catch (IOException e) {
            throw new ExceptionPack(e, ExceptionMsg.builder("Unable to convert base64 to image").build());
        }
    }

    /**
     * @description 获得随机的滑块
     * @return 随机的滑块
     *
     * @author zhangqi
     * @date 2024/8/2 9:24
     * @initVersion v4.0.1.GA
     */
    public String getRandomSlidingBlock() {
        Set<String> fileNames = this.slidingBlockCacheMap.keySet();
        int randomInt = RandomUtil.randomInt(0, fileNames.size());
        return this.slidingBlockCacheMap.get(new ArrayList<>(fileNames).get(randomInt));
    }
}
