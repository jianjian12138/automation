package org.aerie.forest.captcha.domain.transfer;

/***
 * @description 校验主体
 *
 * @author xinglu
 * @date 2024/9/3 11:57
 * @initVersion 3.0.1.300
 */
public abstract class AbstractVerificationSubject<VS> {

    /**
     * @description 校验通过判断
     * @param vs 待校验的对象
     * @return 校验结果
     *
     * @author chengxinyu
     * @date 2024/9/3 11:58
     * @initVersion 3.0.1.300
     */
    public abstract boolean verificationPassed(VS vs);
}
