/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.aerie.forest.captcha.domain.strategy.VerificationStrategy;
import org.aerie.forest.captcha.domain.transfer.*;
import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.BooleanJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.StringJudgementShelf;
import org.aerie.forest.core.brick.exception.AbstractForestException;
import org.aerie.forest.core.brick.exception.AbstractForestRuntimeException;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.ExceptionPack;
import org.aerie.forest.core.brick.exception.account.LoginAccountException;
import org.aerie.forest.core.brick.exception.account.LoginAccountNoPasswordException;
import org.aerie.forest.core.brick.exception.assertprocess.AssertRuntimeException;
import org.aerie.forest.core.brick.exception.captcha.*;
import org.aerie.forest.core.brick.function.generatethrowable.GenerateRuntimeException;

/**
 * @description 验证码处理器
 * @param <T> 验证码类型
 * @param <L> 用户定位信息
 * @param <VC> 验证信息类型
 * @param <CGP> 验证码生成包类型
 * @param <VCCC> 验证码一致性缓存类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/7/31 16:01
 * @version v4.0.1.GA
 */
public abstract class AbstractCaptchaProcessor<T extends AbstractCaptcha, L extends AbstractUserLocatingInfo,
    VC extends VerificationCodePack<L, V>, V extends AbstractVerificationSubject<V>,
    CGP extends AbstractCaptchaGeneratePack<V>, VCCC extends VerificationCodeConsistencyCache<V>> {

    /**
     * @description 验证码一致性中间件
     */
    protected final AbstractCaptchaConsistencyMiddleware<?, VCCC, V> captchaConsistencyMiddleware;

    /**
     * @description 验证策略
     */
    protected final VerificationStrategy verificationStrategy;

    /**
     * @description 一致性标识map
     */
    private static final Map<String, Object> CONSISTENCY_FLAG_MAP = new ConcurrentHashMap<>();

    /**
     * @description 一致性标识
     */
    protected final String consistencyFlag;

    /**
     * @description Constructor
     * @param captchaConsistencyMiddleware 验证码一致性中间件
     * @param verificationStrategy 验证策略
     * @param consistencyFlag 一致性标识+
     *
     * @author zhangqi
     * @date 2024/7/31 15:52
     * @initVersion v4.0.1.GA
     */
    protected AbstractCaptchaProcessor(AbstractCaptchaConsistencyMiddleware<?, VCCC, V> captchaConsistencyMiddleware,
        VerificationStrategy verificationStrategy, String consistencyFlag) {
        this.captchaConsistencyMiddleware =
            AssertInjecter.notNullAndGet(captchaConsistencyMiddleware, "captchaConsistencyMiddleware",
                (GenerateRuntimeException<AssertRuntimeException>)AssertRuntimeException::new);
        this.verificationStrategy = AssertInjecter.inject(verificationStrategy, "verificationStrategy")
            .and(ObjectJudgementShelf.NOT_NULL).andByException(v -> {
                v.verify();
                return null;
            }).judgeAndGet((GenerateRuntimeException<AssertRuntimeException>)AssertRuntimeException::new,
                "verification strategy is invalid");
        this.consistencyFlag =
            AssertInjecter.inject(consistencyFlag, "middlewareConsistency").and(StringJudgementShelf.NOT_BLANK)
                .and(() -> CONSISTENCY_FLAG_MAP.putIfAbsent(consistencyFlag, new Object()) == null)
                .judgeAndGet((GenerateRuntimeException<AbstractForestRuntimeException>)(embeddedValue, exception, msg,
                    args) -> new AssertRuntimeException(msg, args), "middleware consistency repeated");
    }

    /**
     * @description 生成验证码
     * @param locatingInfo 用户定位信息
     * @return 生成的验证码
     * @throws ExceptionPack 生成验证码异常
     *
     * @author zhangqi
     * @date 2024/7/31 15:59
     * @initVersion v4.0.1.GA
     */
    public T generateCaptcha(L locatingInfo) throws AbstractForestException {
        verifyUserLocatingInfo(locatingInfo);
        whetherGenerateCaptcha(locatingInfo);
        CGP cgp = generateVerificationCode(locatingInfo);
        T t = generateCaptchaAction(locatingInfo, cgp);
        // 将验证码一致性缓存信息缓存到中间件
        this.captchaConsistencyMiddleware.set(obtainConsistencyKey(locatingInfo),
            generateVccc(cgp.obtainVerificationCode()), this.verificationStrategy.expireTime());
        return t;
    }

    /**
     * @description 生成VCCC
     * @param verificationCode 验证码
     * @return vccc
     *
     * @author zhangqi
     * @date 2024/8/20 11:47
     * @initVersion v4.0.1.GA
     */
    protected abstract VCCC generateVccc(V verificationCode);

    /**
     * @description 生成正确的认证信息
     * @param locatingInfo 用户定位信息
     * @return 正确的认证信息
     * @throws AbstractForestException 生成验证码异常
     *
     * @author zhangqi
     * @date 2024/8/2 14:23
     * @initVersion v4.0.1.GA
     */
    protected abstract CGP generateVerificationCode(L locatingInfo) throws AbstractForestException;

    /**
     * @description 生成验证码操作
     * @param locatingInfo 用户定位信息
     * @param slidingBlockGeneratePack 验证码生成包
     * @return 生成的验证码
     * @throws AbstractForestException 生成验证码异常
     *
     * @author zhangqi
     * @date 2024/8/1 16:37
     * @initVersion v4.0.1.GA
     */
    protected abstract T generateCaptchaAction(L locatingInfo, CGP slidingBlockGeneratePack)
        throws AbstractForestException;

    /**
     * @description 校验用户定位信息
     * @param locatingInfo 待校验的用户定位信息
     * @throws LoginAccountException 账号校验异常
     * @throws LoginAccountNoPasswordException 登录账号未设置密码异常
     *
     * @author zhangqi
     * @date 2024/8/1 17:30
     * @initVersion v4.0.1.GA
     */
    protected abstract void verifyUserLocatingInfo(L locatingInfo)
        throws LoginAccountException, LoginAccountNoPasswordException;

    /**
     * @description 是否可以生成验证码
     * @param locatingInfo 用户定位信息
     * @throws AbstractForestException 判断异常
     *
     * @author zhangqi
     * @date 2024/8/1 17:25
     * @initVersion v4.0.1.GA
     */
    private void whetherGenerateCaptcha(L locatingInfo) throws AbstractForestException {
        // 初始化限流器
        this.captchaConsistencyMiddleware.initCurrentLimiting(obtainCurrentLimitingKey(locatingInfo),
            this.verificationStrategy.coverCurrentLimiting());
        AssertInjecter.inject(this.verificationStrategy, "verificationStrategy").and(ObjectJudgementShelf.NOT_NULL)
            .generateAssertionBinder(ExceptionMsg.builder("verification strategy cannot be null").build())
            // 策略可覆盖, 或者 验证码不存在
            .transitionAssert(VerificationStrategy::coverCaptcha, "coverCaptcha").and(BooleanJudgementShelf.IS_TRUE)
            .or().and(() -> !this.captchaConsistencyMiddleware.exist(obtainConsistencyKey(locatingInfo)))
            .generateAssertionBinder((embeddedValue, exception,
                exceptionMsg) -> new VerificationDuplicateClaimException(exception, exceptionMsg),
                ExceptionMsg.builder("captcha has been generated").build())
            // 验证码覆盖信号量
            .localSourceAndTransitionAssert(VerificationStrategy::coverCurrentLimiting, "coverSemaphore")
            .and(ObjectJudgementShelf.IS_NULL).or()
            .and(() -> this.captchaConsistencyMiddleware.tryAcquire(obtainCurrentLimitingKey(locatingInfo), 1))
            .judgeAndReturn((embeddedValue, exception,
                exceptionMsg) -> new CaptchaGenerateCurrentLimitingException(exception, exceptionMsg),
                ExceptionMsg.builder("current limiting locked").build())
            // 用户未被锁定
            .and(() -> !this.captchaConsistencyMiddleware.hasLock(obtainConsistencyKey(locatingInfo))).judge(
                (embeddedValue, exception, exceptionMsg) -> new VerificationLockException(exception, exceptionMsg,
                    this.captchaConsistencyMiddleware.lockRemainTime(obtainConsistencyKey(locatingInfo))),
                ExceptionMsg.builder("User locked").build());
    }

    /**
     * @description 验验证验证信息
     * @param verificationCodePack 验证信息
     * @throws AbstractForestException 验证验证码异常
     *
     * @author zhangqi
     * @date 2024/7/31 16:03
     * @initVersion v4.0.1.GA
     */
    public void verifyCaptcha(VC verificationCodePack) throws AbstractForestException {
        AssertInjecter.inject(verificationCodePack, "verificationCodePack").and(ObjectJudgementShelf.NOT_NULL)
            .generateAssertionBinder(ExceptionMsg.builder("verification code pack cannot be null").build())
            // 用户定位信息不能为空
            .transitionAssert(VC::getUserLocatingInfo, "user locating info").and(ObjectJudgementShelf.NOT_NULL)
            .generateAssertionBinder((ExceptionMsg.builder("user locating info cannot be null").build()))
            // 校验信息不能为空
            .localSourceAndTransitionAssert(VC::getVerificationCode, "verification code")
            .and(ObjectJudgementShelf.NOT_NULL)
            .judge((ExceptionMsg.builder("verification code cannot be null").build()));
        // 开始校验
        V verificationCode = verificationCodePack.getVerificationCode();
        L userLocatingInfo = verificationCodePack.getUserLocatingInfo();
        // 验证用户信息
        verifyUserLocatingInfo(userLocatingInfo);
        String consistencyKey = obtainConsistencyKey(userLocatingInfo);
        AssertInjecter.inject(this.captchaConsistencyMiddleware.hasLock(consistencyKey), "has lock")
            .and(BooleanJudgementShelf.IS_FALSE).judge(ExceptionMsg.builder("User locked").build());
        // 获得验证码
        VCCC vccc = AssertInjecter.inject(this.captchaConsistencyMiddleware.get(consistencyKey), "vccc")
            .and(ObjectJudgementShelf.NOT_NULL)
            .judgeAndGet(ExceptionMsg.builder("captcha has been expired").msgView("验证码已失效").build());
        V consistencyVerificationCode =
            AssertInjecter.inject(vccc.obtainVerificationCode(), "verification code").and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndGet(ExceptionMsg.builder("consistency verification code is loss").build());

        if (consistencyVerificationCode.verificationPassed(verificationCode)) {
            // 验证通过 初始化所有计数
            return;
        }

        // 未验证通过
        long continuousLockTime = this.captchaConsistencyMiddleware.continuousLockTime(consistencyKey);
        // 未曾连续锁定
        if (continuousLockTime == 0) {
            long outLimitCount = this.captchaConsistencyMiddleware.outLimitCount(consistencyKey);
            // 已经达到超限次数
            if (outLimitCount >= this.verificationStrategy.outLimitLockingNum()) {
                // 达到超限次数, 删除验证码缓存, 加锁, 记录连续加锁次数
                this.captchaConsistencyMiddleware.delete(consistencyKey);
                this.captchaConsistencyMiddleware.lock(consistencyKey,
                    this.verificationStrategy.outLimitLockingTimeList().getFirst());
                // 记录连续加锁次数
                this.captchaConsistencyMiddleware.continuousLockIncrement(consistencyKey);
                throw new VerificationLockException(ExceptionMsg.builder(
                    "Verification failure after multiple consecutive locking, permanent locking, continuous locking time: {}",
                    continuousLockTime).build(), this.verificationStrategy.outLimitLockingTimeList().getFirst());
            }
            // 未达到超限次数 - 普通验证失败
            int chance = this.verificationStrategy.repeatVerificationNum() - vccc.getFailedNum() - 1;
            if (chance < 1) {
                // 验证失败次数达到上限
                this.captchaConsistencyMiddleware.delete(consistencyKey);
                throw new VerificationFailedException(ExceptionMsg.builder("Verification failed").build(), 0);
            }
            // 验证失败次数未达到上限
            vccc.setFailedNum(vccc.getFailedNum() + 1);
            this.captchaConsistencyMiddleware.set(consistencyKey, vccc,
                this.captchaConsistencyMiddleware.expireTime(consistencyKey));
            throw new VerificationFailedException(ExceptionMsg.builder("Verification failed").build(), chance);
        }
        if (continuousLockTime >= this.verificationStrategy.outLimitLockingTimeList().size()) {
            // 超出了连续加锁次数top, 永久锁定
            this.captchaConsistencyMiddleware.lock(consistencyKey, -1);
            throw new VerificationLockException(ExceptionMsg.builder(
                "Verification failure after multiple consecutive locking, permanent locking, continuous locking times: {}",
                continuousLockTime).build(), -1);
        }
        // 存在连续锁定
        this.captchaConsistencyMiddleware.continuousLockIncrement(consistencyKey);
        Integer lockTime = this.verificationStrategy.outLimitLockingTimeList().get((int)continuousLockTime - 1);
        this.captchaConsistencyMiddleware.lock(consistencyKey, lockTime);
        throw new VerificationLockException(ExceptionMsg.builder(
            "Verification failure after multiple consecutive locking, permanent locking, continuous locking time: {}",
            continuousLockTime).build(), lockTime);
    }

    /**
     * @description 获得限流key
     * @param locatingInfo 用户定位信息
     * @return 限流key
     * @throws AbstractForestException 获得异常
     *
     * @author zhangqi
     * @date 2024/8/20 11:05
     * @initVersion v4.0.1.GA
     */
    protected String obtainCurrentLimitingKey(L locatingInfo) throws AbstractForestException {
        return this.consistencyFlag + "_"
            + AssertInjecter.inject(locatingInfo, "locatingInfo").and(ObjectJudgementShelf.NOT_NULL)
                .judgeAndGet(ExceptionMsg.builder("locating info cannot be null").build()).getCurrentLimitingGroupKey();
    }

    /**
     * @description 生成一致性key
     * @param locatingInfo 用户定位信息
     * @return 一致性key
     *
     * @author zhangqi
     * @date 2024/8/2 14:46
     * @initVersion v4.0.1.GA
     */
    protected String obtainConsistencyKey(L locatingInfo) {
        return this.consistencyFlag + "_" + AssertInjecter.inject(locatingInfo, "locatingInfo")
            .and(ObjectJudgementShelf.NOT_NULL)
            .judgeAndGet((GenerateRuntimeException<CaptchaGenerateRuntimeException>)(embeddedValue, exception, msg,
                args) -> new CaptchaGenerateRuntimeException(exception, msg, args), "locating info cannot be null")
            .getUserLocatingKey();
    }

    /**
     * @description 暴力验证记录
     * @param locatingInfo 用户定位信息
     * @param message 记录信息
     *
     * @author zhangqi
     * @date 2024/8/6 21:06
     * @initVersion v4.0.1.GA
     */
    private void bruteForceValidationRecord(L locatingInfo, String message) {
        if (!this.verificationStrategy.windfallVerificationRecords()) {
            return;
        }
        bruteForceValidationRecordAction(locatingInfo, message);
    }

    /**
     * @description 暴力验证记录操作
     * @param locatingInfo 用户定位信息
     *
     * @author zhangqi
     * @date 2024/8/6 21:17
     * @initVersion v4.0.1.GA
     */
    protected abstract void bruteForceValidationRecordAction(L locatingInfo, String message);
}