/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain;

import java.util.UUID;

import org.aerie.forest.captcha.domain.strategy.CurrentLimitingStrategy;
import org.aerie.forest.captcha.domain.transfer.VerificationCodeConsistencyCache;
import org.aerie.forest.core.brick.consistency.AbstractConsistencyMiddleware;

/**
 * @description 验证码一致性中间件
 * @param <C> 客户端类型
 * @param <VCCC> 验证码一致性缓存类型
 * @param <V> 验证信息类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/7/31 15:29
 * @version v4.0.1.GA
 */
public abstract class AbstractCaptchaConsistencyMiddleware<C, VCCC extends VerificationCodeConsistencyCache<V>, V>
    extends AbstractConsistencyMiddleware<C> {

    /**
     * @description 中间件业务层编号
     */
    private static final String CONSISTENCY_MIDDLEWARE_BUSINESS_CODE = UUID.randomUUID().toString();

    /**
     * @description 缓存标识
     */
    protected static final String CACHE_FLAG = "-Cache";

    /**
     * @description 锁标识
     */
    protected static final String LOCK_FLAG = "-Lock";

    /**
     * @description 连续锁计数标识
     */
    protected static final String CONTINUOUS_LOCK_FLAG = "-CLock";

    /**
     * @description 超限计数标识
     */
    protected static final String OUT_LIMIT_COUNT_FLAG = "-OLimit";

    /**
     * @description 限流标识
     */
    protected static final String CURRENT_LIMITING_FLAG = "-CLimit";

    /**
     * @description Constructor
     * @param c 客户端
     * @param clientName 客户端名称
     *
     * @author zhangqi
     * @date 2024/7/31 15:28
     * @initVersion v4.0.1.GA
     */
    protected AbstractCaptchaConsistencyMiddleware(C c, String clientName) {
        super(c, clientName);
    }

    @Override
    protected final String getConsistencyMiddlewareBusinessCode() {
        return CONSISTENCY_MIDDLEWARE_BUSINESS_CODE;
    }

    // 验证信息一致性缓存 - 设置, 查询, 判断存在, 删除
    /**
     * @description 设置验证码验证信息到中间件
     * @param key 验证信息的key
     * @param value 验证信息
     * @param expireTime 过期时间
     *
     * @author zhangqi
     * @date 2024/7/31 18:12
     * @initVersion v4.0.1.GA
     */
    protected abstract void set(String key, VCCC value, long expireTime);

    /**
     * @description 获得一致性验证信息缓存的过期时间
     * @param key 验证信息的key
     * @return 获得的过期时间
     *
     * @author zhangqi
     * @date 2024/8/7 10:48
     * @initVersion v4.0.1.GA
     */
    protected abstract long expireTime(String key);

    /**
     * @description 判断验证码是否存在
     * @param key 验证信息的key
     * @return 判断结果
     *
     * @author zhangqi
     * @date 2024/8/2 15:26
     * @initVersion v4.0.1.GA
     */
    protected abstract boolean exist(String key);

    /**
     * @description 根据key获得验证码验证信息
     * @param key 验证信息的key
     * @return 获得的验证信息
     *
     * @author zhangqi
     * @date 2024/7/31 18:15
     * @initVersion v4.0.1.GA
     */
    protected abstract VCCC get(String key);

    /**
     * @description 根据key删除验证码验证信息
     * @param key 验证信息的key
     *
     * @author zhangqi
     * @date 2024/7/31 18:17
     * @initVersion v4.0.1.GA
     */
    protected abstract void delete(String key);

    // 用户锁 - 查询, 加锁, 删锁
    /**
     * @description 判断用户是否被锁定
     * @param key 验证信息的key
     * @return 判断结果
     *
     * @author zhangqi
     * @date 2024/8/5 16:03
     * @initVersion v4.0.1.GA
     */
    protected abstract boolean hasLock(String key);

    /**
     * @description 尝试加锁
     * @param key 验证信息的key
     * @param expireTime 过期时间
     *
     * @author zhangqi
     * @date 2024/8/6 22:03
     * @initVersion v4.0.1.GA
     */
    protected abstract void lock(String key, long expireTime);

    /**
     * @description 获得锁的有效时间
     * @param key 验证信息的key
     * @return 有效时间
     *
     * @author zhangqi
     * @date 2024/9/2 19:02
     * @initVersion v4.0.1.GA
     */
    protected abstract long lockRemainTime(String key);

    /**
     * @description 解锁
     * @param key 验证信息的key
     *
     * @author zhangqi
     * @date 2024/8/6 22:03
     * @initVersion v4.0.1.GA
     */
    protected abstract void unlock(String key);

    // 连续锁记录的增,查
    /**
     * @description 连续锁次数的自增
     * @param key 验证信息的key
     *
     * @author zhangqi
     * @date 2024/8/7 15:05
     * @initVersion v4.0.1.GA
     */
    protected abstract void continuousLockIncrement(String key);

    /**
     * @description 连续加锁的次数 - 没有就是 -1
     * @param key 验证信息的key
     * @return 连续加锁的次数
     *
     * @author zhangqi
     * @date 2024/8/7 15:05
     * @initVersion v4.0.1.GA
     */
    protected abstract long continuousLockTime(String key);

    // 超限计数 - 查询, 自增, 删除
    /**
     * @description 获得超限计数 - 没有就是 -1
     * @param key 验证信息的key
     * @return 超限计数的值
     *
     * @author zhangqi
     * @date 2024/8/6 22:03
     * @initVersion v4.0.1.GA
     */
    protected abstract long outLimitCount(String key);

    /**
     * @description 超限自增
     * @param key 验证信息的key
     *
     * @author zhangqi
     * @date 2024/8/6 22:05
     * @initVersion v4.0.1.GA
     */
    protected abstract void outLimitIncrement(String key);

    /**
     * @description 删除超限累加值
     * @param key 验证信息的key
     * @return 累加结果
     *
     * @author zhangqi
     * @date 2024/8/6 22:06
     * @initVersion v4.0.1.GA
     */
    protected abstract boolean deleteOutLimitCount(String key);

    // 信号量 - 信号量只能初始化和释放

    /**
     * @description 获得许可证
     * @param key 验证信息的key
     * @param num 获得许可证的数量
     * @return 释放的结果
     *
     * @author zhangqi
     * @date 2024/8/5 15:34
     * @initVersion v4.0.1.GA
     */
    protected abstract boolean tryAcquire(String key, int num);

    /**
     * @description 初始化限流
     * @param key 验证信息的key
     * @param currentLimitingStrategy 限流策略
     *
     * @author zhangqi
     * @date 2024/8/7 15:25
     * @initVersion v4.0.1.GA
     */
    protected abstract void initCurrentLimiting(String key, CurrentLimitingStrategy currentLimitingStrategy);
}
