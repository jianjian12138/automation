/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer.captcha;

import java.awt.image.BufferedImage;

import org.aerie.forest.captcha.domain.transfer.AbstractCaptchaGeneratePack;

import lombok.Getter;

/**
 * @description 滑块验证码生成包
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/5 17:48
 * @version v4.0.1.GA
 */
public class SlidingBlockGeneratePack extends AbstractCaptchaGeneratePack<SlidingBlockPoint> {

    /**
     * @description 验证信息
     */
    private final SlidingBlockPoint verificationCode;

    /**
     * @description 随机底图
     */
    @Getter
    private final BufferedImage randomOriginal;

    /**
     * @description 随机滑块
     */
    @Getter
    private final String randomSlidingBlock;

    /**
     * @description Constructor
     * @param verificationCode 验证信息
     * @param randomOriginal 随机底图
     * @param randomSlidingBlock 随机滑块
     *
     * @author zhangqi
     * @date 2024/8/5 17:48
     * @initVersion v4.0.1.GA
     */
    public SlidingBlockGeneratePack(SlidingBlockPoint verificationCode, BufferedImage randomOriginal,
        String randomSlidingBlock) {
        this.verificationCode = verificationCode;
        this.randomOriginal = randomOriginal;
        this.randomSlidingBlock = randomSlidingBlock;
    }

    @Override
    public SlidingBlockPoint obtainVerificationCode() {
        return this.verificationCode;
    }
}
