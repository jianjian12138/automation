/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer;

import java.io.Serial;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;

/**
 * @description 验证码
 * @param <L> 用户定位信息类型
 * @param <V> 验证信息
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/7/31 17:27
 * @version v4.0.1.GA
 */
@Getter
public class VerificationCodePack<L extends AbstractUserLocatingInfo, V> implements Serializable {

    @Serial
    private static final long serialVersionUID = -8409183074640913127L;

    /**
     * @description 用户定位信息
     */
    private final L userLocatingInfo;

    /**
     * @description 验证信息
     */
    private final V verificationCode;

    /**
     * @description Constructor
     * @param userLocatingInfo 用户定位信息
     * @param verificationCode 验证信息
     *
     * @author zhangqi
     * @date 2024/7/31 17:24
     * @initVersion v4.0.1.GA
     */
    @JsonCreator
    public VerificationCodePack(@JsonProperty(value = "userLocatingInfo") L userLocatingInfo,
        @JsonProperty(value = "verificationCode") V verificationCode) {
        this.userLocatingInfo = userLocatingInfo;
        this.verificationCode = verificationCode;
    }
}
