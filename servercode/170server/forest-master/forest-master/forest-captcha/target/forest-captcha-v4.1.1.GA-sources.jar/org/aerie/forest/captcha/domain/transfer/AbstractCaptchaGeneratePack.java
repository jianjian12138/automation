/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer;

/**
 * @description 验证码生成包
 * @param <V> 验证信息的类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/5 17:43
 * @version v4.0.1.GA
 */
public abstract class AbstractCaptchaGeneratePack<V> extends AbstractVerificationCodeWrapper<V> {

}