/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.strategy;

import java.util.List;
import java.util.Objects;

import org.aerie.forest.core.brick.assertprocess.AssertInjecter;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.BooleanJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ComparableJudgementShelf;
import org.aerie.forest.core.brick.assertprocess.judge.judgement.shelf.ObjectJudgementShelf;
import org.aerie.forest.core.brick.exception.ExceptionMsg;
import org.aerie.forest.core.brick.exception.validation.ValidationException;
import org.aerie.forest.core.brick.function.generatethrowable.GenerateException;
import org.aerie.forest.core.brick.function.verify.self.SelfVerifiable;

import cn.hutool.core.collection.CollUtil;

/**
 * @description 验证策略
 * @param repeatVerificationNum 重复验证次数 - 重新生成验证码 计数会清零 1-10 --- 影响验证
 * @param coverCaptcha 可以覆盖验证码标识 --- 影响验证码生成
 * @param coverCurrentLimiting 覆盖限流 --- 影响验证码生成
 * @param expireTime 过期时间 --- 影响验证、验证码生成
 * @param windfallVerificationRecords 暴力验证记录 - 开启标识 --- 影响验证、验证码生成
 * @param outLimitCountTimeEffective 超限计数时间有效 --- 影响验证、验证码生成
 * @param outLimitLockingNum 超限锁的次数 --- 影响验证、验证码生成
 * @param outLimitLockingTimeList 超限锁的时间集合 --- 影响验证、验证码生成
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/1 15:44
 * @version v4.0.1.GA
 */
public record VerificationStrategy(int repeatVerificationNum, boolean coverCaptcha, CurrentLimitingStrategy coverCurrentLimiting,
    int expireTime, boolean windfallVerificationRecords, int outLimitCountTimeEffective, int outLimitLockingNum,
    List<Integer> outLimitLockingTimeList) implements SelfVerifiable<VerificationStrategy, ValidationException> {

    @Override
    public VerificationStrategy verify() throws ValidationException {
        return AssertInjecter.inject(this, "verification Strategy").and(ObjectJudgementShelf.NOT_NULL)
            // 验证策略不能为空
            .generateAssertionBinder((GenerateException<
                ValidationException>)(embeddedValue, exception, exceptionMsg) -> new ValidationException(exceptionMsg),
                "verification Strategy cannot be null")
            // 重复验证次数必须大于等于0, 小于等于10
            .localSourceAndTransitionAssert(verificationStrategy -> verificationStrategy.repeatVerificationNum,
                "repeat Verification Num")
            .and(ComparableJudgementShelf.GREATER_THAN_EQUAL, 1).and(ComparableJudgementShelf.LESS_THAN_EQUAL, 10)
            .generateAssertionBinder(
                (GenerateException<ValidationException>)(embeddedValue, exception,
                    exceptionMsg) -> new ValidationException(exceptionMsg),
                "repeat Verification Num must be greater than or equal to 1 and less than or equal to 10")
            // 可以覆盖验证码必须要提供信号量策略, 不能覆盖验证码信号量策略必须是空
            .localSourceAndTransitionAssert(verificationStrategy -> verificationStrategy.coverCaptcha, "cover Captcha")
            .and(BooleanJudgementShelf.IS_TRUE).and(() -> this.coverCurrentLimiting != null).or()
            .and(BooleanJudgementShelf.IS_FALSE).and(() -> this.coverCurrentLimiting == null)
            .generateAssertionBinder((GenerateException<
                ValidationException>)(embeddedValue, exception, exceptionMsg) -> new ValidationException(exceptionMsg),
                "cover Captcha cannot be null")
            // 信号量策略不为空时需要校验
            .localSourceAndTransitionAssert(verificationStrategy -> verificationStrategy.coverCurrentLimiting,
                "cover Semaphore")
            .and(ObjectJudgementShelf.IS_NULL).or().andByException(CurrentLimitingStrategy::verify)
            .generateAssertionBinder((GenerateException<
                ValidationException>)(embeddedValue, exception, exceptionMsg) -> new ValidationException(exceptionMsg),
                "cover Semaphore is invalid")
            // 过期时间必须大于等于15, 小于等于60
            .localSourceAndTransitionAssert(verificationStrategy -> verificationStrategy.expireTime, "expire Time")
            .and(ComparableJudgementShelf.GREATER_THAN_EQUAL, 15).and(ComparableJudgementShelf.LESS_THAN_EQUAL, 60)
            .generateAssertionBinder(
                (GenerateException<ValidationException>)(embeddedValue, exception,
                    exceptionMsg) -> new ValidationException(exceptionMsg),
                "expire Time must be greater than or equal to 15 and less than or equal 60")
            // 超限锁定次数必须大于2倍的重复验证次数, 小于等于5倍的重复验证次数, 或者等于-1(不锁定)
            .localSourceAndTransitionAssert(verificationStrategy -> verificationStrategy.outLimitLockingNum,
                "out Limit Locking Num")
            .and(ComparableJudgementShelf.GREATER_THAN, 2 * repeatVerificationNum)
            .and(ComparableJudgementShelf.LESS_THAN_EQUAL, 5 * repeatVerificationNum)
            .and(() -> this.outLimitLockingTimeList != null).or().and(ComparableJudgementShelf.EQUAL_TO, -1)
            .and(() -> this.outLimitLockingTimeList == null)
            .generateAssertionBinder(
                (GenerateException<ValidationException>)(embeddedValue, exception,
                    exceptionMsg) -> new ValidationException(exceptionMsg),
                "out Limit Locking Num must be greater than or equal to 3 and less than or equal 7 and outLimitLockingTimeList not null or equal -1 and outLimitLockingTimeList is not null")
            // 超限锁定次数不等于-1时, 超限计数时间有效必须大于3倍的过期时间最大值, 超限锁定次数等于-1时, 超限计数时间有效必须等于0
            .localSourceAndTransitionAssert(verificationStrategy -> verificationStrategy.outLimitCountTimeEffective,
                "out Limit Count Time Effective")
            .and(ComparableJudgementShelf.GREATER_THAN_EQUAL, 180).and(() -> this.outLimitLockingNum != -1).or()
            .and(ComparableJudgementShelf.EQUAL_TO, 0).and(() -> this.outLimitLockingNum == -1)
            .generateAssertionBinder(
                (GenerateException<ValidationException>)(embeddedValue, exception,
                    exceptionMsg) -> new ValidationException(exceptionMsg),
                "out Limit Count Time Effective must be greater than 180s and outLimitLockingNum not equal -1 or equal 0 and outLimitLockingNum equal -1")
            // 超限锁定时间间隔集合不为空时校验
            .localSourceAndTransitionAssert(verificationStrategy -> verificationStrategy.outLimitLockingTimeList,
                "out Limit Locking Time List")
            .and(ObjectJudgementShelf.NOT_NULL).andByException(outLimitLockingTimeList -> {
                verifyOutLimitLockingTimeList(outLimitLockingTimeList);
                return null;
            }).locateSourceValue(
                (GenerateException<ValidationException>)(embeddedValue, exception,
                    exceptionMsg) -> new ValidationException(exception, exceptionMsg),
                "out Limit Locking Time List is invalid");
    }

    /**
     * @description 校验 超限锁定时间间隔集合
     * @param outLimitLockingTimeList 待校验的超限锁定时间间隔集合
     * @throws ValidationException 校验异常
     *
     * @author zhangqi
     * @date 2024/8/1 15:43
     * @initVersion v4.0.1.GA
     */
    private void verifyOutLimitLockingTimeList(List<Integer> outLimitLockingTimeList) throws ValidationException {
        if (CollUtil.isEmpty(outLimitLockingTimeList)) {
            return;
        }
        AssertInjecter.inject(outLimitLockingTimeList, "out Limit Locking Time List")
            .and(p -> p.stream().allMatch(Objects::nonNull)).judge(
                (GenerateException<ValidationException>)(embeddedValue, exception,
                    exceptionMsg) -> new ValidationException(exceptionMsg),
                "the times of out Limit Locking Time List must not null");
        // 锁定最小时间为60s
        int cacheTime = 60;
        for (Integer time : outLimitLockingTimeList) {
            if (time < cacheTime) {
                throw new ValidationException(ExceptionMsg.builder(
                    "The later lock time must be greater than the earlier lock time, outLimitLockingTimeList: {}",
                    outLimitLockingTimeList.toString()).build());
            }
            cacheTime = time;
        }
    }
}
