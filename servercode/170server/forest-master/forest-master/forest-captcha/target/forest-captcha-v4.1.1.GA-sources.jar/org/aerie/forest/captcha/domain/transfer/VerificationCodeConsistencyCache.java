/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */

package org.aerie.forest.captcha.domain.transfer;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * @description 验证信息一致性缓存
 * @param <V> 验证信息类型
 *
 * @author zhangqi
 * @organization futurecraftsmen
 * @date 2024/8/6 10:53
 * @version v4.0.1.GA
 */
public class VerificationCodeConsistencyCache<V> extends AbstractVerificationCodeWrapper<V> {

    /**
     * @description 验证信息
     */
    private final V verificationCode;

    /**
     * @description 验证失败次数
     */
    @Getter
    @Setter
    private int failedNum;

    /**
     * @description Constructor
     * @param verificationCode 验证信息
     * @param failedNum 验证失败次数
     *
     * @author zhangqi
     * @date 2024/8/6 10:53
     * @initVersion v4.0.1.GA
     */
    @JsonCreator
    public VerificationCodeConsistencyCache(@JsonProperty(value = "verificationCode") V verificationCode,
        @JsonProperty(value = "failedNum") int failedNum) {
        this.verificationCode = verificationCode;
        this.failedNum = failedNum;
    }

    @Override
    public V obtainVerificationCode() {
        return this.verificationCode;
    }
}
