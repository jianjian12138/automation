/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */
/**
 * 
 * @description forest的验证码模块 - 领域模型 - 策略
 *
 * @author quark
 * @organization aerie
 * @date 2020年2月10日 下午8:11:54
 * @version 1.2.0
 */
package org.aerie.forest.captcha.domain.strategy;