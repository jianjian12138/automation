/*
 * Copyright (c) Artisan Hovel Technology Co. Ltd. 1992-2062 All rights reserved
 */
/**
 * 
 * @description forest的验证码模块 - 领域模型 - 传输 - Completely Automated Public Turing test to tell Computers and Humans
 *              Apart（全自动区分计算机和人类的图灵测试）
 *
 * @author quark
 * @organization aerie
 * @date 2020年2月10日 下午8:11:54
 * @version 1.2.0
 */
package org.aerie.forest.captcha.domain.transfer.captcha;